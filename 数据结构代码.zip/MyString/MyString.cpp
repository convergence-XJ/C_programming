#include <iostream>
#include <cstring>
#include "MyString.h"

using namespace std;

// 无参构造函数
MyString::MyString()
{
    str = NULL;
    len = 0;
    capacity = 0;
}

//带参构造函数
MyString::MyString(const char* s)
{
    len = strlen(s); // 确定长度
    capacity = len; // 确定容量
    str = new char[capacity + 1]; // 分配空间
    strcpy(str, s); // 复制
}

// 析构函数
MyString::~MyString()
{
    delete []str; // 释放内存
}

// 把MyString型对象s赋值给调用本成员函数的对象
void MyString::assign(MyString &s)
{
    len = strlen(s.get_str());
    if(capacity < len) // 容量不足
    {
        capacity = len;
        delete[] str; // 清理旧空间
        str = new char[capacity + 1]; // 空间扩充
        if(!str) // 注意检查是否分配成功
        {
            cout << "insufficient memory" << endl;
            exit(1);
        }
    }
    strcpy(str, s.get_str()); // 复制
}

// 把MyString型对象添加到调用本成员函数的对象的后面
void MyString::append(MyString &s)
{
    len += strlen(s.get_str()); // 扩充长度
    if(capacity < len){
        capacity = len; // 扩充容量
        char* temp_str = new char[len + 1];  // 扩充空间
        if(!temp_str) // 注意检查是否分配成功
        {
            cout << "insufficient memory" << endl;
            exit(1);
        }
        strcpy(temp_str, str); // 把原字符串复制过去
        delete[] str; // 回收原字符串占据的空间
        str = temp_str; // 指针重定向
    }
    strcat(str, s.get_str()); // 连接
}

void MyString::show()
{
    cout << str;
}
