#ifndef MY_STRING_H
#define MY_STRING_H

class MyString{
    private:
        char *str; // 字符串首元素地址
        int len; // 字符串长度
        int capacity; // 字符串容量
        // 获取字符串首元素地址
        char* get_str() // 涉及内存，设为私有比较保险
        {
            return str;
        }
    public:
        MyString();
        MyString(const char* s);
        ~MyString();
        // 把MyString类型对象s赋值给当前MyString类型对象
        void assign(MyString &s);
        // 把对象s连接到当前的对象之后
        void append(MyString &s);
        void show();
};

#endif