#include <iostream>
#include <cstring>
#include <queue>
#include <string>
#include <fstream>

#include "MyAdjacencyList.h"

using namespace std;

const int OK = 1;
const int ERROR = 0;

// 给定顶点，返回它在顶点数组（0号单元弃用）中的下标；若不存在，则返回0
int locate_vertex(const ALGraph &my_graph, VertexType data)
{
    int i;
    for(i = my_graph.vertex_num; i > 0; --i)
    {
        if(my_graph.vertices[i].data == data)
        {
            break;
        }
    }
    return i;
}

// 利用邻接表创建无向图，根据文件提供的数据
int create_undirected_graph(ALGraph &my_graph)
{
    cout << "input vertex num:" << endl;
    cin >> my_graph.vertex_num; // 输入顶点数
    cout << "input arc num:" << endl;
    cin >> my_graph.arc_num; // 输入边数

    my_graph.vertices = new VertexNode[my_graph.vertex_num + 1]; // 申请空间
    if(!my_graph.vertices)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }

    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        cout << "input a value of the " << i << "-th vertex" << endl;
        cin >> my_graph.vertices[i].data; // 输入顶点的数据
        my_graph.vertices[i].arc_first = NULL; // 一开始没发现任何邻边，所以默认顶点度数为零
    }

    for(int k = 1; k <= my_graph.arc_num; k++)
    {
        VertexType v1, v2;
        cout << "input two vertices for " << k << "-th edge" << endl;
        cin >> v1 >> v2;
        int i = locate_vertex(my_graph, v1); // 查找v1的下标
        int j = locate_vertex(my_graph, v2); // 查找v2的下标
        int weight;
        cout << "input the weight of this edge" << endl;
        cin >> weight;

        // 有向图只要做出一个结点，并关联到弧头顶点处
        ArcNode *p1 = new ArcNode; 
        if(!p1)
        {
            cout << "insufficent memory" << endl;
            return ERROR;
        }
        p1->to_vertex_id = j; // 记下邻居顶点下标j
        // 链表头插入操作，插入到i号顶点关联的链表
        p1->arc_next = my_graph.vertices[i].arc_first; // 有向图只关联到弧头顶点处
        my_graph.vertices[i].arc_first = p1; // 无向图要关联到两个顶点
        // 写入边权
        p1->activity_time = weight;
#ifdef undirected_mode
        // 无向图还要再做出一个结点，然后关联到另一个顶点处
        ArcNode *p2 = new ArcNode;
        if(!p2)
        {
            cout << "insufficient memory" << endl;
            return ERROR;
        }
        p2->to_vertex_id = i; // 记下邻居顶点下标i
        // 链表头插入操作，插入到j号顶点关联的链表
        p2->arc_next = my_graph.vertices[j].arc_first; // 
        my_graph.vertices[j].arc_first = p2;
        // 写入边权
        p2->activity_time = weight;
#endif
    }
    return OK;
}

// 利用邻接表创建无向图，根据文件提供的数据
int create_undirected_graph(ALGraph &my_graph, const string file_name)
{
    ifstream in_file(file_name);
    if(!in_file)
    {
        cout << "fail to open " << file_name << endl;
        return ERROR;
    }

    int v_num, e_num;
    in_file >> my_graph.vertex_num >> my_graph.arc_num;

    // 分配空间
    my_graph.vertices = new VertexNode[my_graph.vertex_num + 1]; // 申请空间
    if(!my_graph.vertices)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }

    // 初始化顶点数组
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        in_file >> my_graph.vertices[i].data; // 输入顶点的数据
        my_graph.vertices[i].arc_first = NULL; // 一开始没发现任何邻边，所以默认顶点度数为零
    }

    // 为邻接表的结点分配空间
    for(int k = 1; k <= my_graph.arc_num; k++)
    {
        VertexType v1, v2;
        int weight;
        in_file >> v1 >> v2 >> weight;
        int i = locate_vertex(my_graph, v1); // 查找v1的下标
        int j = locate_vertex(my_graph, v2); // 查找v2的下标

        // 有向图只要做出一个结点，然后关联到弧头顶点处
        ArcNode *p1 = new ArcNode; 
        if(!p1)
        {
            cout << "insufficent memory" << endl;
            return ERROR;
        }
        p1->to_vertex_id = j; // 记下邻居顶点下标j
        // 链表头插入操作，插入到i号顶点关联的链表
        p1->arc_next = my_graph.vertices[i].arc_first; 
        my_graph.vertices[i].arc_first = p1; 
        // 写入边权
        p1->activity_time = weight;
#ifdef undirected_mode
        // 无向图要再做出一个结点，关联到另一个顶点
        ArcNode *p2 = new ArcNode;
        if(!p2)
        {
            cout << "insufficient memory" << endl;
            return ERROR;
        }
        p2->to_vertex_id = i; // 记下邻居顶点下标i
        // 链表头插入操作，插入到j号顶点关联的链表
        p2->arc_next = my_graph.vertices[j].arc_first; 
        my_graph.vertices[j].arc_first = p2;
        // 写入边权
        p2->activity_time = weight;
#endif
        
    }
    in_file.close();
    return OK;
}

// 深度优先遍历
void dfs(ALGraph &my_graph, int v, int* visited) // 只用于访问连通图
// my_graph为邻接矩阵类型，它的一部分顶点可能已经被访问过，
// 从第v个顶点出发深度优先搜索遍历图my_graph
// 借助visited数组来维护各个顶点的访问情况
{
    cout << my_graph.vertices[v].data << '\t'; // 访问第v个顶点
    visited[v] = true; // 把它置为已访问
    ArcNode* p = my_graph.vertices[v].arc_first;
    while(p)
    {
        int w = p->to_vertex_id;
        if(!visited[w])
        {
            dfs(my_graph, w, visited);
        }
        p = p->arc_next;
    }
}


// 深度优先访问非连通图，my_graph为邻接矩阵类型
int dfs_traverse(ALGraph &my_graph)
{
    // 以下用于维护各个顶点被访问的状况
    int *visited = new int[my_graph.vertex_num + 1];
    if(!visited) 
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }
    memset(visited, 0, sizeof(int) * (my_graph.vertex_num + 1)); // 初始化为未访问
    // 考虑每个顶点，以防非连通
    for(int v = 1; v <= my_graph.vertex_num; v++)
    {
        if(!visited[v]) // 找到未被访问的连通分量
        {
            dfs(my_graph, v, visited); // 每调用一次遍历一个连通分量
        }
    }
    delete[] visited;
    return OK;
}

// 广度优先遍历
void bfs(ALGraph &my_graph, int v, int* visited) // 只用于访问连通图
// my_graph为邻接矩阵类型，它的一部分顶点可能已经被访问过，
// 从第v个顶点出发广度优先遍历图my_graph
// 借助visited数组来维护各个顶点的访问情况
{
    cout << my_graph.vertices[v].data << '\t'; // 访问第v个顶点
    visited[v] = true; // 把它置为已访问
    queue<int> que; // 用于存储自身已被访问，但邻居不确定是否全被访问的顶点
    que.push(v);
    while(!que.empty())
    {
        int w = que.front(); // 获取队首元素
        que.pop(); // 
        ArcNode* p = my_graph.vertices[w].arc_first;
        while(p)
        {
            if(!visited[p->to_vertex_id]) // 该邻居仍未被访问
            {
                cout << my_graph.vertices[p->to_vertex_id].data << '\t';
                visited[p->to_vertex_id] = true; // 置为已访问
                que.push(p->to_vertex_id); // 邻居入队
            }
            p = p->arc_next;
        }
    }
}


// 广度优先访问非连通图，my_graph为邻接矩阵类型
int bfs_traverse(ALGraph &my_graph)
{
    // 以下用于维护各个顶点被访问的状况
    int *visited = new int[my_graph.vertex_num + 1];
    if(!visited) 
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }
    memset(visited, 0, sizeof(int) * (my_graph.vertex_num + 1)); // 初始化为未访问
    // 考虑每个顶点，以防非连通
    for(int v = 1; v <= my_graph.vertex_num; v++)
    {
        if(!visited[v]) // 找到未被访问的连通分量
        {
            bfs(my_graph, v, visited); // 每调用一次遍历一个连通分量
        }
    }
    delete[] visited;
    return OK;
}


// 销毁邻接表
void destroy_graph(ALGraph& my_graph)
{
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        while(my_graph.vertices[i].arc_first)
        {
            ArcNode* p = my_graph.vertices[i].arc_first;
            my_graph.vertices[i].arc_first = my_graph.vertices[i].arc_first->arc_next;
            delete p;
        }
    }
    delete[] my_graph.vertices;
}

// 打印邻接表构建的图
void print_graph(const ALGraph& my_graph)
{
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        ArcNode* p = my_graph.vertices[i].arc_first;
        while(p)
        {
            if(i <= p->to_vertex_id)
            {
#ifdef undirected_mode
                cout << "("; 
#else
                cout << "<";
#endif
                cout << my_graph.vertices[i].data << ", " << my_graph.vertices[p->to_vertex_id].data << ", " << p->activity_time; 
#ifdef undirected_mode
                cout << "), ";
#else
                cout << ">, ";
#endif
            }
            p = p->arc_next;
        }
        cout << endl;
    }
}
