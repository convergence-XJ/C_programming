#ifndef MY_CRITICAL_PATH_H
#define MY_CRITICAL_PATH_H

#include <vector>
#include "MyTopologicalSort.h"

const int OK = 1;
const int ERROR = 0;

// 给定邻接表存储的有向图，求出最短运行时间，保存在run_time中，并求出所有关键活动，保存在critial_activities中
Status compute_critical_activities_and_time(const ALGraph & my_graph, int & run_time, vector<pair<int, int>>& critial_activities);

// 输出关键活动
void print_critical_activities(const ALGraph & my_graph, const vector<pair<int, int>> & critical_activities);
#endif