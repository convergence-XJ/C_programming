#include <iostream>
#include <vector>
#include "MyCriticalPath.h"

using std::cout;
using std::endl;

const int FAILURE = -1;
const int SUCCESS = 0;

#ifdef undirected_mode
const string FILE_NAME = "undirected_data_file.txt";
#else
// const string FILE_NAME = "directed_data_file.txt";
const string FILE_NAME = "directed_data_file2.txt";

#endif

int main()
{
#ifdef undirected_mode
    cout << "Below is an undirected graph" << endl;
#else
    cout << "Below is a directed graph" << endl;
#endif
    ALGraph my_graph;
    if(!create_undirected_graph(my_graph, FILE_NAME))
    {
        return FAILURE;
    }
    print_graph(my_graph);

    vector<pair<int, int>> critial_activities;
    int run_time;
    compute_critical_activities_and_time(my_graph, run_time, critial_activities);
    cout << "critical activities:" << endl;
    print_critical_activities(my_graph, critial_activities);
    cout << "run time: " << run_time << endl;
    
    destroy_graph(my_graph);
    return SUCCESS;
}