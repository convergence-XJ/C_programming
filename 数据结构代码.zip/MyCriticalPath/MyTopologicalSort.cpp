#include <iostream>
#include <vector>
#include <deque>
#include "MyTopologicalSort.h"

const int OK = 1; 
const int ERROR = 0;

// 对邻接表形式存储的有向图的顶点进行拓扑排序，把排序后各顶点的序号依次写入topo_sort_res。若my_graph有环，则排序失败
Status topologicalSort(const ALGraph & my_graph, vector<int> &topo_sort_res_in_indexes)
{
    vector<int> in_degree(my_graph.vertex_num + 1); // 给定顶点的序号，返回顶点的入度度数
    // 计算各顶点的度数，并存储在迭代器中
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        ArcNode *p = my_graph.vertices[i].arc_first;
        while(p)
        {
            in_degree[p->to_vertex_id]++; //
            p = p->arc_next; // 扫描下一条边
        }
    }

    deque<int> in_degree_0_stack; // 用堆栈，队列，甚至迭代器都可以
    // 扫描各个活动，找到无先决条件的活动
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        if(!in_degree[i]) // 入度为0，先决条件已经满足，可以执行这个活动
        {
            in_degree_0_stack.push_back(i); // 入栈
        }
    }

    // 迭代
    while(!in_degree_0_stack.empty())
    {
        // 出栈
        int i = in_degree_0_stack.back();
        in_degree_0_stack.pop_back();

        // 存入迭代器
        topo_sort_res_in_indexes.push_back(i);

        // 删除顶点和附属的边之后，相关信息需要被维护
        ArcNode* p = my_graph.vertices[i].arc_first;
        while(p)
        {
            // v被删除之后，直接后继的入度减一
            int k = p->to_vertex_id;
            in_degree[k]--;

            // 入度为0的顶点入栈
            if(!in_degree[k])
            {
                in_degree_0_stack.push_back(k);
            }

            // 扫描下一个顶点
            p = p->arc_next;
        }
    }

    if(topo_sort_res_in_indexes.size() == my_graph.vertex_num)
    {
        return OK;
    }
    else
    {
        return ERROR;
    }
}
