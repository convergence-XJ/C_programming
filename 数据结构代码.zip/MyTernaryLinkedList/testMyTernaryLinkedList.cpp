#include <iostream>
#include "MyTernaryLinkedList.h"

using namespace std;

const int SUCCESS = 0;
const int FAILURE = -1;

int main()
{
    MyTernaryLinkedList bt = NULL;
 
    // create_binary_tree(bt);
    // print_binary_tree_as_general_list(bt);
 
    string str = "A,(B,(D,(),()),(E,(),())),(C,(F,(),()),())";
    create_binary_tree(bt, str);
    cout << "bt looks like:" << endl;
    print_binary_tree_prettily(bt);
    cout << endl;
    cout << "the depth of bt is " << depth(bt) << endl;
    cout << "the node count of bt is " << node_count(bt) << endl;
    cout << "in order traverse:" << endl;
    // in_order_traverse(bt);
    in_order_traverse_nonrecursively(bt);
    cout << endl;
    cout << "pre order traverse:" << endl;
    pre_order_traverse(bt);
    cout << endl;
    cout << "post order traverse:" << endl;
    post_order_traverse(bt);
    cout << endl;
    cout << "level order traverse:" << endl;
    level_order_traverse(bt);
    cout << endl;

    MyTernaryLinkedList new_bt = NULL;
    copy_ternary_linked_list(bt, new_bt);
    cout << "another copy below:" << endl;
    print_binary_tree_prettily(new_bt);
    cout << endl;

    cout << "in this copy:" << endl;
    string my_str = "A";
    MyTernaryLinkedNode* child_ptr = address_of_data(new_bt, my_str);
    MyTernaryLinkedNode* father_ptr = address_of_parent(child_ptr);
    if(father_ptr)
    {
        cout << "the parent data of " << my_str << " is " << father_ptr->data << endl;
    }
    else
    {
        cout << "the parent data of " << my_str << " does not exist" << endl;
    }


    my_str = "E";
    child_ptr = address_of_data(new_bt, my_str);
    father_ptr = address_of_parent(child_ptr);
    if(father_ptr)
    {
        cout << "the parent data of " << my_str << " is " << father_ptr->data << endl;
    }
    else
    {
        cout << "the parent data of " << my_str << " does not exist" << endl;
    }

    string my_str1 = "A", my_str2 = "E";
    if(is_ancestor(address_of_data(new_bt, my_str1), address_of_data(new_bt, my_str2)))
    {
        cout << my_str1 << " is an ancestor of " << my_str2 << endl;
    }    
    else
    {
        cout << my_str1 << " is not an ancestor of " << my_str2 << endl;
    }

    my_str1 = "B"; my_str2 = "F";
    if(is_ancestor(address_of_data(new_bt, my_str1), address_of_data(new_bt, my_str2)))
    {
        cout << my_str1 << " is an ancestor of " << my_str2 << endl;
    }    
    else
    {
        cout << my_str1 << " is not an ancestor of " << my_str2 << endl;
    }

    my_str1 = "D"; my_str2 = "E";
    if(is_sibling(address_of_data(new_bt, my_str1), address_of_data(new_bt, my_str2)))
    {
        cout << my_str1 << " is a sibling of " << my_str2 << endl;
    }
    else
    {
        cout << my_str1 << " is not a sibling of " << my_str2 << endl;
    }
    
    my_str1 = "E"; my_str2 = "F";
    if(is_sibling(address_of_data(new_bt, my_str1), address_of_data(new_bt, my_str2)))
    {
        cout << my_str1 << " is a sibling of " << my_str2 << endl;
    }
    else
    {
        cout << my_str1 << " is not a sibling of " << my_str2 << endl;
    }

    if(!destroy_binary_tree(bt))
    {
        return FAILURE;
    }

    if(!destroy_binary_tree(new_bt))
    {
        return FAILURE;
    }

    return SUCCESS;
}