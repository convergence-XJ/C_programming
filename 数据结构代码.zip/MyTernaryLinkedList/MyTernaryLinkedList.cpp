#include <iostream>
#include <queue>
#include <deque>
#include <vector>

#include "MyTernaryLinkedList.h"

using namespace std;

const int ERROR = 0;
const int OK = 1;

// 创建二叉排序树，使bt指向其根结点，并使根结点的parent指针指向fptr所指的对象
int _create_binary_tree(MyTernaryLinkedList &bt, MyTernaryLinkedNode* fptr)
// fptr是比bt高一级的指针，(*fptr)将成为(*bt)的父结点
{
    cout << "input data for the current node, # means no data:" << endl;
    string temp_data;
    cin >> temp_data;
    if(temp_data != "#")
    {
        bt = new MyTernaryLinkedNode;
        if(!bt)
        {
            cout << "insufficient memory" << endl;
            return ERROR;
        }
        bt->data = temp_data;
        bt->lchild = NULL;
        bt->rchild = NULL;
        bt->parent = fptr; // 使父指针指向上一级的结点
        cout << "down to its left" << endl;
        if(!_create_binary_tree(bt->lchild, bt))
        {
            return ERROR;
        }
        cout << "down to its right" << endl;
        if(!_create_binary_tree(bt->rchild, bt))
        {
            return ERROR;
        }
    }
    return OK;
}


// 根据用户输入创建二叉树
int create_binary_tree(MyTernaryLinkedList &bt)
{
    if(!_create_binary_tree(bt, NULL))
    {
        return ERROR;
    }
    return OK;
}


// 以括号的形式，输出二叉树
void print_binary_tree_as_general_list(MyTernaryLinkedList &bt)
{
    if(bt)
    {
        cout << bt->data;
        cout << ",";
        cout << "(";
        print_binary_tree_as_general_list(bt->lchild);
        cout << "),";
        cout << "(";
        print_binary_tree_as_general_list(bt->rchild);
        cout << ")";
    }
}


// 给定二叉树返回数的深度
int depth(const MyTernaryLinkedList &bt)
{
    if(!bt)
    {
        return 0;
    }
    int l_dp = depth(bt->lchild); // 左子树深度
    int r_dp = depth(bt->rchild); // 右子树深度
    return l_dp > r_dp ? (l_dp + 1) : (r_dp + 1);
}


// 给定二叉树返回结点数
int node_count(MyTernaryLinkedList &bt)
{
    if(!bt)
    {
        return 0;
    }
    return node_count(bt->lchild) + node_count(bt->rchild) + 1;
}


// 根据字符串创建二叉树，使bt指向根结点，并使根结点的parent指针指向fptr所指的对象
void _create_binary_tree(MyTernaryLinkedList& bt, const string& str, MyTernaryLinkedNode* fptr)
/*fptr为bt上一级的指针，即，fptr指向的结点将成为bt指向的结点*/
{
    // 归纳基
    if(str == "")// 代表空子树
    {
        bt = NULL;
        return;
    }
    // 以下分割字符串
    int first_commas = str.find_first_of(",");
    // 父结点的字符串
    string parent_str = str.substr(0, first_commas);
    // 以下查找左子树字符串的结尾，按照括号匹配来找
    int i = first_commas + 1, level = 0;
    do{
        if(str[i] == '(')
        {
            level--;
        }
        else if(str[i] == ')')
        {
            level++;
        }
        i++;
    }while(level != 0);
    // 字符串分割
    // 左子树字符串
    string left_child_str = str.substr(first_commas + 1, i - first_commas - 1 - 1);
    left_child_str = left_child_str.substr(1, left_child_str.size() - 1);
    // 右子树字符串
    string right_child_str = str.substr(i + 1, str.size() - i - 1 - 1);
    right_child_str = right_child_str.substr(1, right_child_str.size() - 1);
    /*
    cout << parent_str << endl;
    cout << left_child_str << endl;
    cout << right_child_str << endl;
    */
    // 创建父结点
    bt = new MyTernaryLinkedNode;
    if(!bt)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    bt->lchild = NULL;
    bt->rchild = NULL;
    bt->parent = fptr; // 指向父结点
    bt->data = parent_str; // 父结点数据
    // 创建左子树
    _create_binary_tree(bt->lchild, left_child_str, bt); //
    // 创建右子树
    _create_binary_tree(bt->rchild, right_child_str, bt);
}


// 根据字符串创建二叉树，使bt指向根结点
void create_binary_tree(MyTernaryLinkedList& bt, const string& str)
{
    _create_binary_tree(bt, str, NULL);
}

// 中序遍历
void in_order_traverse(const MyTernaryLinkedList bt)
{
    if(!bt)
    {
        return;
    }
    in_order_traverse(bt->lchild);
    cout << bt->data << ", ";
    in_order_traverse(bt->rchild);
}


// 中序遍历二叉树（非递归）
void in_order_traverse_nonrecursively(const MyTernaryLinkedList bt)
{
    MyTernaryLinkedNode* p = bt;
    deque<MyTernaryLinkedList> bt_pt_stack;
    while(p || !bt_pt_stack.empty())
    // p非空表示仍有往下探索的可能
    // bt_pt_stack非空表示有往上探索的可能
    {
        if(p) // 仍有往下探索的空间
        {
            // 进栈
            bt_pt_stack.push_back(p); // 保存走过的地方，因为没有回退指针，所以只能用堆栈，类似于探索山洞的时候留个几个花生米做记号
            p = p->lchild; // 往左下走，目标是第一个要访问的结点
        }
        else
        {
            MyTernaryLinkedNode* q = bt_pt_stack.back(); // 获取栈顶元素
            bt_pt_stack.pop_back(); // 出栈
            cout << q->data << ", "; // 此时(*q)的左子树已经访问完，所以访问(*q)
            p = q->rchild; // 接下来考虑(*q)的右子树
        }
    }
}


// 前序遍历
void pre_order_traverse(const MyTernaryLinkedList bt)
{
    if(!bt)
    {
        return;
    }
    cout << bt->data << ", ";
    pre_order_traverse(bt->lchild);
    pre_order_traverse(bt->rchild);
}


// 后序遍历
void post_order_traverse(const MyTernaryLinkedList bt)
{
    if(!bt)
    {
        return;
    }
    post_order_traverse(bt->lchild);
    post_order_traverse(bt->rchild);
    cout << bt->data << ", ";
}


// 层序遍历
void level_order_traverse(const MyTernaryLinkedList bt)
{
    // 先入队的结点，先被访问
    // 而且它们的孩子也应该先被访问
    queue<MyTernaryLinkedList> que; 
    que.push(bt);
    while(!que.empty())
    {
        MyTernaryLinkedNode* p = que.front();
        que.pop();
        if(!p)
        {
            continue; // 跳过空指针
        }
        cout << p->data << ", ";
        que.push(p->lchild);
        que.push(p->rchild);
    }
}


// 复制以三叉链表为存储结构的二叉树，使得new_bt指向新产生的二叉树，
// 并使得新二叉树的根结点的parent指针指向fptr所指的对象
void _copy_ternary_linked_list(const MyTernaryLinkedList bt, MyTernaryLinkedList &new_bt, MyTernaryLinkedNode* fptr)
{
    // 归纳基
    if(!bt)
    {
        new_bt = NULL;
        return;
    }
    // 
    new_bt = new MyTernaryLinkedNode;
    if(!new_bt)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    // 复制结点数据
    new_bt->data = bt->data;
    new_bt->lchild = new_bt->rchild = NULL;
    new_bt->parent = fptr;
    // 复制子树
    _copy_ternary_linked_list(bt->lchild, new_bt->lchild, new_bt);
    _copy_ternary_linked_list(bt->rchild, new_bt->rchild, new_bt);
}


// 复制以三叉链表为存储结构的二叉树
void copy_ternary_linked_list(const MyTernaryLinkedList bt, MyTernaryLinkedList &new_bt)
{
    _copy_ternary_linked_list(bt, new_bt, NULL);
}


// 求每个结点指针的父结点指针（根结点除外）
void get_parents_for_nodes(const MyTernaryLinkedList &bt, map<MyTernaryLinkedList, MyTernaryLinkedList> &child2Parent)
{
    if(!bt)
    {
        return;
    }
    // 存在左孩子
    if(bt->lchild)
    {
        child2Parent[bt->lchild] = bt;
    }
    // 存在右孩子
    if(bt->rchild)
    {
        child2Parent[bt->rchild] = bt;
    }
    // 递归
    get_parents_for_nodes(bt->lchild, child2Parent);
    get_parents_for_nodes(bt->rchild, child2Parent);
}


void _get_levels_for_nodes(const MyTernaryLinkedList &bt, map<MyTernaryLinkedList, int> &node2Level)
{
    if(!bt)
    {
        return;
    }
    // 存在左孩子
    if(bt->lchild)
    {
        node2Level[bt->lchild] = node2Level[bt] + 1; // 层数加1
    }
    // 存在右孩子
    if(bt->rchild)
    {
        node2Level[bt->rchild] = node2Level[bt] + 1; // 层数加1
    }
    // 递归调用
    _get_levels_for_nodes(bt->lchild, node2Level);
    _get_levels_for_nodes(bt->rchild, node2Level);
}

void get_levels_for_nodes(const MyTernaryLinkedList &bt, map<MyTernaryLinkedList, int> &node2Level)
{
    if(!bt)
    {
        return; // 
    }
    node2Level[bt] = 1; // 根结点的层数规定为1
    _get_levels_for_nodes(bt, node2Level);
}


// 层序保存指针
void get_level_order_pointers(const MyTernaryLinkedList bt, vector<MyTernaryLinkedList>& vecOfNodePtr)
{
    queue<MyTernaryLinkedList> que;
    que.push(bt);
    while(!que.empty())
    {
        MyTernaryLinkedNode* p = que.front();
        que.pop();
        if(!p)
        {
            continue;
        }
        vecOfNodePtr.push_back(p); // 指针进入迭代器
        que.push(p->lchild);
        que.push(p->rchild);
    }
}


// 给定二叉树，计算每一个层的相邻两结点之间的间距
void get_node_distances(const MyTernaryLinkedList &bt, vector<int>& level2PositionDistance)
{
    int dp = depth(bt);
    int two2Dp = 1;
    for(int i = 0; i < dp; i++)
    {
        two2Dp *= 2; // 2^{dp}
    }
    level2PositionDistance.push_back(two2Dp * 2);
    for(int i = 1; i <= dp; i++)
    {
        // 每层相邻两个位置的间距，注意倍增关系
        level2PositionDistance.push_back(level2PositionDistance[i-1] / 2); 
    }
}


// 
// 给定根结点所在的位置，求每一个结点在它所在的层的位置
void _get_positions_for_nodes(const MyTernaryLinkedList &bt, map<MyTernaryLinkedList, int> &node2Position, map<MyTernaryLinkedList, int> &node2Level, vector<int> &level2PositionDistance)
{
    if(bt->lchild)
    {
        // 父结点与孩子结点之间的位置关系
        node2Position[bt->lchild] = node2Position[bt] - level2PositionDistance[node2Level[bt->lchild]] / 2;
        _get_positions_for_nodes(bt->lchild, node2Position, node2Level, level2PositionDistance);
    }
    if(bt->rchild)
    {
        // 父结点与孩子结点之间的位置关系
        node2Position[bt->rchild] = node2Position[bt] + level2PositionDistance[node2Level[bt->rchild]] / 2;
        _get_positions_for_nodes(bt->rchild, node2Position, node2Level, level2PositionDistance);
    }
}


// 给定二叉树，求各个结点在它所在的层的位置
void get_positions_for_nodes(const MyTernaryLinkedList &bt, map<MyTernaryLinkedList, int> &node2Level, map<MyTernaryLinkedList, int> &node2Position)
{
    if(!bt)
    {
        return;
    }
    get_levels_for_nodes(bt, node2Level);
    vector<int> level2PositionDistance;
    get_node_distances(bt, level2PositionDistance);
    node2Position[bt] = level2PositionDistance[1] / 2;
    _get_positions_for_nodes(bt, node2Position, node2Level, level2PositionDistance);
}


// 直观地输出二叉树
void print_binary_tree_prettily(const MyTernaryLinkedList &bt)
{
    vector<MyTernaryLinkedList> vecOfNodePtrInLevelOrder; // 结点按层序排列
    get_level_order_pointers(bt, vecOfNodePtrInLevelOrder);
    map<MyTernaryLinkedList, int> node2Level; // 每个结点所在的层
    map<MyTernaryLinkedList, int> node2Position; // 每个结点在某层的位置
    get_positions_for_nodes(bt, node2Level, node2Position);
    // 初始化有利于后面的循环
    int last_node_level = 1;
    int last_node_position = 0; 
    // 按层序输出结点
    for(int i = 0; i < vecOfNodePtrInLevelOrder.size(); i++)
    {
        MyTernaryLinkedList curr_tr = vecOfNodePtrInLevelOrder[i]; // 此刻要输出的结点
        if(node2Level[curr_tr] != last_node_level) // 进入下一层
        {
            last_node_position = 0; // 光标回到行首
            last_node_level++; // 更新所在的层
            cout << endl;
        }
        for(int j = last_node_position + 1; j < node2Position[curr_tr]; j++)
        {
            // cout << "\t\t"; // 输出若干个空位
            cout << "   ";
        }
        last_node_position = node2Position[curr_tr]; // 记住刚刚输出的结点的位置
        // cout << "\t" << curr_tr->data << "\t";
        cout << " " << curr_tr->data << " ";
    }
}


// 给定二叉树和数据元素，返回它所在的某个结点的地址，若相应结点不存在，则返回空指针
MyTernaryLinkedNode* address_of_data(const MyTernaryLinkedList bt, const string& data)
{
    if(!bt) // 空树不存在存储data的结点
    {
        return NULL;
    }
    if(bt->data == data) // 根结点存储了data
    {
        return bt;
    }
    MyTernaryLinkedNode* p = address_of_data(bt->lchild, data); // 在左子树中查找
    if(p) // 存在即返回
    {
        return p;
    }
    p = address_of_data(bt->rchild, data); // 在右子树中查找
    return p; // 有无都返回
}

// 给定指向二叉树某结点的指针，求指向它的父结点的指针，若父结点不存在，则返回空指针。若p为空指针，则返回空。
MyTernaryLinkedNode* address_of_parent(const MyTernaryLinkedNode* p)
{
    if(!p) // 传入空指针
    {
        cout << "NULL pointer does not correspond to a father pointer" << endl;
        return NULL; // 
    }
    
    return p->parent;
}

// 给定二叉树和两个结点指针，判断前一指针所指对象是否后一指针所指对象的祖先。如果是，则返回真，否则返回假。（若某一指针为空，也返回假。）
bool is_ancestor(const MyTernaryLinkedNode* p, const MyTernaryLinkedNode* q)
{
    if(!p || !q)
    {
        cout << "one of the two pointers is null" << endl;
        return false;
    }
    const MyTernaryLinkedNode* r = q; // 指向孩子结点
    while(r && r != p) // 只要所指非空，并且没有寻到p
    {
        r = r->parent; // 往上追溯
    }
    if(!r) // 走到了尽头
    {
        return false;
    }
    return true;
}

// 给定二叉树和两个结点指针，判断前一指针所指对象是否后一指针所指对象的兄弟。如果是，则返回真，否则返回假。（若某一指针为空，也返回假。）
bool is_sibling(const MyTernaryLinkedNode* p, const MyTernaryLinkedNode* q)
{
    if(!p || !q)
    {
        cout << "one of the two pointers is null" << endl;
        return false;
    }
    return p->parent == q->parent; // 有共同的父亲
}


// 销毁根指针非空的二叉树
void _destroy_binary_tree(const MyTernaryLinkedList &bt)
{
    if(bt->lchild)
    {
        _destroy_binary_tree(bt->lchild);
    }
    if(bt->rchild)
    {
        _destroy_binary_tree(bt->rchild);
    }
    delete bt;
}

// 销毁二叉树
int destroy_binary_tree(const MyTernaryLinkedList &bt)
{
    if(!bt)
    {
        return ERROR;
    }
    _destroy_binary_tree(bt);
    return OK;
}
