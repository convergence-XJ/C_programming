#include <iostream>
#include "MyBinaryTree.h"

using namespace std;

const int SUCCESS = 0;
const int FAILURE = -1;

int main()
{
    MyBinaryTree bt = NULL;
 
    // create_binary_tree(bt);
    // print_binary_tree_as_general_list(bt);
 
    string str = "A,(B,(D,(),()),(E,(),())),(C,(F,(),()),())";
    create_binary_tree(bt, str);
    cout << "bt looks like:" << endl;
    print_binary_tree_prettily(bt);
    cout << endl;
    cout << "the depth of bt is " << depth(bt) << endl;
    cout << "the node count of bt is " << node_count(bt) << endl;
    cout << "in order traverse:" << endl;
    // in_order_traverse(bt);
    in_order_traverse_nonrecursively(bt);
    cout << endl;
    cout << "pre order traverse:" << endl;
    pre_order_traverse(bt);
    cout << endl;
    cout << "post order traverse:" << endl;
    post_order_traverse(bt);
    cout << endl;
    cout << "level order traverse:" << endl;
    level_order_traverse(bt);
    cout << endl;

    MyBinaryTree new_bt = NULL;
    copy_binary_tree(bt, new_bt);
    cout << "another copy below:" << endl;
    print_binary_tree_prettily(new_bt);
    cout << endl;

    if(!destroy_binary_tree(bt))
    {
        return FAILURE;
    }

    if(!destroy_binary_tree(new_bt))
    {
        return FAILURE;
    }

    return SUCCESS;
}