#include <iostream>
#include "MyLinkedQueue.h"

using namespace std;

const int FAILURE = -1;

MyLinkedQueue::MyLinkedQueue()
{
    front = rear = new MyLinkedQueueNode; // 创建哨兵结点
    if(!front)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    front->set_next_pointer(NULL); // 哨兵结点后面没有元素，故指针域的值设为空
    que_size = 0;
}

// 入队
void MyLinkedQueue::enQueue(int data)
{
    MyLinkedQueueNode* p = new MyLinkedQueueNode;
    if(!p)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    p->set_data(data); // 设置数据域
    p->set_next_pointer(NULL); // 最为元素指针域的值为空
    rear->set_next_pointer(p); // 接上
    rear = p; // 维护尾指针
    que_size++;
}


// 出队
int MyLinkedQueue::deQueue()
{
    if(empty()) // 队列为空，无法执行操作
    {
        cout << "underflow" << endl;
        exit(FAILURE);
    }
    MyLinkedQueueNode *p = front->get_next_pointer(); // 指向即将出队的元素所在的结点
    front->set_next_pointer(p->get_next_pointer()); // 绕过p所指的结点
    int data = p->get_data();
    delete p;
    que_size--;
    return data;
}

// 销毁队列
MyLinkedQueue::~MyLinkedQueue()
{
    while(front->get_next_pointer()) // 队列中仍有元素
    {
        deQueue(); // 出队
    }
    delete front; // 销毁哨兵结点
}

void MyLinkedQueue::show()
{
    MyLinkedQueueNode* p = front->get_next_pointer();
    while(p)
    {
        cout << p->get_data() << "\t";
        p = p->get_next_pointer();
    }
}
