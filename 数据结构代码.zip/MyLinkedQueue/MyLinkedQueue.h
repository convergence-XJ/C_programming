#ifndef MY_LINKED_QUEUE_H
#define MY_LINKED_QUEUE_H

#include <cstddef>

class MyLinkedQueueNode{ // 链队结点

    private:
        int data; // 数据域
        MyLinkedQueueNode* next; // 指针域

    public: 

        // 数据操作
        int get_data()
        {
            return data;
        }

        void set_data(int v)
        {
            data = v;
        }

        // 指针操作
        MyLinkedQueueNode* get_next_pointer()
        {
            return next;
        }

        void set_next_pointer(MyLinkedQueueNode * p)
        {
            next = p;
        }
};

class MyLinkedQueue{ // 链队结构，在队列最开头设置哨兵结点

    private:
        MyLinkedQueueNode* front; // 指向哨兵结点
        MyLinkedQueueNode* rear; // 指向队列的最后一个结点
        size_t que_size;

    public:
        // 构造函数
        MyLinkedQueue();

        // 析构函数
        ~MyLinkedQueue();

        // 判断队列是否为空
        bool empty()
        {
            return !que_size;
        }

        // 入队
        void enQueue(int data);

        // 出队
        int deQueue();

        // 返回队列中元素个数
        size_t get_size()
        {
            return que_size;
        }

        // 输出队列中的元素
        void show();
};



#endif