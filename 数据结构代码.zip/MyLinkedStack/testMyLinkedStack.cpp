#include <iostream>
#include "MyLinkedStack.h"

using namespace std;

const int SUCCESS = 0;

int main()
{
    MyLinkedStack stk;
    if(stk.empty())
    {
        cout << "This is an empty stack" << endl;
    }
    else
    {
        cout << "This is a non-empty stack" << endl;
    }
    
    stk.push(2); stk.push(3); stk.push(5); stk.push(7);
    cout << "after several 'push' operations, the contents of this stack:" << endl;
    stk.show();
    cout << endl;
    cout << "the number of elements in the stack is " << stk.get_size() << endl;
    int data = stk.pop();
    cout << data << " is popped" << endl;
    cout << "the contents become: " << endl;
    stk.show();

    if(stk.empty())
    {
        cout << "Now this is an empty stack" << endl;
    }
    else
    {
        cout << "Now this is a non-empty stack" << endl;
    }
    return SUCCESS;
}