#include <iostream>
#include "MyLinkedStack.h"

using namespace std;

const int FALIURE = -1;


// 设定头指针的指向
MyLinkedStack::MyLinkedStack()
{
    head = NULL;
    stack_sz = 0;
}

// 入栈
void MyLinkedStack::push(const int data)
{
    MyLinkedStackNode* p = new MyLinkedStackNode; // 运算符重载，销毁栈结点
    if(!p)
    {
        cout << "insufficient memory" << endl;
        exit(-1);
    }
    p->set_data(data); // 设置数据域
    p->set_next_pointer(head); // 设置指针域
    head = p; // 维护head
    stack_sz++;
}

// 出栈，并返回出栈的数据元素的值
int MyLinkedStack::pop()
{
    if(empty())
    {
        cout << "underflow" << endl;
        exit(FALIURE);
    }
    int data = head->get_data(); // 获取数据（注意要在回收内存之前）
    MyLinkedStackNode *p = head;
    head = head->get_next_pointer();
    delete p; // 运算符重载，销毁栈结点
    stack_sz--; // 维护stack_sz
    return data;
}

// 销毁堆栈
MyLinkedStack::~MyLinkedStack()
{
    while (!empty()) // 链栈中仍有元素
    {
        pop(); // 出栈
    }
}

// 显示堆栈内容
void MyLinkedStack::show()
{
    MyLinkedStackNode* p = head;
    while(p)
    {
        cout << p->get_data() << endl;
        p = p->get_next_pointer();
    }
}