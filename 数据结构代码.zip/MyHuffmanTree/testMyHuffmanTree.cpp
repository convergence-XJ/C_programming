#include <iostream>
#include "MyHuffmanTree.h"

using namespace std;

int main()
{
    // 已知 w = (5,29,7,8,14,23,3,11), 构造一棵哈夫曼树
    int w[] = {5, 29, 7, 8, 14, 23, 3, 11};
    int num_of_elements = sizeof(w) / sizeof(int);
    MyHuffmanTree htree;
    // 创建哈夫曼树
    create_huffman_tree(htree, w, num_of_elements);
    HuffmanCode hc;
    // 生成哈夫曼编码
    generateHuffmanCode(htree, hc, num_of_elements);
    cout << "Huffman Codes for each character:" << endl;
    for(int i = 1; i <= num_of_elements; i++)
    {
        cout << hc[i] << endl;
    }
    // 最小的带权路径长度
    cout << "weighted path len: " << weighted_path_length(htree, w, num_of_elements) << endl;

    // 销毁哈夫曼树
    destroy_huffman_tree(htree);
    // 销毁哈夫曼编码
    destroy_huffman_code(hc, num_of_elements);
    return 0;
}