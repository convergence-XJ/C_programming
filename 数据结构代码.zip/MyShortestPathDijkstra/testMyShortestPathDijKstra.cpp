#include <iostream>
#include <string>

#include "MyAdjacencyMatrix.h"
#include "MyShortestPathDijKstra.h"

const int SUCCESS = 0;
const string FILE_NAME = "data_file.txt";

using namespace std;

int main()
{
    AMGraph my_graph;
    create_undirected_network(my_graph, FILE_NAME);
    print_undirected_network(my_graph);
    vector<pair<int, int>> shortest_path_info = shortest_path_dijkstra(my_graph, locate_vertex(my_graph, "v0"));
/*
    for(vector<pair<int, int>>::iterator iter = shortest_path_info.begin() + 1; iter != shortest_path_info.end(); iter++)
    {
        cout << my_graph.vertices[iter - shortest_path_info.begin()] << ": ";
        if(iter->first == -1)
        {
            cout << -1;
        }
        else
        {
            cout << my_graph.vertices[iter->first];
        }
        
        cout << ", " << iter->second << endl;
    }
*/
    // 打印最短路径信息
    print_shortest_path(my_graph, locate_vertex(my_graph, "v0"), locate_vertex(my_graph, "v5"), shortest_path_info);

    print_shortest_path(my_graph, locate_vertex(my_graph, "v0"), locate_vertex(my_graph, "v2"), shortest_path_info);
    return SUCCESS;
}