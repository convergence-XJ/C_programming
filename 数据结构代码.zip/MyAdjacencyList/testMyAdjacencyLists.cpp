#include <iostream>
#include "MyAdjacencyList.h"

using std::cout;
using std::endl;

const int FAILURE = -1;
const int SUCCESS = 0;

#ifdef undirected_mode
const string FILE_NAME = "undirected_data_file.txt";
#else
const string FILE_NAME = "directed_data_file.txt";
#endif

int main()
{
#ifdef undirected_mode
    cout << "Below is an undirected graph" << endl;
#else
    cout << "Below is a directed graph" << endl;
#endif
    ALGraph my_graph;
    if(!create_undirected_graph(my_graph, FILE_NAME))
    {
        return FAILURE;
    }
    print_undirected_graph(my_graph);
    cout << "below are dfs results:" << endl;
    dfs_traverse(my_graph);
    cout << endl;
    cout << "below are bfs results:" << endl;
    bfs_traverse(my_graph);
    cout << endl;
    destroy_undirected_graph(my_graph);
    return SUCCESS;
}