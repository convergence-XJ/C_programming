#ifndef MY_ADJACENCY_LIST
#define MY_ADJACENCY_LIST

#include <string>
using namespace std;

// #define undirected_mode

typedef string VertexType;

typedef struct ArcNode{ // 边结点
    int to_vertex_id; // 指向的结点（有向图），或邻居结点（无向图）
    struct ArcNode* arc_next; // 指向下一个边结点元素的指针
    int data; // 数据
} ArcNode; // 边结点

typedef struct VertexNode{ //顶点结点
    VertexType data; // 顶点保存的数据
    ArcNode* arc_first; // 指向第一条边的指针
} VertexNode, *AdjacencyList; // 用于模拟顶点结点组成的数组

typedef struct ALGraph{ // 利用邻接表存储的图
    AdjacencyList vertices; // 用于模拟顶点结点组成的数组
    int vertex_num, arc_num; // 顶点数和边数
} ALGraph;


// 利用邻接表创建无向图
int create_undirected_graph(ALGraph &my_graph);

// 利用邻接表创建无向图，根据文件提供的数据
int create_undirected_graph(ALGraph &my_graph, const string file_name);

// 销毁邻接表构建的无向图
void destroy_undirected_graph(ALGraph& my_graph);

// 打印邻接表构建的无向图
void print_undirected_graph(const ALGraph& my_graph);

// 深度优先访问非连通图，my_graph为邻接矩阵类型
int dfs_traverse(ALGraph &my_graph);

// 广度优先访问非连通图，my_graph为邻接矩阵类型
int bfs_traverse(ALGraph &my_graph);

#endif