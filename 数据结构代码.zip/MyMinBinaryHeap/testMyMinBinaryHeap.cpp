#include "MyMinBinaryHeap.h"

const int SUCCESS = 0;

int main()
{
    int a[] = {1, 3, 4, 2, 12, 11, 10, 14, 13, 19, 18};
    MyMinBinaryHeap min_heap(a, 11);
    min_heap.show();
    int data = min_heap.get_minimum();
    cout << "the smallest element in this heap is " << data << endl;
    min_heap.insert(17);
    min_heap.insert(16);
    cout << "after inserting 17 and then  16, we have " << endl;
    min_heap.show();
    cout << endl;
    cout << "extract " << min_heap.extract_min() << endl;
    cout << "the heap becomes " << endl;
    min_heap.show();
    cout << "extract " << min_heap.extract_min() << endl;
    cout << "the heap becomes " << endl;
    min_heap.show();
    min_heap.insert(7);
    min_heap.insert(2);
    cout << "after inserting 7 and then 2, we have " << endl;
    min_heap.show();
    return SUCCESS;
}