#include <iostream>
#include <cstdlib>
#include <ctime>
#include "MyVector.h"

const int FAILURE = -1;

// 无参构造函数
MyVector::MyVector()
{
    array_capacity = INIT_CAPACITY;
    arr = new int[array_capacity + 1]; // 0号元素不用
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    array_size = 0;
}

// 带参构造函数
MyVector::MyVector(int *a, int sz)
{
    // 确定容量
    array_capacity = INIT_CAPACITY > sz ? INIT_CAPACITY : sz;
    // 分配空间
    arr = new int[array_capacity + 1]; // 因为0号单元不用，所以多一个空间
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    // 复制
    for(int i = 1; i <= sz; i++)
    {
        arr[i] = a[i-1]; // 注意到数组的0号元素是使用的
    }
    array_size = sz; // 维护数组大小
}

// 析构函数
MyVector::~MyVector()
{
    delete[] arr;
}

// 取值
int MyVector::get_element(int i, int &e)
/*返回下标为i的元素（即第i+1个元素）的值*/
{
    if(i < 1 || i > array_size) // 访问越界
    {
        return ERROR;
    }
    e = arr[i];
    return OK;
}

// 定位
int MyVector::locate_element(int e)
/*返回最后一个值为e的元素的下标；若满足条件的元素不存在，则返回0，*/
{
    int i;
    // 从后往前搜查
    for(i = array_size; i >= 1; i--)
    {
        if(arr[i] == e) // 找到
        {
            break;
        }
    }
    return i;
}

// 插入
int MyVector::insert_element(int i, int e)
/*在下标为i的位置之前插入元素e，i的范围是[1, array_size+1]*/
{
    if(i < 1 || i > array_size + 1) // 这里特别允许在所有元素之后插入
    {
        return ERROR; // 不在合法范围内
    }
    
    if(array_capacity < array_size + 1) // 容量不足
    {
        
        int* new_arr = new int[array_capacity * 2 + 1]; // 分配空间
        if(!new_arr)
        {
            cout << "insufficient memory" << endl;
            exit(FAILURE);
        }
        array_capacity *= 2; // 容量增大为2倍
        int j;
        // 把前面i个旧元素复制过去
        for(j = 1; j <= i - 1; j++)
        {
            new_arr[j] = arr[j];
        }
        new_arr[j++] = e; // 插入元素
        for(; j <= array_size + 1; j++)
        {
            new_arr[j] = arr[j - 1]; // 复制发生偏移
        }
        delete[] arr; // 销毁原数组
        arr = new_arr; // 关联新数组
    }
    else
    {
        for(int j = array_size; j >= i; --j)
        {
            arr[j + 1] = arr[j]; // 元素后移，包括下标为i的元素
        }
        arr[i] = e;
    }
    array_size++;
    return OK;
}

// 删除
int MyVector::delete_element(int i)
/*删除下标为i的元素*/
{
    if(i < 1 || i > array_size)
    {
        return ERROR;
    }
    // 下标从i+1开始是后面的元素，直到最后一个
    for(int j = i + 1; j <= array_size; j++)
    {
        arr[j - 1] = arr[j]; // 前移
    }
    array_size--;
    return OK;
}

// 往迭代器末端添加元素e
void MyVector::push_back(int e)
{
    // 可能需要调整容量
    if(array_size == array_capacity)
    {
        int* new_arr = new int[array_capacity * 2 + 1]; // 分配空间
        if(!new_arr)
        {
            cout << "insufficient memory" << endl;
            exit(FAILURE);
        }
        array_capacity *= 2; // 容量增大为2倍
        // 把前面i个旧元素复制过去
        for(int j = 1; j <= array_size; j++)
        {
            new_arr[j] = arr[j];
        }
        delete[] arr; // 销毁原数组
        arr = new_arr; // 关联新数组
    }
    arr[++array_size] = e;
}

// 打印
void MyVector::show()
{
    for(int i = 1; i <= array_size; i++)
    {
        cout << arr[i] << '\t';
    }
}

// 取增量为dk，做一趟希尔插入排序
void MyVector::shell_insertion_sort(int dk)
{
    // 注意到增量为dk的子序列有dk个，所以要循环
    for (int i = 1 + dk; i <= array_size; i++)
    {
        if(i > 2 * dk) // 按增量获取子序列，增量为dk的子序列只能有dk个
        {
            continue; // 跳过
        }
        if(arr[i] < arr[i - dk]) // 
        {
            // 以下考虑下标为i的元素所在的，增量为dk的子序列
            arr[0] = arr[i]; // 保存arr[i]的值
            int j = i -dk; // 即将搜索arr[0]的值应该插入的位置，j为搜索的起点
            while (j > 0 && arr[j] > arr[0]) // j为数组的有效位置，并且a[0]（待插入的值）应该在a[j]之前
            {
                arr[j + dk] = arr[j]; // 后移，以便挪出空间
                j -= dk; // 继续往前探索
            }
            arr[j + dk] = arr[0]; // 插入，注意到之前有一个-=操作，这里要加回来
        }
    }
}

/*希尔排序*/
void MyVector::shell_sort()
{
    int dk = array_size / 2;
    do
    {
        shell_insertion_sort(dk);
        dk /= 2; // Shell最初的方案
        // dk = dk / 3 + 1; // Knuth的方案 
    } while (dk); // dk的最后一次有效取值必为1
    
}