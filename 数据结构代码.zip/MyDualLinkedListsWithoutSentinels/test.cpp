#include <stdio.h>
#include <vector>
#include "MyDualLinkedListsWithoutSentinels.h"

using namespace std;

const int FAILURE = -1; // main()函数运行正常异常返回

int main()
{
    Du_Linked_List lst1 = NULL, lst2 = NULL; // 暂时没有明确值，先赋值为NULL保安全

    int a1[] = {1, 2, 3, 4, 5};
    int a2[] = {6, 5, 4, 3, 2, 1};
    
    vector<int> vecOfData1(a1, a1 + sizeof(a1) / sizeof(int));
    vector<int> vecOfData2(a2, a2 + sizeof(a2) / sizeof(int));

    if(!create_list_from_head_to_tail(lst1, vecOfData1)) 
    {
        return FAILURE; // 返回值非0都表示程序运行异常
    }
        
    printf("lst1:\n");
    print_list(lst1);
    printf("\n");

    if(!create_list_from_tail_to_head(lst2, vecOfData2)) 
    {
        return FAILURE;
    }
        
    printf("lst2:\n");
    print_list(lst2);
    printf("\n");

    int v;
    // query lst1
    if(get_element(lst1, 3, v)) // 获取lst1的第3个元素，把值保存在v中
    {
        printf("The 3rd element in lst1 is %d\n", v);
    }
    else
    {
        printf("The 3rd element in lst2 is not found.\n");
    }
    // query lst2
    if(get_element(lst2, 2, v)) // 获取lst2列表的第2个元素，把值保存在v中
    {
        printf("The 2nd element in lst1 is %d\n", v);
    }
    else
    {
        printf("The 2nd element in st2 is not found.\n");
    }

    // insertion
    if(!list_insert(lst1, 2, 7))
    {
        return FAILURE;
    }
    if(!list_insert(lst1, 1, 10))
    {
        return FAILURE;
    }
    if(!list_insert(lst2, 4, 8))
    {
        return FAILURE;
    }

    printf("after inserting 7 into the 2nd location and then 10 into the 1st in lst1:\n");
    print_list(lst1);
    printf("\n");

    printf("after inserting 8 into the 4th location in lst2:\n");
    print_list(lst2);
    printf("\n");

    // location
    DuNode* p = locate_element(lst1, 3);
    if(p)
    {
        if(p->prev != lst1)
        {
            printf("The predecessor of 3 in lst1 is %d\n", p->prev->data);
        }
        if(p->next != lst1)
        {
            printf("The successor of 3 in lst1 is %d\n", p->next->data);
        }
    }
    else
    {
        printf("3 is not found is lst1\n");
    }
    
    p = locate_element(lst2, 7);
    if(p)
    {
        if(p->prev != lst2)
        {
            printf("The predecessor of 7 is lst2 is %d\n", p->prev->data);
        }
        if(p->next != lst2)
        {
            printf("The successor of 7 in lst2 is %d\n", p->next->data);
        }
    }
    else
    {
        printf("7 is not found is lst2\n");
    }

    // deletion
    if(!list_delete(lst1, 4)) 
    {
        return FAILURE;
    }
    if(!list_delete(lst2, 5)) 
    {
        return FAILURE;
    }

    printf("after deleting the 4-th element, lst1 has become:\n");
    print_list(lst1); 
    printf("\n");

    printf("after deleting the 5-th element, lst2 has become:\n");
    print_list(lst2);
    printf("\n");
    
    // 回收空间
    if(!destroy_list(lst2)) 
    {
        return FAILURE;
    }
    lst2 = NULL;
    if(!destroy_list(lst1)) 
    {
        return FAILURE;
    }
    lst1 = NULL; // 收好指针，防止误操作
    return 0;
}