#ifndef DUAL_LINKED_LISTS_WITHOUT_SENTINELS_H
#define DUAL_LINKED_LISTS_WITHOUT_SENTINELS_H

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>

const int OK = 1; // 涉及指针和内存分配的函数，运行正常返回
const int ERROR = 0; // 运行异常返回

typedef struct DuNode{
    int data;
    DuNode* prev;
    DuNode* next;
} DuNode, *Du_Linked_List;

/*给定不带哨兵结点的双链表list，输出各个元素的值*/
void print_list(Du_Linked_List list);

//在不带哨兵结点的双链表list中，
//根据序号i获取元素的值，用v返回链表中第i个数据元素的值
int get_element(const Du_Linked_List list, int i, int &v);

//在不带哨兵结点的双链表list中，查找值为v的元素，如找到返回结点的地址，否则返回NULL
DuNode *locate_element(const Du_Linked_List list, int v);

//在不带哨兵结点的双链表list中，第i个位置插入值为v的新结点（新结点成为第i个结点）
int list_insert(Du_Linked_List &list, int i, int v);

/*在不带哨兵结点的非循环双链表list中，在p_to_successor指针所指的结点之前，插入p_to_inserted指针所指的结点*/
int list_insert_before(Du_Linked_List &list, DuNode *p_to_inserted, DuNode* p_to_successor);

/*在不带哨兵结点的非循环双链表中，在p_to_predecessor指针所指的结点之后，插入p_to_inserted指针所指的结点*/
int list_insert_after(Du_Linked_List &list, DuNode *p_to_inserted, DuNode* p_to_predecessor);

//在不带哨兵结点的双链表list中，删除第i个元素
int list_delete(Du_Linked_List list, int i);

//逆序输入n个元素的值，建立不带表哨兵结点的双链表list
int create_list_from_tail_to_head(Du_Linked_List &list, int n);

//逆序输入元素的值，建立不带表哨兵结点的双链表list，数据来源于迭代器
int create_list_from_tail_to_head(Du_Linked_List &list, const std::vector<int> &vecOfData);

//顺序输入n个元素的值，建立不带表哨兵结点的双链表list
int create_list_from_head_to_tail(Du_Linked_List & list, int n);

//顺序输入元素的值，建立不带表哨兵结点的双链表list，数据来源于迭代器
int create_list_from_head_to_tail(Du_Linked_List & list, const std::vector<int> &vecOfData);

/*给定不带哨兵结点的非循环双链表list，销毁它并回收空间*/
int destroy_list(Du_Linked_List list);

#endif
