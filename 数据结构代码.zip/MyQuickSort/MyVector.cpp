#include <iostream>
#include <cstdlib>
#include <ctime>
#include "MyVector.h"

const int FAILURE = -1;

// 无参构造函数
MyVector::MyVector()
{
    array_capacity = INIT_CAPACITY;
    arr = new int[array_capacity + 1]; // 0号元素不用，或者说arr[0]是闲置空间
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    array_size = 0;
}

// 带参构造函数
MyVector::MyVector(int *a, int sz)
{
    // 确定容量
    array_capacity = INIT_CAPACITY > sz ? INIT_CAPACITY : sz;
    // 分配空间
    arr = new int[array_capacity + 1]; // 因为0号单元不用，所以多一个空间
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    // 复制
    for(int i = 1; i <= sz; i++)
    {
        arr[i] = a[i-1]; // 注意到数组的0号元素是使用的
    }
    array_size = sz; // 维护数组大小
}

// 析构函数
MyVector::~MyVector()
{
    delete[] arr;
}

// 取值
int MyVector::get_element(int i, int &e)
/*返回下标为i的元素（即第i+1个元素）的值*/
{
    if(i < 1 || i > array_size) // 访问越界
    {
        return ERROR;
    }
    e = arr[i];
    return OK;
}

// 定位
int MyVector::locate_element(int e)
/*返回最后一个值为e的元素的下标；若满足条件的元素不存在，则返回0，*/
{
    int i;
    // 从后往前搜查
    for(i = array_size; i >= 1; i--)
    {
        if(arr[i] == e) // 找到
        {
            break;
        }
    }
    return i;
}

// 插入
int MyVector::insert_element(int i, int e)
/*在下标为i的位置之前插入元素e，i的范围是[1, array_size+1]*/
{
    if(i < 1 || i > array_size + 1) // 这里特别允许在所有元素之后插入
    {
        return ERROR; // 不在合法范围内
    }
    
    if(array_capacity < array_size + 1) // 容量不足
    {
        
        int* new_arr = new int[array_capacity * 2 + 1]; // 分配空间
        if(!new_arr)
        {
            cout << "insufficient memory" << endl;
            exit(FAILURE);
        }
        array_capacity *= 2; // 容量增大为2倍
        int j;
        // 把前面i个旧元素复制过去
        for(j = 1; j <= i - 1; j++)
        {
            new_arr[j] = arr[j];
        }
        new_arr[j++] = e; // 插入元素
        for(; j <= array_size + 1; j++)
        {
            new_arr[j] = arr[j - 1]; // 复制发生偏移
        }
        delete[] arr; // 销毁原数组
        arr = new_arr; // 关联新数组
    }
    else
    {
        for(int j = array_size; j >= i; --j)
        {
            arr[j + 1] = arr[j]; // 元素后移，包括下标为i的元素
        }
        arr[i] = e;
    }
    array_size++;
    return OK;
}

// 删除
int MyVector::delete_element(int i)
/*删除下标为i的元素*/
{
    if(i < 1 || i > array_size)
    {
        return ERROR;
    }
    // 下标从i+1开始是后面的元素，直到最后一个
    for(int j = i + 1; j <= array_size; j++)
    {
        arr[j - 1] = arr[j]; // 前移
    }
    array_size--;
    return OK;
}

// 清空迭代器的数据
void MyVector::clear()
{
    array_size = 0;
}

// 往迭代器末端添加元素e
void MyVector::push_back(int e)
{
    // 可能需要调整容量
    if(array_size == array_capacity)
    {
        int* new_arr = new int[array_capacity * 2 + 1]; // 分配空间
        if(!new_arr)
        {
            cout << "insufficient memory" << endl;
            exit(FAILURE);
        }
        array_capacity *= 2; // 容量增大为2倍
        // 把前面i个旧元素复制过去
        for(int j = 1; j <= array_size; j++)
        {
            new_arr[j] = arr[j];
        }
        delete[] arr; // 销毁原数组
        arr = new_arr; // 关联新数组
    }
    arr[++array_size] = e;
}

// 打印
void MyVector::show()
{
    for(int i = 1; i <= array_size; i++)
    {
        cout << arr[i] << '\t';
    }
}

// 交换两个整型变量所存储的数据
void swap(int &x, int &y) // 注意这里使用了引用
{
    int temp = x;
    x = y;
    y = temp;
}

// 把迭代器的子表arr[low ... high]一分为二，并返回轴枢的位置
int MyVector::partition(int low, int high)
// 在排序中arr[0]被用于临时存放轴枢
{
    // 注意到快速排序中，轴枢的选择是非常有技巧的，这里只为了说明问题，因而简单处理
    int rand_loc = low + rand() % (high - low + 1); // 在low和high（含端点）之间随机选择一个位置
    swap(&arr[rand_loc], &arr[low]); // 交换是为了确保轴枢的选择具有随机性，从而加强了排序效率的稳定性，避免最坏情况造成过大的效率问题
    // 交换后的数组内容不变，a[low]可以是之前数组的任何一个元素

    int pivot_key = arr[0] = arr[low]; // arr[low]的值作为轴枢值存在了arr[0]，因此arr[low]这个空位实际上成为了闲置空间
                                        // 我们将把这个闲置空间作为轴枢，把一切>=轴枢的放右边，把一切<=轴枢的放左边，
                                        // 最后把pivot_key往这个闲置空间一放就可以了
                                        // 比如数组arr[]={*, 3, 3, 1, 2, 5, 3}，如果我们选择了a[1]作为轴枢，
                                        // 就会得到arr[]={3, *, 3, 1, 2, 5, 3}，注意到此时a[1]的值已经保存在a[0]，并且a[1]成为闲置空间
                                        // 那么，a[2]和a[6]存储的3可以随意放在轴枢(*)的任何一侧
                                        

    // 注意在分区过程中，我们一直都有一个闲置的位置，直到最后填入pivot_key为止
    // 以下运行中，要维护：（1）low指向闲置空间，（2）low左侧的元素是顶多不超过pivot_key，（3）high右侧的元素最低不低于pivot_key
    while(low < high) // 仍有元素未确定分区 
    {
        // 逐个检查，尽力确定高半区的元素
        while(low < high && arr[high] >= pivot_key) // 关键字等于pivot_key时，元素可以放在任何一侧，所以这里可以取=号，
                                                    // 而且也必须取等号，否则high指针可能无法移动
        
        {
            --high; // 跳过（注意这里的编程技巧，物理上移动指针，从而做到逻辑上移动元素）
        }
        // 此时arr[high]必小于pivot_key，因此，它的值一定要放在轴枢(*)的左边
        // 如何把a[high]的元素移动到轴枢(*)的左边？注意到轴枢(*)实际上是闲置空间
        arr[low] = arr[high]; // 对闲置空间进行写入操作不会丢失有用数据
                            // 并且写入操作执行后，a[high]成为了闲置空间

        // 逐个检查，尽力确定低半区的元素
        while(low < high && arr[low] <= pivot_key) // 关键字等于pivot_key时，元素可以放在任何一侧，所以这里可以取=号，
                                                    // 而且也必须取等号，否则low指针可能无法移动
        {
            ++low; // 跳过（注意这里的编程技巧，物理上移动指针，从而做到逻辑上移动元素）
        }
        // 此时arr[low]必大于pivot_key，因此，它的值一定要放在轴枢(*)的右边
        // 如何把a[low]的元素移动到轴枢(*)的右边？注意到在上一步，a[high]成为了闲置空间
        arr[high] = arr[low]; // 对闲置空间进行写入操作不会丢失有用数据
                            // arr[low]又成为了闲置空间
    }
    // 此时low==high，左右两侧的元素已经安放好
    arr[low] = arr[0]; // 把轴枢的值放进当前的闲置空间arr[low]
                        // arr[0]又成为了闲置空间
    return low; // 返回轴枢的位置
}

// 对迭代器的子表arr[low ... high]进行排序
void MyVector::qsort(int low, int high)
/*
调用时的前置值：low = 1, high = array_size
对迭代器的子表arr[low, high]做快速排序
*/
{
    if(low < high)
    {
        int pivot_loc = partition(low, high);
        qsort(low, pivot_loc - 1);
        qsort(pivot_loc + 1, high);
    }
}

// 快速排序
void MyVector::quick_sort()
{
    srand(time(NULL)); // 播种，准备产生随机数
    qsort(1, array_size);
}