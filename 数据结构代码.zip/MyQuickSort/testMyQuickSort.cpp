#include <iostream>
#include "MyVector.h"

using namespace std;

const int FAILURE = 1;

int main()
{
    // 创建
    int a1[] = {1, 2, 3};
    int a2[] = {29, 13, 17, 19, 23};
    MyVector vec1(a1, 3), vec2(a2, 5);
    cout << "vec1:" << endl;
    vec1.show(); 
    cout << endl;
    cout << "vec2:" << endl;
    vec2.show();
    cout << endl;

    // 取值
    int e;
    if(!vec1.get_element(2, e))
    {
        return FAILURE;
    }
    cout << "The 2nd element in vec1 is " << e << endl;
    if(!vec2.get_element(3, e))
    {
        return FAILURE;
    }
    cout << "The 3rd element in vec2 is " << e << endl;

    // 定位
    int index = vec1.locate_element(4);
    if(index == 0)
    {
        cout << "4 is not found in vec1" << endl;
    }
    else
    {
        cout << "the index of 4 in vec1 is " << index << endl;
    }

    index = vec2.locate_element(4);
    if(index == 0)
    {
        cout << "4 is not found in vec2" << endl;
    }
    else
    {
        cout << "the index of 4 in vec2 is " << index << endl;
    }
    
    // 插入
    cout << "try to insert 8 into vec1 before location 4" << endl;
    if(!vec1.insert_element(4, 8))
    {
        cout << "inserting 8 into vec1 before location 4 causes failures" << endl;
    }
    cout << "vec1:" << endl;
    vec1.show();
    cout << endl;

    cout << "try to insert 8 into vec1 before location 2" << endl;
    if(!vec1.insert_element(2, 8))
    {
        cout << "inserting 8 into vec1 before location 2 causes failures" << endl;
    }
    cout << "vec1:" << endl;
    vec1.show();
    cout << endl;

    cout << "try to insert 7 into vec2 before location 5" << endl;
    if(!vec2.insert_element(5, 7))
    {
        cout << "inserting 7 into vec2 before location 5 causes failures" << endl;
    }
    cout << "vec2:" << endl;
    vec2.show();
    cout << endl;

    cout << "try to delete the element at location 1 in vec1" << endl;
    if(!vec1.delete_element(1))
    {
        cout << "deleting the element at location 1 in vec1 failed" << endl;
    }
    cout << "vec1:" << endl;
    vec1.show();
    cout << endl;

    cout << "try to delete the element at location 5 in vec2" << endl;
    if(!vec2.delete_element(5))
    {
        cout << "deleting the element at location 5 in vec2 failed" << endl;
    }
    cout << "vec1:" << endl;
    vec2.show();
    cout << endl;

    vec2.push_back(9); vec2.push_back(11); vec2.push_back(8);
    cout << "after pushing back a few elements, vec2 becomes" << endl;
    vec2.show();
    cout << endl;

    vec2.quick_sort();
    cout << "after being quick-sorted, vec2 becomes" << endl;
    vec2.show();
    cout << endl;

    int a3[] = {1, 2, 3, 7, 6, 7, 10, 11, 12};
    MyVector vec3(a3, 9);
    cout << "below are contents of vec3:" << endl;
    vec3.show();
    cout << endl;
    vec3.quick_sort();
    cout << "after being quick-sorted, it becomes:" << endl;
    vec3.show();

    // 无需手工调用析构函数
    return 0;
}