#ifndef MY_VECTOR_H
#define MY_VECTOR_H
#include <iostream>

using namespace std;

const int OK = 1;
const int ERROR = 0;

const int INIT_CAPACITY = 4;

class MyVector{ // 注意数组从0号单元开始使用
    private:
        int *arr;
        int array_size;
        int capacity;
        
    public:
        MyVector();
        MyVector(int *a, int sz);
        ~MyVector();

        /*返回下标为i的元素（即第i+1个元素）的值*/
        int get_element(int i, int &e);

        /*返回最后一个值为e的元素的下标；若满足条件的元素不存在，则返回-1，*/
        int locate_element(int e);

        /*在下标为i的位置之前插入元素e，i的范围是[0, array_size]*/
        int insert_element(int i, int e);

        /*删除下标为i的元素*/
        int delete_element(int i);

        /*输出迭代器的内容*/
        void show();
};

#endif