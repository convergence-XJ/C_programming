#include <iostream>
#include "MyVector.h"

// 无参构造函数
MyVector::MyVector()
{
    capacity = INIT_CAPACITY;
    arr = new int[capacity];
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    array_size = 0;
}

// 带参构造函数
MyVector::MyVector(int *a, int sz)
{
    // 确定容量
    capacity = INIT_CAPACITY > sz ? INIT_CAPACITY : sz;
    // 分配空间
    arr = new int[capacity];
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    // 复制
    for(int i = 0; i < sz; i++)
    {
        arr[i] = a[i]; 
    }
    array_size = sz; // 维护数组大小
}

// 析构函数
MyVector::~MyVector()
{
    delete[] arr;
}

// 取值
int MyVector::get_element(int i, int &e)
/*返回下标为i的元素（即第i+1个元素）的值*/
{
    if(i < 0 || i >= array_size) // 访问越界
    {
        return ERROR;
    }
    e = arr[i];
    return OK;
}

// 定位
int MyVector::locate_element(int e)
/*返回最后一个值为e的元素的下标；若满足条件的元素不存在，则返回-1，*/
{
    int i;
    // 从后往前搜查
    for(i = array_size - 1; i >= 0; i--)
    {
        if(arr[i] == e) // 找到
        {
            break;
        }
    }
    return i;
}

// 插入
int MyVector::insert_element(int i, int e)
/*在下标为i的位置之前插入元素e，i的范围是[0, array_size]，允许在末端插入元素*/
{
    if(i < 0 || i > array_size)
    {
        return ERROR; // 不在合法范围内
    }
    
    if(capacity < array_size + 1) // 容量不足
    {
        capacity *= 2; // 容量增大为2倍
        int* new_arr = new int[capacity]; // 分配空间
        if(!new_arr)
        {
            cout << "insufficient memory" << endl;
            exit(1);
        }
        int j;
        // 把前面i个旧元素复制过去
        for(j = 0; j < i; j++)
        {
            new_arr[j] = arr[j];
        }
        new_arr[j++] = e; // 插入元素
        for(; j < array_size + 1; j++)
        {
            new_arr[j] = arr[j - 1]; // 复制发生偏移
        }
        delete[] arr; // 销毁原数组
        arr = new_arr; // 关联新数组
    }
    else
    {
        for(int j = array_size - 1; j >= i; --j)
        {
            arr[j + 1] = arr[j]; // 元素后移，包括下标为i的元素
        }
        arr[i] = e;
    }
    array_size++;
    return OK;
}

// 删除
int MyVector::delete_element(int i)
/*删除下标为i的元素*/
{
    if(i < 0 || i > array_size - 1)
    {
        return ERROR;
    }
    // 下标从i+1开始是后面的元素，直到最后一个
    for(int j = i + 1; j < array_size; j++)
    {
        arr[j - 1] = arr[j]; // 前移
    }
    array_size--;
    return OK;
}

// 打印
void MyVector::show()
{
    for(int i = 0; i < array_size; i++)
    {
        cout << arr[i] << '\t';
    }
}