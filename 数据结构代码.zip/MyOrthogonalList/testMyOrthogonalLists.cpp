#include <iostream>
#include "MyOrthogonalList.h"

const int SUCCESS = 0;
const int FAILURE = 1;

const std::string FILE_NAME = "directed_data_file.txt";

int main()
{
    OLGraph my_graph;
    if(!create_directed_graph(my_graph, FILE_NAME))
    {
        return FAILURE;
    }
    
    std::cout << "by tails:" << std::endl;
    print_directed_graph_by_tails(my_graph);
    std::cout << "by heads:" << std::endl;
    print_directed_graph_by_heads(my_graph);

    destroy_directed_graph(my_graph);
    return SUCCESS;
}