#ifndef MY_ORTHOGONAL_LIST_H
#define MY_ORTHOGONAL_LIST_H

#include <string>
#include <vector>

typedef std::string VertexType;

typedef struct ArcBox{ // 弧结点
    int head_vertex; // 弧头顶点下标 
    int tail_vertex; // 弧尾顶点下标
    struct ArcBox* head_link; // 指向下一段具有相同头顶点的弧
    struct ArcBox* tail_link; // 指向下一段具有相同尾顶点的弧
    int data; // 与弧关联的数据
} ArcBox;

typedef struct VertexNode{
    VertexType data; // 
    ArcBox* in_first; // 指向第一条流入该顶点的弧
    ArcBox* out_first; // 指向第一条从该顶点流出的弧
} VertexNode;

typedef struct OLGraph{
    VertexNode* xlist; // 用于创建头结点组成的数组
    int vertex_num; // 顶点数
    int arc_num; // 边数
} OLGraph; // 更适用于有向图，因为<1, 2>和<2, 1>被视为两个边结点


// 从键盘创建十字链表
int create_directed_graph(OLGraph &my_graph);

// 从键盘创建十字链表，数据来自于文件
int create_directed_graph(OLGraph &my_graph, const std::string& file_name);

// 打印十字链表
void print_directed_graph_by_tails(const OLGraph &my_graph); 

// 打印十字链表
void print_directed_graph_by_heads(const OLGraph &my_graph); 

// 销毁十字链表
void destroy_directed_graph(const OLGraph &my_graph);

#endif