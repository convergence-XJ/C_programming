#include <iostream>
#include "MyString.h"

using namespace std;

int main()
{
    MyString str1("long"), str2("-term");
    str1.show();
    cout << endl;
    str2.show();
    cout << endl;
    str1.append(str2);
    str1.show();
    cout << endl;
    str1.assign(str2);
    str1.show();
    cout << endl;
    // 析构函数自动释放内存
    return 0;
}

