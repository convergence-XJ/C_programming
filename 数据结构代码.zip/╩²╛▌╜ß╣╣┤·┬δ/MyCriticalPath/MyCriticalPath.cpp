#include <iostream>
#include "MyTopologicalSort.h"
#include "MyCriticalPath.h"

using namespace std;

// 给定邻接表存储的有向图，求出最短运行时间，保存在run_time中，并求出所有关键活动，保存在critial_activities中
Status compute_critical_activities_and_time(const ALGraph & my_graph, int & run_time, vector<pair<int, int>>& critial_activities)
{
    // 以下描述中，图的顶点表示瞬间发生并完成的事件，图的边表示持续一段时间的活动
    // 设i和j为事件，并且k=<i,j>为活动。于是i和j都是瞬间发生并完成的，k则要持续一段时间。
    // 事件i一旦发生，紧随的活动k立即开始；活动k一旦完成，紧随的事件j立即发生
    // 因此我们需要按拓扑排序来确认各个活动的最早和最晚开始时间

    vector<int> topo_sort_result_in_indexes;
    if(!topologicalSort(my_graph, topo_sort_result_in_indexes))
    {
        cout << "cannot find critical paths for a cyclic graph" << endl;
        return ERROR;
    }
    
    // 以下用迭代器event_earliest_start_time来保存各个事件的最早发生时间
    // 用迭代器event_latest_start_time来保存各个事件的最晚发生时间
    
    // 为保证工程进度最快，第一个事件的最早发生时间和最晚发生时间必相等，最后一个事件的最早发生时间和最晚发生时间必相等
    // 更相信地来说，任何无先决条件的事件，最早发生时间必然等于最晚发生时间
    // 任何无后继活动的事件，其最早发生时间也必然等于最晚发生时间，这才能最快完成

    // 把所有事件的最早发生时间设为0（任何事件都不可能更早发生），
    // 对于那些有先决条件的事件，往后我们将推迟它们的发生时间
    vector<int> event_earliest_start_time(my_graph.vertex_num + 1, 0);

    // 按拓扑次序计算每个事件的最早发生时间
    for(int i = 0; i < topo_sort_result_in_indexes.size(); i++)
    {
        int k = topo_sort_result_in_indexes[i]; // 拓扑序列中的次序为i的事件，它是图中k号顶点对应的事件
        ArcNode* p = my_graph.vertices[k].arc_first; // 找到所有的后继事件组成的链表，每个事件都因为被k约束而有一定的延后
        while(p)
        {
            int j = p->to_vertex_id; // 后继活动通往的是图中j号顶点对应的事件

            // 等待k号顶点对应的事件开始并且等待其后序活动完成，须推迟j号顶点对应的事件
            if(event_earliest_start_time[j] < event_earliest_start_time[k] + p->activity_time) 
            {
                event_earliest_start_time[j] = event_earliest_start_time[k] + p->activity_time;
            }

            //
            p = p->arc_next;
        }
    }

    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        cout << my_graph.vertices[i].data << ":" << event_earliest_start_time[i] << "\t";
    }
    cout << endl;

    run_time = event_earliest_start_time[topo_sort_result_in_indexes.back()]; // 最后事件的发生时间，也就是完成项目所用时间
    
    // 把所有事件的最晚发生时间，设为最后一个事件的最早发生时间（任何事件都不可能更晚发生）
    // 对于那些作为先决条件的事件，往后我们将提早它们的发生时间
    vector<int> event_latest_start_time(my_graph.vertex_num + 1, \
        event_earliest_start_time[topo_sort_result_in_indexes.back()]);

    // 按逆拓扑次序计算每个活动的最晚发生时间
    for(int i = topo_sort_result_in_indexes.size() - 1; i >= 0; i--)
    {
        int k = topo_sort_result_in_indexes[i]; // 拓扑序列中的次序为i的事件，它是图中k号顶点对应的事件
        ArcNode* p = my_graph.vertices[k].arc_first; // 找到所有的后继事件，每个事件都对事件k造成一定的约束，把k的最晚开始时间往前推

        while(p)
        {
            int j = p->to_vertex_id; // 后继活动通往的是图中j号顶点对应的事件

            // 确保j号顶点对应的事件及时开始并且确保其前驱活动及时完成，须提早k号顶点对应的事件
            if(event_latest_start_time[j] - p->activity_time < event_latest_start_time[k])
            {
                event_latest_start_time[k] = event_latest_start_time[j] - p->activity_time;
            }

            // 
            p = p->arc_next;
        }
    }

    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        cout << my_graph.vertices[i].data << ":" << event_latest_start_time[i] << "\t";
    }
    cout << endl;

    // 判断每一活动是否为关键活动
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        ArcNode *p = my_graph.vertices[i].arc_first; // p指向i号顶点的第一个邻接点
        while(p)
        {
            int j = p->to_vertex_id; // 确认了一条边<v_i, v_j>
            int earliest_start = event_earliest_start_time[i]; // 活动<v_i, v_j>的最早开始时间
            int latest_start = event_latest_start_time[j] - p->activity_time; // 活动<v_i, v_j>的最晚开始时间
            if(earliest_start == latest_start) // 最早开始时间与最晚开始时间相同，刻不容缓
            {
                critial_activities.push_back(pair<int, int>(i, j));
            }
            p = p->arc_next;
        }
    }

    return OK;
}

// 输出关键活动
void print_critical_activities(const ALGraph & my_graph, const vector<pair<int, int>> & critical_activities)
{
    for(vector<pair<int, int>>::const_iterator itr = critical_activities.begin(); itr != critical_activities.end(); itr++)
    {
        cout << "<" << my_graph.vertices[itr->first].data << ", " << my_graph.vertices[itr->second].data << ">,\t";
    }
    cout << endl;
}