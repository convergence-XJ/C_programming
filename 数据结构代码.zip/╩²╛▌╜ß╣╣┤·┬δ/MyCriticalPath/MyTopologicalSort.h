#ifndef MY_TOPOLOGICAL_SORT_H
#define MY_TOPOLOGICAL_SORT_H

#include <vector>
#include "MyAdjacencyList.h"

typedef int Status;

// 对邻接表形式存储的有向图的顶点进行拓扑排序，把排序后各顶点的序号依次写入topo_sort_res。若my_graph有环，则排序失败
Status topologicalSort(const ALGraph & my_graph, vector<int> &topo_sort_res_in_indexes);

#endif