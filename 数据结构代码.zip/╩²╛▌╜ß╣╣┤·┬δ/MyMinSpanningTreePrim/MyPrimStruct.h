#ifndef MY_PRIM_STRUCT_H
#define MY_PRIM_STRUCT_H

#include <vector>

using namespace std;

struct MinCostAdjacentEdge{ // 到达局部生成子树的最小代价边
    VertexType v; // 通往子树上的顶点v，注意，不是下标，是顶点名称
    ArcType cost; // 代价
};

// 从顶点u出发，通过普利姆算法，求最小生成树
vector<pair<VertexType, VertexType>>  min_cost_spanning_tree(const AMGraph & my_graph, const VertexType u);

#endif