#include <iostream>
#include <vector>
#include "MyAdjacencyMatrix.h"
#include "MyPrimStruct.h"

using namespace std;

const int FAILURE = -1;

int next_added_vertex_index(const AMGraph & my_graph, MinCostAdjacentEdge *min_cost_adj_edges)
{
    // 计算
    int best_next_vertex_index = 0; // 利用无用元素
    min_cost_adj_edges[best_next_vertex_index].cost = INFINITY; // 初始化代价为无穷大（这是常用编程技巧）
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        if(!min_cost_adj_edges[i].cost) // 已被选上
        {
            // 算了
            continue;
        }
        if(min_cost_adj_edges[i].cost < min_cost_adj_edges[best_next_vertex_index].cost)
        // 未被选过，而且代价更低
        {
            best_next_vertex_index = i; // 更新最优添加顶点的下标
        }
    }
    // 找不到合适的顶点
    if(!best_next_vertex_index) // 成立说明best_next_vertex_index未被更新，说明所有顶点都与
    {
        cout << "the input graph is not connected" << endl;
        exit(FAILURE);
    }
    return best_next_vertex_index;
}

// 从顶点u出发，通过普利姆算法，求最小生成树
vector<pair<VertexType, VertexType>> min_cost_spanning_tree(const AMGraph & my_graph, const VertexType u)
{
    vector<pair<VertexType, VertexType>> edge_vertex_pair;
    MinCostAdjacentEdge *min_cost_adj_edges = new MinCostAdjacentEdge[my_graph.vertex_num + 1]; // 0号单元不用
    if(!min_cost_adj_edges)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    // 确定u的下标k
    int k = locate_vertex(my_graph, u);
    min_cost_adj_edges[k].cost = 0; // cost=0表示已经连接到局部子树上，注意标志位的使用
    // 初始化其余各顶点连到子树的方式和代价
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        if(i == k) // 自身顶点不用管
        {
            continue;
        }
        min_cost_adj_edges[i].v = u; // 目前只能通往顶点u
        min_cost_adj_edges[i].cost = my_graph.arcs[i][k]; // 初始化代价为边权，注意到在邻接矩阵中，
                                                            // 如果两点之间没有边，边权为无穷大
    }
    // 对其余(n-1)个顶点
    for(int i = 1; i < my_graph.vertex_num; i++) 
    {
        // 选择下一个最好的顶点，下标保存到k，添加它的代价最小（最贪心选择）
        int k = next_added_vertex_index(my_graph, min_cost_adj_edges);
        VertexType u0 = min_cost_adj_edges[k].v; // 通往已选的u0
        VertexType v0 = my_graph.vertices[k]; // 从v0出发
        edge_vertex_pair.push_back(pair<VertexType, VertexType>(v0, u0)); // 添加到结果
        min_cost_adj_edges[k].cost = 0; // 置零，标记为已添加
        // 以下更新未连上的结点的最短边
        for(int j = 1; j <= my_graph.vertex_num; j++)
        {
            if(!min_cost_adj_edges[j].cost)
            {
                // 已选的就算了
                continue;
            }
            if(my_graph.arcs[j][k] < min_cost_adj_edges[j].cost) // 新顶点带来更低权重的边
            {
                // 果断更新
                min_cost_adj_edges[j].v = my_graph.vertices[k];
                min_cost_adj_edges[j].cost = my_graph.arcs[j][k];
            }
        }
    }
    delete[] min_cost_adj_edges; // 销毁辅助数组
    return edge_vertex_pair; // 不能返回引用，因为这是临时变量，离开本函数后无效
}