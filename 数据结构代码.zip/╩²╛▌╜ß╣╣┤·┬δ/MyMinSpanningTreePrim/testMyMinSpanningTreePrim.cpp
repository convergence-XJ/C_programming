#include <iostream>
#include <vector>
#include "MyAdjacencyMatrix.h"
#include "MyPrimStruct.h"

const int SUCCESS = 0;

const string FILE_NAME = "data_file.txt";

int main()
{
    AMGraph my_graph;
    
    create_undirected_network(my_graph, FILE_NAME);
    cout << "input graph:" << endl;
    print_undirected_network(my_graph);
    VertexType u = my_graph.vertices[1];
    vector< pair<VertexType, VertexType> > edge_vertex_pair = min_cost_spanning_tree(my_graph, u);
    cout << "minimum spanning tree:" << endl;
    for(vector< pair<VertexType, VertexType> >::iterator iter = edge_vertex_pair.begin(); iter != edge_vertex_pair.end(); ++iter)
    {
        cout << iter->first << ", " << iter->second << endl;
    }
    destroy_undirected_network(my_graph);
    return SUCCESS;
}