#include <iostream>
#include <fstream>
#include "MyAdjacencyMultilist.h"

using namespace std;

const int ERROR = 0;
const int OK = 1;

// 给定顶点，返回它在顶点数组（0号单元弃用）中的下标；若不存在，则返回0
int locate_vertex(const AMLGraph &my_graph, VertexType data)
{
    int i;
    for(i = my_graph.vertex_num; i > 0; --i)
    {
        if(my_graph.adjacency_multilist[i].data == data)
        {
            break;
        }
    }
    return i;
}

// 创建基于邻接多重表的无向图（网），数据来源于文件
int create_undirected_network(AMLGraph &my_graph, const string& file_name)
{
    ifstream in_file(file_name);
    if(!in_file)
    {
        cout << "cannot open " << file_name << endl;
        exit(-1);
    }

    in_file >> my_graph.vertex_num;
    in_file >> my_graph.edge_num;

    my_graph.adjacency_multilist = new VertexBox[my_graph.vertex_num + 1];
    if(!my_graph.adjacency_multilist)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }

    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        in_file >> my_graph.adjacency_multilist[i].data;
        my_graph.adjacency_multilist[i].edge_first = NULL;
    }

    for(int k = 1; k <= my_graph.edge_num; k++)
    {
        // 读入顶点信息
        VertexType v1, v2;
        in_file >> v1 >> v2;

        // 确定顶点的序号
        int i_vertex_index = locate_vertex(my_graph, v1);
        int j_vertex_index = locate_vertex(my_graph, v2);

        // 创建边结点
        EdgeBox* p = new EdgeBox;
        if(!p)
        {
            cout << "insufficient memory" << endl;
            return ERROR;
        }

        // 写入数据信息
        p->data = 1; // 无数据先设定为*
        p->i_vertex_index = i_vertex_index; // 其中一个顶点的下标
        p->j_vertex_index = j_vertex_index; // 另外一个顶点的下标
        p->i_link = NULL;
        p->j_link = NULL; // 置为空

        // 插入到所有与i关联的边组成的列表
        if(my_graph.adjacency_multilist[i_vertex_index].edge_first) // 如果插入的是该链表的第一个边结点，无需特殊处理
        {
            if(my_graph.adjacency_multilist[i_vertex_index].edge_first->i_vertex_index == i_vertex_index) // 第一个边结点的前面顶点对上号
            {
                p->i_link = my_graph.adjacency_multilist[i_vertex_index].edge_first; // 于是用i_link来追踪
            }
            else // 第一个边结点的后面顶点对上号
            {
                p->j_link = my_graph.adjacency_multilist[i_vertex_index].edge_first; // 于是用j_link来追踪
            }
        }
        my_graph.adjacency_multilist[i_vertex_index].edge_first = p; // 插入


        // 插入到所有与j关联的边组成的列表
        if(my_graph.adjacency_multilist[j_vertex_index].edge_first) // 如果插入的是该链表的第一个边结点，无需特殊处理
        {
            if(my_graph.adjacency_multilist[j_vertex_index].edge_first->j_vertex_index == j_vertex_index) // 第一个边结点的前面顶点对上号
            {
                p->j_link = my_graph.adjacency_multilist[j_vertex_index].edge_first; 
            }
            else // 第一个边结点的后面顶点对上号
            {
                p->i_link = my_graph.adjacency_multilist[j_vertex_index].edge_first;
            }
        }
        my_graph.adjacency_multilist[j_vertex_index].edge_first = p;
    }

    in_file.close(); // 关闭文件
    return OK;    
}

// 销毁邻接多重表
void destroy_undirected_network(AMLGraph &my_graph)
{
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        // 销毁i号顶点在前面的所有边，遍历所有可能的i值之后，每个边结点都被恰当销毁
        if(!my_graph.adjacency_multilist[i].edge_first) // 空表，该顶点无边，无需销毁边结点
        {
            continue;
        }

        if(my_graph.adjacency_multilist[i].edge_first->i_vertex_index != i) // 在i号顶点的第一条边中，i号顶点不在前面
        {
            continue;
        }

        while(my_graph.adjacency_multilist[i].edge_first)
        {
            EdgeBox* p = my_graph.adjacency_multilist[i].edge_first;
            my_graph.adjacency_multilist[i].edge_first = my_graph.adjacency_multilist[i].edge_first->i_link; // 从关联到i的边组成的链表中删除
            // cout << "deleting: (" << my_graph.adjacency_multilist[p->i_vertex_index].data << ", "\
             << my_graph.adjacency_multilist[p->j_vertex_index].data << ")" << endl;
            delete p;
        }
    }
    delete[] my_graph.adjacency_multilist;
}

// 打印基于邻接多重表的无向图（网）
void print_undirected_network(const AMLGraph &my_graph)
{
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        // 打印i号顶点在前面的所有边，遍历所有i值之后，任何一条边都恰好被打印一次
        cout << my_graph.adjacency_multilist[i].data << ":";

        if(!my_graph.adjacency_multilist[i].edge_first) // 空表，该顶点无边
        {
            cout << endl;
            continue;
        }

        if(my_graph.adjacency_multilist[i].edge_first->i_vertex_index != i) // 在i号顶点的第一条边中，i号顶点不在前面
        {
            cout << endl;
            continue;
        }

        EdgeBox* p = my_graph.adjacency_multilist[i].edge_first;
        while(p)
        {
            cout << "(" << my_graph.adjacency_multilist[p->i_vertex_index].data << ", "\
             << my_graph.adjacency_multilist[p->j_vertex_index].data << ")" << "\t";
            p = p->i_link;
        }

        cout << endl;
    }
}