#include <iostream>
#include <cstring>
#include "MyHuffmanTree.h"

using namespace std;

void select(const MyHuffmanTree& htree, int num_of_trees_in_front, int& s1, int& s2)
/*从前面k棵树中选择权重最小的两棵树s1和s2，其中s1和s2为树的序号*/
{
    int i; // 用于遍历各个结点，须找出根结点
    bool flag = true; // 用于控制是给s1赋值还是给s2赋值
    for(i = 1; i <= num_of_trees_in_front; i++) // 一直循环，直到找出两个树为止
    {
        if(!htree[i].parent) // 没有父亲，可用于合并（用0来模拟空指针）
        {
            if(flag)
            {
                s1 = i; // 第一次遇见无父亲的赋值给s1
                flag = false;
            }
            else
            {
                s2 = i; // 第二次遇见无父亲的赋值给s2
                break;
            }
        }
    }
    for(i++; i <= num_of_trees_in_front; i++) // 对剩下的每棵树
    {
        if(htree[i].parent) // 已经被选上
        {
            continue; // 
        }
        if(htree[s1].weight < htree[s2].weight)
        {
            if(htree[i].weight < htree[s2].weight) // 小于s1和s2中较大的权
            {
                s2 = i; // 较大权的树被更新
            }
        }
        else
        {
            if(htree[i].weight < htree[s1].weight) // 小于s1和s2中较大的权
            {
                s1 = i; // 较大权的树被更新
            }
        }
    } // 循环结束后s1和s2的权是所有子树中最小的
}

// 根据以a为首元素地址的数组（权重数组），创建具有n个叶结点的哈夫曼树
void create_huffman_tree(MyHuffmanTree& htree, int *a, int n)
{
    if(n <= 1)
    {
        return;
    }
    int m = 2 * n - 1; // 哈夫曼树结点总数
    htree = new MyHuffmanTreeNode[m+1]; // 0号单元不用，因此多留一个空间，以后恰好可以用0来模拟空指针
    if(!htree)
    {
        cout << "insufficient memory" << endl;
        exit(-1);
    }
    for(int i = 1; i <= n; i++) // 前面n个单元用于存储叶结点，注意到0号结点不用
    {
        // 数据域
        htree[i].weight = a[i-1];
    } 
    // 前面n棵树已经准备好
    for(int i = 1; i <= m; i++) // 初始化全部结点的指针，注意到0号结点不用
    {
        // 指针初始化为空
        htree[i].lchild = htree[i].rchild = htree[i].parent = 0; 
    }
    for(int i = n + 1; i <= m; i++) // 对于叶结点以外的结点，注意0号结点不用
    {
        int s1, s2;
        // 从前面i-1棵树中，找出权值最小的两棵树
        select(htree, i - 1, s1, s2);
        htree[i].weight = htree[s1].weight + htree[s2].weight;
        // 建立指针关联
        htree[i].lchild = s1;
        htree[i].rchild = s2;
        htree[s1].parent = htree[s2].parent = i; 
    }
    /*
    for(int i = 1; i <= m; i++)
    {
        cout << i << "\t" << htree[i].weight << "\t" << htree[i].parent << "\t" << htree[i].lchild << "\t" << htree[i].rchild << endl;
    }
    */
}

// 给定包含n个字符的哈夫曼树，生成哈夫曼编码（注意到哈夫曼编码是0-1字符串）
// 左分支用0表示，右分支用1表示
void generateHuffmanCode(const MyHuffmanTree htree, HuffmanCode &huffmanCode, const int n)
{
    huffmanCode = new char*[n + 1]; // 分配n个字符的编码存储空间，0号单元留出不用
    // 用于临时存放哈夫曼编码，因为哈夫曼编码最长为n-1，
    char* temp_str = new char[n]; // 所以，n个空间最起码可以多出一个来存储'\0'
    temp_str[n-1] = '\0'; // 填上字符串末端标识符
    // 上述字符串按照从尾到头的顺序填充
    for(int i = 1; i <= n; i++) // 对n个字符，逐个求哈夫曼编码
    {
        int huffman_code_start = n - 1; // 字符串的起始位置，初始化为末端
        int curr_node_index = i; // 当前关注的结点（对应第i个字符）的下标
        int father_index = htree[i].parent; // 当前关注结点的父结点的下标
        while(father_index) // 父结点存在，说明当前关注的结点不是根结点
        {
            huffman_code_start--; // 起始为止迁移，便于填入前一个字符
            if(curr_node_index == htree[father_index].lchild) // 当前结点是左孩子
            {
                temp_str[huffman_code_start] = '0'; // 左分支填入'0'
            }
            else // 当前结点是右孩子
            {
                temp_str[huffman_code_start] = '1';
            }
            // 往上回溯
            curr_node_index = father_index; // 指针跟上
            father_index = htree[father_index].parent; // 沿父结点回溯
        }
        huffmanCode[i] = new char[n - huffman_code_start + 1]; // 按实际需要分配存储空间
        strcpy(huffmanCode[i], &temp_str[huffman_code_start]); // 注意只有在huffman_code_start或以后的才是有效的哈夫曼编码字符串
    }
    delete[] temp_str;
}


// k号元素的深度，默认根结点的深度为1
int depth(const MyHuffmanTree htree, int k)
{
    if(!k)
    {
        return 0;
    }
    int d = 0;
    while(k)
    {
        d++;
        k = htree[k].parent;
    }
    return d;
}


// 带权路径长度，权重数组首元素地址为a，元素个数为leaf_num
int weighted_path_length(const MyHuffmanTree & htree, const int* w, const int leaf_num)
{
    int len_sum = 0;
    for(int i = 1; i <= leaf_num; i++)
    {
        len_sum += w[i-1] * (depth(htree, i) - 1); // 深度减一等于0-1编码的长度
    }
    return len_sum;
}


// 销毁哈夫曼树
void destroy_huffman_tree(MyHuffmanTree& htree)
{
    delete[] htree;
}

// 销毁哈夫曼编码
void destroy_huffman_code(HuffmanCode hc, const int leaf_num)
{
    for(int i = 1; i <= leaf_num; i++)
    {
        delete[] hc[i];
    }
    delete[] hc;
}