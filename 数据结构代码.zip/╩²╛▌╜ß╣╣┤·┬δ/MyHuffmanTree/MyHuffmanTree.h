#ifndef MY_HUFFMAN_TREE
#define MY_HUFFMAN_TREE

typedef struct { // Huffman树的结点结构
    int weight; // 结点权重
    int lchild, rchild; // 左右孩子，注意数组下标某种意义上类似于指针
    int parent; // 父结点
} MyHuffmanTreeNode, *MyHuffmanTree;

typedef char **HuffmanCode; // 哈夫曼编码数据类型

// 创建具有n个叶结点的哈夫曼树
void create_huffman_tree(MyHuffmanTree& htree, int *a, int n);

// 生成哈夫曼编码
void generateHuffmanCode(MyHuffmanTree htree, HuffmanCode &hc, int n);

// 带权路径长度，权重数组首元素地址为a，元素个数为leaf_num
int weighted_path_length(const MyHuffmanTree & htree, const int* w, const int leaf_num);

// 销毁哈夫曼树
void destroy_huffman_tree(MyHuffmanTree& htree);

// 销毁哈夫曼编码
void destroy_huffman_code(HuffmanCode hc, const int leaf_num);

#endif