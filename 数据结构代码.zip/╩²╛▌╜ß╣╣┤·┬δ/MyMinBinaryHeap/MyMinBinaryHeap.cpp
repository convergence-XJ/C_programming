#include <iostream>
#include <climits>
#include "MyMinBinaryHeap.h"

using namespace std;

// 无参构造函数
MyMinBinaryHeap::MyMinBinaryHeap()
{
    heap_capacity = INIT_SIZE;
    heap_array = new int[heap_capacity + 1]; // 0号单元不用
    if(!heap_array)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    heap_size = 0;
}

// 假定下标为i的结点，它的左孩子和右孩子都是最小顶二叉堆。
// 以下函数使得，以“下标为i的结点”为根结点的子树，它是最小顶二叉堆。
void MyMinBinaryHeap::min_heapify(int i)
{
    int l = left_child(i);
    int r = right_child(i);
    int index_of_smallest = i;
    if(l <= heap_size && heap_array[l] < heap_array[i]) // 比父结点的值更小
    {
        index_of_smallest = l;
    }
    if(r <= heap_size && heap_array[r] < heap_array[index_of_smallest]) // 比较小的更小
    {
        index_of_smallest = r;
    }
/*
    cout << "the heap:" << endl;
    show();
    cout << endl;
*/
    if(index_of_smallest != i) // 不符合堆的要求
    {
        // 以下通过交换，使得三父子符合堆的要求
        int temp = heap_array[i];
        heap_array[i] = heap_array[index_of_smallest];
        heap_array[index_of_smallest] = temp;
        // 有一课子树可能因为上面的交换而违反堆的要求
        min_heapify(index_of_smallest);
    }
}

// 带参构造函数
MyMinBinaryHeap::MyMinBinaryHeap(int *a, int n)
{
    heap_capacity = n > INIT_SIZE ? n : INIT_SIZE;
    heap_array = new int[heap_capacity + 1]; // 0号单元不用
    if(!heap_array)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    for(int i = 1; i <= n; i++)
    {
        heap_array[i] = a[i-1]; // heap的0号单元不用
    }
    heap_size = n;
    for(int i = heap_size / 2; i >= 1; --i)
    {
        min_heapify(i);
    }
}

// 析构函数
MyMinBinaryHeap::~MyMinBinaryHeap()
{
    delete[] heap_array;
}


// 直观地输出堆的元素
void MyMinBinaryHeap::show()
{
    int node_num_in_this_level = 1; // 当前要打印的层的元素个数
    int dp = get_depth(); // 二叉堆的深度
    int node_dist_in_this_level = 1; // 当前要打印的层中，相邻元素之间的距离
    for(int k = 1; k <= dp; k++)
    {
        node_dist_in_this_level *= 2;
    }
    int start_index_in_this_level = 1;
    // 以下开始打印
    for(int i = 1; i <= dp; i++) // 对每一行
    {
        for (int j = start_index_in_this_level; j < start_index_in_this_level + node_num_in_this_level; j++) // 对行中的每一个元素
        {
            if(j > heap_size) // 超出堆的范围
            {
                break;
            }
            // 打印空格形成左半空白
            for(int k = 1; k <= node_dist_in_this_level / 2 - 1; k++)
            {
                cout << "  ";
            }
            // 打印元素
            if(heap_array[j] >= 0 && heap_array[j] <= 9)
            {
                cout << "+";
            }
            cout << heap_array[j];
            // 打印空格形成有半空白
            for(int k = 1; k <= node_dist_in_this_level / 2; k++)
            {
                cout << "  ";
            }
        }
        cout << endl; // 换下一行
        if(heap_size > 7) cout << endl; // 结点个数多的时候再换一行
        // 准备好下一行的各个参数
        node_num_in_this_level *= 2;
        node_dist_in_this_level /= 2;
        start_index_in_this_level *= 2;
    }
}


// 取走堆中的最小元素，并把最小元素的值返回
int MyMinBinaryHeap::extract_min()
{
    if(!heap_size)
    {
        cout << "underflow" << endl;
        exit(FAILURE);
    }
    int mini = heap_array[1];
    heap_array[1] = heap_array[heap_size--];
    min_heapify(1);
    return mini;
} 

// 把下标为i的元素的关键字缩小为key，
// 如果关键字缩小后违反了堆的要求，则进行位置调整，使得堆的要求再次得到满足
void MyMinBinaryHeap::decrease_key(int i, int key)
{
    if(key > heap_array[i]) // 违反函数的前提
    {
        cerr << "new key is bigger than current key" << endl;
        exit(FAILURE);
    }
    heap_array[i] = key; // 缩小关键字
    while (i > 1 && heap_array[parent(i)] > heap_array[i]) // 具有父结点，且父结点违反小顶堆的要求
    {
        // 交换
        int temp = heap_array[parent(i)];
        heap_array[parent(i)] = heap_array[i];
        heap_array[i] = temp;
        // 可能仍有向上移动的必要
        i = parent(i);
    }
}

void MyMinBinaryHeap::insert(int key)
{
    if(heap_size == heap_capacity) // 满溢
    {
        // 扩容
        int * new_heap_array = new int[heap_capacity * 2 + 1]; // 扩大为原来两倍
        if(!new_heap_array)
        {
            cout << "insufficient memory--" << endl;
            exit(FAILURE);
        }
        // 复制数据到新的数组
        memcpy(new_heap_array, heap_array, (heap_size + 1) * sizeof(int));
        // 
        delete[] heap_array;
        heap_array = new_heap_array;
        heap_capacity *= 2;
    }
    //
    heap_array[++heap_size] = INT16_MAX; // 插入元素到末端
    decrease_key(heap_size, key); // 把末端元素的关键字缩小为key
}





