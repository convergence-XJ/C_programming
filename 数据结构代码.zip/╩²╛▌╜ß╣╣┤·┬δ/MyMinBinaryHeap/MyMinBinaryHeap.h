#ifndef MY_MIN_BINARY_HEAP
#define MY_MIN_BINARY_HEAP

#include <iostream>
using namespace std;

const int FAILURE = -1;

const int INIT_SIZE = 7;


class MyMinBinaryHeap{ // 最小顶二叉堆，用于实现动态集合

private:
    int *heap_array; // 用于存储堆中元素的数组
    int heap_size; // 堆中元素个数
    int heap_capacity; // 堆中最多能容纳的元素个数

private:
    // 给定孩子结点的下标，求父结点的下标
    int parent(int child_index)
    {
        return child_index / 2;
    }

    // 给定父结点的下标，求左孩子结点的下标
    int left_child(int parent_index)
    {
        return parent_index * 2;
    }

    // 给定父结点的下标，求右孩子结点的下标
    int right_child(int parent_index)
    {
        return parent_index * 2 + 1;
    }

    // 假定下标为i的结点，它的左孩子和右孩子都是最小顶二叉堆。
    // 以下函数使得，以“下标为i的结点”为根结点的子树，它是最小顶二叉堆。
    void min_heapify(int i);

    // 二叉堆的层数
    int get_depth()
    {
        if(!heap_size)
        {
            return 0;
        }
        int i = heap_size;
        int dp = 1;
        while(i) // 直到不存在父结点位置
        {
            i = parent(i); // 寻找父结点
            dp++;
        }
        return dp;
    }

    // 把下标为i的元素的关键字缩小为key，
    // 如果关键字缩小后违反了堆的要求，则进行位置调整，使得堆的要求再次得到满足
    void decrease_key(int i, int key);

public:
    MyMinBinaryHeap(); // 无参构造函数
    MyMinBinaryHeap(int *arr, int n); // 带参构造函数
    ~MyMinBinaryHeap(); // 析构函数

    // 直观地输出堆的元素
    void show();

    // 把关键字为key的数据元素插入到堆中
    void insert(int key);

    // 返回堆中的最小元素，如果堆为空，则报错
    int get_minimum()
    {
        if(!heap_size)
        {
            cout << "underflow" << endl;
            exit(FAILURE);
        }
        return heap_array[1];
    }

    // 取走堆中的最小元素，并把最小元素的值返回
    int extract_min(); 
    
};



#endif