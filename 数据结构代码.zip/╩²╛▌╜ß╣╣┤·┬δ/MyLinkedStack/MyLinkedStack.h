#ifndef MY_LINKED_STACK_H
#define MY_LINKED_STACK_H

class MyLinkedStackNode{ // 栈结点

    private:

        int data; // 数据
        MyLinkedStackNode* next; // 指向下面元素的指针

    public:

        // 返回下一结点的地址
        MyLinkedStackNode* get_next_pointer()
        {
            return next;
        }

        // 设置指针域
        void set_next_pointer(MyLinkedStackNode* p)
        {
            next = p;
        }

        // 获取数据
        int get_data()
        {
            return data;
        }

        // 设置数据
        void set_data(const int v)
        {
            data = v;
        }
};

class MyLinkedStack{ // 链栈，不带哨兵结点的非循环单链表，每一个链表结点存一个数据元素

    private:

        MyLinkedStackNode* head; // 链表头指针
        size_t stack_sz;

    public:

        // 构造函数
        MyLinkedStack();

        // 析构函数
        ~MyLinkedStack();

        // 判断堆栈是否为空
        bool empty()
        {
            return !stack_sz;
        }

        // 返回堆栈中元素个数
        size_t get_size()
        {
            return stack_sz;
        }

        // 入栈
        void push(const int data);

        // 出栈
        int pop();

        // 显示堆栈内容，用于调试程序
        void show();
};

#endif