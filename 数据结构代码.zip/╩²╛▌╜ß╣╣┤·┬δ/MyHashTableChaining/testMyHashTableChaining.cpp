#include <iostream>
#include <fstream>
#include <vector>
#include "MyHashTableChaining.h"

// #define last_digit_small_mode

const int SUCCESS = 0;
const int FAILURE = -1;

#ifdef last_digit_small_mode
const string FILE_NAME = "data_file_for_0_2_4.txt";
#else
const string FILE_NAME = "data_file_for_5_2_9.txt";
#endif


int main()
{
    HashTable ht;
/*
    if(!create_hash_table(ht))
    {
        return FAILURE;
    }
*/
    
    vector<string> str_vec;

    ifstream in_file(FILE_NAME); // 打开数据文件
    if(!in_file)
    {
        cout << "cannot open " << FILE_NAME << endl;
        exit(EXIT_FAILURE);
    }

    string temp_str;
    while(in_file) // 数据文件仍有未读数据
    {
        in_file >> temp_str; // 读取，存在temp_str中
        str_vec.push_back(temp_str);
    }
    in_file.close(); // 关闭文件

    if(!create_empty_hash_table_chaining(ht))
    {
        return FAILURE;
    }

    if(!insert_data_into_hash_table_chaining_from_vector(ht, str_vec))
    {
        return FAILURE;
    }
    cout << "ht:" << endl;
    print_hash_table_chaining(ht);
    remove_data_from_hash_table_chaining(ht, "testing");
    cout << "after removing 'testing' from this table" << endl;
    cout << "ht:" << endl;
    print_hash_table_chaining(ht);
    if(address_of_element("resolved", ht))
    {
        cout << "\'resolved\' found" << endl;
    }
    else
    {
        cout << "\'resolved\' not found" << endl;
    }

    if(address_of_element("iceburg", ht))
    {
        cout << "\'iceburg\' found" << endl;
    }
    else
    {
        cout << "\'iceburg\' not found" << endl;
    }

    destroy_hash_table_chaining(ht);

    return SUCCESS;
}