#include <iostream>
#include <vector>

#include "MyHashTableChaining.h"

const int OK = 1;
const int ERROR = 0;

// 哈希函数：(sum_{i=0}^{s.size()-1}s[i]*B^{s.size()-i}) mod hash_table_size
int get_hash(const string& s, const HashTable &htable) 
{
  int res = 0;
  for (int i = 0; i < s.size(); ++i) 
  {
    res = (LL)(res * B + s[i]) % htable.hash_array_len;
  }
  return res;
}

// 把指针p指向的链表结点添加到哈希表中（如果数据元素已经存在，则不进行添加操作）
int insert_node_into_hash_table_chaining(const HashTable &htable, HashLinkedNode* p)
{
    if(!p)
    {
        return ERROR;
    }
    // 根据数据元素确定链表的头指针
    HashLinkedNode* &hd = htable.hash_array[get_hash(p->str, htable)].head;
    HashLinkedNode* q = hd; // 用于遍历某个哈希单元对应的链表
    while(q) // 待插入结点仍可能是链表中某个数据元素
    {
        if(q->str == p->str) // 元素已存在，直接跳出循环
        {
            break;
        }
        q = q->next; // 在链表中找下一个元素
    }
    if(!q) // 数据元素不存在
    {
        // 插入到链表头处
        p->next = hd;
        hd = p;
    }
    return OK;
}

// 插入数据元素到哈希表中
int insert_data_into_hash_table_chaining(const HashTable &htable, const string &data)
{
    HashLinkedNode* p = new HashLinkedNode;
    if(!p)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }
    p->str = data;
    if(!insert_node_into_hash_table_chaining(htable, p))
    {
        return ERROR;
    }
    return OK;
}

// 创建空的哈希表
int create_empty_hash_table_chaining(HashTable& htable)
{
    // 分配数组空间
    htable.hash_array = new HashHeadNode[INIT_TABLE_LEN];
    if(!htable.hash_array)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }
    htable.hash_array_len = INIT_TABLE_LEN;
    // 初始化头结点
    for(int i = 0; i < htable.hash_array_len; i++)
    {
        htable.hash_array[i].head = NULL;
    }
    return OK;
}

// 请求用户输入数据到哈希表
int ask_for_data_to_be_inserted_into_hash_table_chaining(const HashTable& htable)
{
    // 创建结点并插入到相应的链表中
    do{
        string data;
        cout << "input a string:" << endl;
        cin >> data;
        if(data == "#")
        {
            break;
        }
        // 插入p所指的结点
        if(!insert_data_into_hash_table_chaining(htable, data))
        {
            return ERROR;
        }
    } while (true);
    return OK;
}


// 
// 把字符串迭代器里的数据，插入到哈希表
int insert_data_into_hash_table_chaining_from_vector(const HashTable& htable, vector<string> &str_vec)
{
    // 创建结点并插入到相应的链表中
    do{
        if(str_vec.empty())
        {
            break;
        }
        if(!insert_data_into_hash_table_chaining(htable, str_vec.back()))
        {
            return ERROR;
        }
        // 把最后元素删掉
        str_vec.pop_back();
    } while (true);
    return OK;
}

// 查看关键字为key的元素是否存在，若存在，返回指向该元素所在结点的指针，否则返回NULL
HashLinkedNode* address_of_element(const string & data, const HashTable &htable)
{
    HashLinkedNode* p = htable.hash_array[get_hash(data, htable)].head; // 定位到可能包含元素的链表的头结点
    while(p && p->str != data) // 仍没有到链表末端，且数据元素未找到
    {
        p = p->next; // 检查下一个数据元素
    }
    return p; // 无论是否找到都可以返回恰当值
}

// 删除数据元素，如果数据元素不存在，则不进行任何修改操作
void remove_data_from_hash_table_chaining(HashTable &htable, const string& data)
{
    HashLinkedNode* p = htable.hash_array[get_hash(data, htable)].head; // 定位到可能包含元素的链表的头结点
    HashLinkedNode* q = NULL; // 用于指向(*p)的前面一个元素
    while(p && p->str != data) // 仍没有到链表末端，且数据元素未找到
    {
        q = p; // q跟上p的位置
        p = p->next; // p指向下一个数据元素
    }
    if(!p) // 元素不存在，无需删除
    {
        return;
    }
    if(!q) // 首元素就是要被删除的
    {
        htable.hash_array[get_hash(data, htable)].head = htable.hash_array[get_hash(data, htable)].head->next; // 跳过结点
        delete p; // 删除结点 
        return;
    }
    // 待删除的元素不是首元素
    q->next = q->next->next; // 跳过元素
    delete p;
    return;
}

void print_hash_table_chaining(const HashTable& htable)
{
    // 遍历头结点数组
    for(int i = 0; i < htable.hash_array_len; i++)
    {
        // 遍历每个链表
        HashLinkedNode* p = htable.hash_array[i].head;
        cout << i << ":\t";
        while(p)
        {
            cout << p->str << "\t";
            p = p->next;
        }
        cout << endl;
    }
    return;
}

// 销毁哈希表
void destroy_hash_table_chaining(HashTable &htable)
{
    // 遍历头结点数组
    for(int i = 0; i < htable.hash_array_len; i++)
    {
        // 遍历每个链表
        HashLinkedNode* p = htable.hash_array[i].head; // 用于遍历链表
        HashLinkedNode* q = p; // 用于保存待删除的结点的地址
        while(p)
        {
            q = p;
            p = p->next;
            delete q; // 必须在p=p->next之后，否则销毁(*q)就是销毁(*p)，导致p=p->next失灵
        }
    }
    delete[] htable.hash_array;
    return;
}