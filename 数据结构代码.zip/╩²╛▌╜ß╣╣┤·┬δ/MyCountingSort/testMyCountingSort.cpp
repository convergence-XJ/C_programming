#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;

const int MAX_ELEMENT = 100;

void counting_sort(int *a, int n, int *b)
/*给定数组首元素地址a，数组长度n，对数组进行计数排序，
并把排序结果存在以b为首元素地址的数组中，
用户须确保以b开头的存储空间足够存储n个int型元素，
只适用于对一定范围内的非负整数进行排序*/
{
    // 分配数组，用于存储以a为首元素地址的数组中各个元素出现的次数
    int *occur_times = new int[MAX_ELEMENT + 1];
    if(!occur_times)
    {
        cout << "insufficient memory" << endl;
        exit(EXIT_FAILURE);
    }
    // 各个元素出现的次数初始化为零
    memset(occur_times, 0, sizeof(int) * (MAX_ELEMENT + 1));
    // 统计各个元素出现的次数（计数）
    for(int i = 0; i < n; i++)
    {
        occur_times[a[i]]++; // 
    }
    // 分区
    int *occur_positions = new int[MAX_ELEMENT + 1]; // 任意给定元素e，得到小于e的元素的个数
    if(!occur_positions)
    {
        cout << "insufficient memory" << endl;
        exit(EXIT_FAILURE);
    }
    // occur_position[i]也理解为此刻i应该填入的位置
    occur_positions[0] = 0; // 小于0的元素个数
    for(int i = 1; i <= MAX_ELEMENT + 1; i++)
    {
        occur_positions[i] = occur_positions[i-1] + occur_times[i-1]; // 递推，比i小的最大元素最早出现位置+它在输入数组中出现的次数
    }
    // 填入
    for(int i = 0; i < n; i++)
    {
        int v = a[i]; // 待填入的值
        b[occur_positions[v]++] = v; // 把v填入之后，待填入的目标地址+1
    }
    delete[] occur_times;
    delete[] occur_positions;
}

int main()
{
    // 待排序的数组
    int arr[] = {2, 5, 3, 0, 2, 3, 0, 3};
    // 用于存放排序结果
    int *sorted_array = new int[sizeof(arr)];
    // 待排序数组的元素个数
    int num_of_elements = sizeof(arr) / sizeof(int);
    // 计数排序
    counting_sort(arr, num_of_elements, sorted_array);
    // 输出
    for(int i = 0; i < num_of_elements; i++)
    {
        cout << sorted_array[i] << "\t";
    }
    cout << endl;
    // 回收内存
    delete[] sorted_array;
}