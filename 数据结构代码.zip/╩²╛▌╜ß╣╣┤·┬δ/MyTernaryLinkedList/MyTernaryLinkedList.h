#ifndef MY_TERNARY_LINKED_LIST_H
#define MY_TERNARY_LINKED_LIST_H

#include <string>
#include <map>
#include <vector>

using namespace std;

typedef struct MyTernaryLinkedNode{
    string data; // 数据域
    MyTernaryLinkedNode *lchild, *rchild; // 指向左右孩子的指针
    MyTernaryLinkedNode *parent; // 指向父结点的指针
} *MyTernaryLinkedList; // 三叉链表用于存储二叉树


// 用户输入各个结点的值，创建二叉树
int create_binary_tree(MyTernaryLinkedList& bt);

// 根据给定的括号形式的字符串，创建二叉树
void create_binary_tree(MyTernaryLinkedList& bt, const string& str);

// 以括号的形式输出二叉树
void print_binary_tree_as_general_list(MyTernaryLinkedList& bt);

// 生动打印二叉树
void print_binary_tree_prettily(const MyTernaryLinkedList& bt);

// 给定二叉树返回树的深度
int depth(const MyTernaryLinkedList &bt);

// 给定二叉树返回结点个数
int node_count(MyTernaryLinkedList &bt);

// 中序遍历二叉树
void in_order_traverse(const MyTernaryLinkedList bt);

// 中序遍历二叉树（非递归）
void in_order_traverse_nonrecursively(const MyTernaryLinkedList bt);

// 前序遍历二叉树
void pre_order_traverse(const MyTernaryLinkedList bt);

// 后序遍历二叉树
void post_order_traverse(const MyTernaryLinkedList bt);

// 层序遍历二叉树
void level_order_traverse(const MyTernaryLinkedList bt);

// 复制二叉树，把bt复制到new_bt
void copy_ternary_linked_list(const MyTernaryLinkedList bt, MyTernaryLinkedList &new_bt);

// 求每个结点指针的父结点指针（父结点除外）
void get_parents_for_nodes(const MyTernaryLinkedList &bt, map<MyTernaryLinkedList, MyTernaryLinkedList> &mmap);

// 求每个结点所在的层数
void get_levels_for_nodes(const MyTernaryLinkedList &bt, map<MyTernaryLinkedList, int> &mmap);

// 求每层的首位置以及位置之间的距离
void get_node_distances(const MyTernaryLinkedList &bt, vector<int>& level2PositionDistance);

// 给定二叉树，求各个结点在它所在的层的位置
void get_positions_for_nodes(const MyTernaryLinkedList &bt, map<MyTernaryLinkedList, int> &node2Level, map<MyTernaryLinkedList, int> &node2Position);

// 给定二叉树和数据元素，返回它所在的某个结点的地址，若相应结点不存在，则返回空指针
MyTernaryLinkedNode* address_of_data(const MyTernaryLinkedList bt, const string& data);

// 给定二叉树和两个结点指针，判断前一指针所指对象是否后一指针所指对象的祖先。如果是，则返回真，否则返回假。（若某一指针为空，也返回假。）
bool is_ancestor(const MyTernaryLinkedNode* p, const MyTernaryLinkedNode* q);

// 给定二叉树和两个结点指针，判断前一指针所指对象是否后一指针所指对象的兄弟。如果是，则返回真，否则返回假。（若某一指针为空，也返回假。）
bool is_sibling(const MyTernaryLinkedNode* p, const MyTernaryLinkedNode* q);

// 给定指向二叉树某结点的指针，求指向它的父结点的指针，若父结点不存在，则返回空指针
MyTernaryLinkedNode* address_of_parent(const MyTernaryLinkedNode* p);

// 销毁二叉树
int destroy_binary_tree(const MyTernaryLinkedList &bt);
#endif