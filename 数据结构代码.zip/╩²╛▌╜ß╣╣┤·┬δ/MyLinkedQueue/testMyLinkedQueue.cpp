#include <iostream>

#include "MyLinkedQueue.h"

using namespace std;

const int SUCCESS = 0;

int main()
{
    MyLinkedQueue que;
    if(que.empty())
    {
        cout << "Now we have an empty queue" << endl;
    }
    else
    {
        cout << "Now we have a non-empty queue" << endl;
    }
    que.enQueue(2); que.enQueue(3); que.enQueue(5); que.enQueue(7);
    cout << "a queue below:" << endl;
    que.show();
    cout << endl;
    cout << "the number of its elements is " << que.get_size() << endl;
    int data = que.deQueue();
    cout << data << " exits this queue" << endl;
    cout << "its contents become: " << endl;
    que.show();
    cout << endl;
    if(que.empty())
    {
        cout << "Now we have an empty queue" << endl;
    }
    else
    {
        cout << "Now we have a non-empty queue" << endl;
    }
    return SUCCESS;
}