#include <iostream>
#include <fstream>

#include "MyOrthogonalList.h"

using namespace std;

const int ERROR = 0;
const int OK = 1;

// 给定顶点，返回它在顶点数组（0号单元弃用）中的下标；若不存在，则返回0
int locate_vertex(const OLGraph &my_graph, VertexType data)
{
    int i;
    for(i = my_graph.vertex_num; i > 0; --i)
    {
        if(my_graph.xlist[i].data == data)
        {
            break;
        }
    }
    return i;
}

// 用户输入，创建十字链表
int create_directed_graph(OLGraph &my_graph)
{
    cout << "create the vertex number: " << endl;
    cin >> my_graph.vertex_num;
    cout << "create the arc number: " << endl;
    cin >> my_graph.arc_num;

    my_graph.xlist = new VertexNode[my_graph.vertex_num + 1]; // 0号单元不用
    if(!my_graph.xlist)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }
    
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        cout << "input a value of the " << i << "-th vertex" << endl;
        cin >> my_graph.xlist[i].data; // 输入顶点的数据
        my_graph.xlist[i].in_first = NULL; // 一开始没发现任何邻边，所以默认顶点度数为零
        my_graph.xlist[i].out_first = NULL; // 默认出入边都是零
    }

    for(int k = 1; k <= my_graph.arc_num; k++)
    {
        VertexType v1, v2;
        cout << "input the head and tail respectively for " << k << "-th edge" << endl;
        cin >> v1 >> v2;
        int i = locate_vertex(my_graph, v1); // 查找v1的下标
        int j = locate_vertex(my_graph, v2); // 查找v2的下标

        ArcBox *p = new ArcBox;
        if(!p)
        {
            cout << "insufficient memory" << endl;
            return ERROR;
        }
        p->head_vertex = j; // 记下始点下标i
        p->tail_vertex = i; // 记下终点下标j

        // 链表头插入操作，插入到j号顶点关联的链表
        p->tail_link = my_graph.xlist[i].out_first;
        my_graph.xlist[j].out_first = p;

        p->head_link = my_graph.xlist[j].in_first;
        my_graph.xlist[i].in_first = p;
        // 自此，一条边在两个顶点处都被登记了
    }
    return OK;
}

// 从键盘创建十字链表，数据来自于文件
int create_directed_graph(OLGraph &my_graph, const std::string& file_name)
{
    std::ifstream in_file(file_name);
    if(!in_file)
    {
        cout << "cannot open " << file_name << endl;
        exit(EXIT_FAILURE);
    }

    // 读取顶点数和边数
    in_file >> my_graph.vertex_num >> my_graph.arc_num;
    my_graph.xlist = new VertexNode[my_graph.vertex_num + 1]; // 0号单元不用
    if(!my_graph.xlist)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }

    // 读取顶点信息
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        in_file >> my_graph.xlist[i].data; // 输入顶点的数据
        my_graph.xlist[i].in_first = NULL; // 一开始没发现任何邻边，所以默认顶点度数为零
        my_graph.xlist[i].out_first = NULL; // 默认出入边都为空
    }

    // 读取边信息
    for(int k = 1; k <= my_graph.arc_num; k++) // 对每一条边
    {
        VertexType v1, v2;

        // 读取边的顶点信息
        in_file >> v1 >> v2;

        // 确定两个顶点的下标
        int i = locate_vertex(my_graph, v1); // 查找v1的下标
        int j = locate_vertex(my_graph, v2); // 查找v2的下标

        // 创建边结点
        ArcBox *p = new ArcBox;
        if(!p)
        {
            cout << "insufficient memory" << endl;
            return ERROR;
        }

        // 写入头尾顶点的下标
        p->head_vertex = j; // 记下头顶点下标i
        p->tail_vertex = i; // 记下尾顶点下标j

        // 这段弧从第i个顶点流入第j个顶点

        // 链表头插入操作，插入到j号顶点关联的链表
        p->tail_link = my_graph.xlist[i].out_first; // 这是从i流出的弧，共尾
        my_graph.xlist[i].out_first = p;

        p->head_link = my_graph.xlist[j].in_first; // 这是往j流入的弧，共头
        my_graph.xlist[j].in_first = p;
        // 自此，一条边在两个顶点处都被登记了
    }

    in_file.close();
    return OK;    
}

void print_directed_graph_by_tails(const OLGraph &my_graph)
{
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        ArcBox* p = my_graph.xlist[i].out_first;
        cout << my_graph.xlist[i].data << ": ";
        while(p)
        {
            cout << "<" << my_graph.xlist[p->tail_vertex].data << ", " << my_graph.xlist[p->head_vertex].data << ">, ";
            p = p->tail_link;
        }
        cout << endl;
    }
}

// 打印十字链表
void print_directed_graph_by_heads(const OLGraph &my_graph)
{
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        ArcBox* p = my_graph.xlist[i].in_first;
        cout << my_graph.xlist[i].data << ": ";
        while(p)
        {
            cout << "<" << my_graph.xlist[p->tail_vertex].data << ", " << my_graph.xlist[p->head_vertex].data << ">, ";
            p = p->head_link;
        }
        cout << endl;
    }
}

// 销毁十字链表
void destroy_directed_graph(const OLGraph &my_graph)
{
    for(int i = 1; i <= my_graph.vertex_num; i++) // 0号单元弃用
    {
        while(my_graph.xlist[i].out_first)
        {
            ArcBox* p = my_graph.xlist[i].out_first;
            my_graph.xlist[i].out_first = my_graph.xlist[i].out_first->tail_link;
            delete p;
        }
    }
    delete[] my_graph.xlist;
}