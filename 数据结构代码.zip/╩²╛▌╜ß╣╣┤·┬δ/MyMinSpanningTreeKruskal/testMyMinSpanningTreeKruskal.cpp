#include <iostream>

#include "MyAdjacencyMatrix.h"
#include "MyMinSpanningTreeKruskal.h"

const int SUCCESS = 0;
const string FILE_NAME = "data_file.txt";

int main()
{
    AMGraph my_graph;
    create_undirected_network(my_graph, FILE_NAME);
    print_undirected_network(my_graph);
    vector<pair<VertexType, VertexType>> edge_vertex_pairs;
    edge_vertex_pairs = min_spanning_tree_kruskal(my_graph);
    cout << "below is a minimum spanning tree:" << endl;
    for(vector<pair<VertexType, VertexType>>::iterator iter = edge_vertex_pairs.begin(); iter != edge_vertex_pairs.end(); iter++)
    {
        cout << iter->first << ", " << iter->second << endl;
    }
    return SUCCESS;
}