#ifndef MY_MIN_SPANNING_TREE_KRUSKAL_H
#define MY_MIN_SPANNING_TREE_KRUSKAL_H

#include <vector>
#include "MyAdjacencyMatrix.h"

using namespace std;

struct Edge{ // 边结构
    // 两个顶点
    VertexType v1;
    VertexType v2;
    // 
    ArcType cost; // 边的代价

    // 构造函数
    Edge(VertexType u1, VertexType u2, ArcType c)
    {
        v1 = u1; v2 = u2; cost = c;
    }

    // 运算符重载
    bool operator < (const Edge & e)
    {
        return cost < e.cost;
    }

    bool operator == (const Edge &e)
    {
        return cost == e.cost;
    }

    bool operator > (const Edge &e)
    {
        return cost > e.cost;
    }

    bool operator >= (const Edge &e)
    {
        return cost >= e.cost;
    }

    bool operator <= (const Edge &e)
    {
        return cost <= e.cost;
    }

    bool operator != (const Edge &e)
    {
        return cost != e.cost;
    }
};

// 构造函数

// 根据克鲁斯卡尔算法，返回最小生成树
vector<pair<VertexType, VertexType>> min_spanning_tree_kruskal(const AMGraph & my_graph);
#endif