#ifndef MY_HASH_TABLE_OPEN_ADDRESS_H
#define MY_HASH_TABLE_OPEN_ADDRESS_H

#include <vector>
#include <string>
#include <climits>

using namespace std;

// const int M = 1e9 + 7;
const int B = 233;

const string NULL_KEY = "";
const int INCREASING_TABLE_SIZES[] = {7, 11, 13, 17, 19, 23, 57, 97};

const int RE_HASH_LIMIT = 10; // 当发生冲突时，允许的再次计算哈希的次数

typedef long long LL;
typedef string ElemType;
typedef int Status;

enum ReHashType{
    LINEAR,
    SQUARE, // 目前的实现导致经常找不到空位
    PSURAND // 同上
};

class MyRecordType{ // 数据记录

    private:
        ElemType data; // 卫星数据
        string key; // 关键字

    public:

        MyRecordType()
        {
            key = NULL_KEY;
        }

        MyRecordType(const ElemType d, const string k)
        {
            data = d;
            key = k;
        }

        ElemType get_data() const
        {
            return data;
        }

        void set_data(ElemType v)
        {
            data = v;
        }

        string get_key() const
        {
            return key;
        }

        void set_key(string k)
        {
            key = k;
        }

        // 对赋值号进行重载，支持MyRecordType类型的对象之间进行用户自定义的赋值（无必要）
        MyRecordType operator=(const MyRecordType & rc);
};

class MyHashTable{ // 哈希表

    private:
        LL *increments;
        ReHashType rht; // 开放定址法实现再哈希的方法
        MyRecordType* entries; // 哈希空间要求连续存储
        int element_count; // 哈希表所存储的元素的个数
        int table_size; // 哈希表的长度
        int table_size_update_time; // 哈希表容量被更新的次数

        // 生成线性探测、二次探测和为随机探测的增量序列
        void generate_increment_squences();

        // 哈希函数：(sum_{i=0}^{s.size()-1}s[i]*B^{s.size()-i}) mod hash_table_size
        // 求关键字为key的记录首次被散列得到的哈希地址
        int get_init_hash(const string & key);

        // 获取记录的哈希值
        int get_init_hash(const MyRecordType& rc);

        // 增长哈希表，从而控制冲突
        void enlarge();

        // 给定关键字key，结合再散列方法，返回它在当前哈希表中应该出现的位置的下标
        int hash_index_in_current_table(const string& key);

    public:
        MyHashTable(ReHashType rht);
        MyHashTable(const vector<MyRecordType> &vecOfStr, ReHashType rht); // 构造哈希表的同时，把迭代器的数据放入哈希表
        ~MyHashTable();

        // 插入记录rc
        void insert_element(const MyRecordType &rc);

        // 若关键字为key的记录，则删除关键字为key的记录并返回true，否则返回false
        Status remove_element(const string & key);

        // 判断关键字为key的记录是否存在，若存在则返回true，否则返回false
        bool exist(const string &key)
        {
            // 注意标志位的作用
            return entries[hash_index_in_current_table(key)].get_key() != NULL_KEY;
        }

        // 
        string get_data(const string & key)
        {
            return entries[hash_index_in_current_table(key)].get_data();
        }
        
        void show();
        
};

// 重载<< 运算符，便于输出MyRecord类型
ostream & operator<<(ostream& out, const MyRecordType & rc);

#endif