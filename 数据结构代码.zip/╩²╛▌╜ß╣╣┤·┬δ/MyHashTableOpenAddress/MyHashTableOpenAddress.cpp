#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>

#include "MyHashTableOpenAddress.h"

using namespace std;

//#define debug_mode

const int FAILURE = -1; // 

const int OK = 1;
const int ERROR = 0;

// 哈希函数：(sum_{i=0}^{s.size()-1}s[i]*B^{s.size()-i}) mod hash_table_size
// 求关键字为key的记录首次被散列得到的哈希地址
int MyHashTable::get_init_hash(const string & key) 
{
    string s = key; // 获取关键字
    // 根据关键字计算哈希值
    int res = 0;
    for (int i = 0; i < s.size(); ++i) 
    {
        res = (LL)(res * B + s[i]) % table_size;
    }
    return res;
}

// 重载，求记录首次被散列得到的地址
int MyHashTable::get_init_hash(const MyRecordType& rc) 
{
    return get_init_hash(rc.get_key());
}

// 生成线性探测、二次探测和为随机探测的增量序列
void MyHashTable::generate_increment_squences()
{
    // 为增量序列分配存储空间
    increments = new LL[RE_HASH_LIMIT];

    if(!increments)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }

    switch (rht)
    {
        case ReHashType::LINEAR:
            // 线性探测再散列的增量序列
            for(int i = 0; i < RE_HASH_LIMIT; i++)
            {
                increments[i] = i + 1;
            }
            break;

        case ReHashType::SQUARE:
            // 二次探测再散列的增量序列
            for(int i = 0; i < RE_HASH_LIMIT; i++)
            {
                increments[i] = (i / 2 + 1) * (i / 2 + 1);
                if(i % 2 == 1)
                {
                    increments[i] = -increments[i];
                }
            }
            break;

        case ReHashType::PSURAND:
            // 伪随机探测再散列的增量序列
            srand(time(NULL));
            for(int i = 0; i < RE_HASH_LIMIT; i++)
            {
                increments[i] = rand() % table_size; // 限定增量大小避免运算溢出
            }
            break;

        default:
            exit(FAILURE);
    }
}

// 构造函数，需要给出解决冲突的方法
MyHashTable::MyHashTable(ReHashType rht = ReHashType::LINEAR)
{
    this->rht = rht; // 注意this指针
    table_size_update_time = 0; // 初生成的哈希数组，长度被更新次数为0
    table_size = INCREASING_TABLE_SIZES[table_size_update_time]; // 从长度数组获取元素，从而确定哈希表长度

    // 分配存储空间
    entries = new MyRecordType[table_size];
    if(!entries)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    element_count = 0; // 表明这是一张空表，未填入任何信息

    // 生成线性探测、二次探测和为随机探测的增量序列
    generate_increment_squences();
}

// 对赋值号进行重载，支持MyRecordType类型的对象之间进行用户自定义的赋值（无必要）
MyRecordType MyRecordType::operator=(const MyRecordType & rc)
{
    this->data = rc.data;
    this->key = rc.key;
    return *this;
}

// 对<<进行重载，支持自定义的cout操作
ostream & operator<<(ostream& out, const MyRecordType & rc)
{
    out << rc.get_key() << ": " << rc.get_data();
    return out;
}

// 增长哈希表，从而控制冲突
void MyHashTable::enlarge()
{
#ifdef debug_mode
    cout << "***to enlarge the hash table***" << endl;
#endif
    MyRecordType* old_entries = entries; // 先保存原来哈希数组的地址，稍后将从这里获取数据
#ifdef debug_mode
    cout << "original table size: " << table_size << endl;
#endif
    // 分配更大的存储空间
    table_size = INCREASING_TABLE_SIZES[++table_size_update_time];
#ifdef debug_mode
    cout << "hash table size has become " << table_size << endl;
#endif
    entries = new MyRecordType[table_size]; // 按新的大小分配存储空间
    if(!entries)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    element_count = 0; // 新建的表没有元素

    // 将之前的哈希表的记录搬过来
    for(int i = 0; i < INCREASING_TABLE_SIZES[table_size_update_time - 1]; i++) // -1是要用增长之前的表长
    {
        // 空的条目不需要搬动
        if(old_entries[i].get_key() == NULL_KEY)
        {
            continue;
        }
        insert_element(old_entries[i]);
#ifdef debug_mode
        cout << "right after enlarging this hash table, having just re-inserted " << i << ": " << old_entries[i] << endl;
#endif
    }

    // 销毁旧的哈希数组
    delete[] old_entries;
}

// 给定关键字key，结合再散列方法，返回它在当前哈希表中应该出现的位置的下标
int MyHashTable::hash_index_in_current_table(const string& key)
{
    // 计算初始哈希
    int init_index = get_init_hash(key);
    int proposed_index = init_index;
    int i = 0;

   // 哈希目标条目非空，装载的非本关键字，并且再哈希次数未到达上限
    while(entries[proposed_index].get_key() != NULL_KEY && entries[proposed_index].get_key() != key && i < RE_HASH_LIMIT)
    {
#ifdef debug_mode
        cout << "collisions: hashing to " << proposed_index << ", which contains the record " << entries[proposed_index] << endl; 
#endif
        // 再哈希公式
        proposed_index = (init_index + increments[i++]) % table_size;
#ifdef debug_mode
        if(proposed_index < 0)
        {
            cout << "the proposed index is smaller than 0" << endl;
        }
#endif
        // 伪随机再散列和平方再散列中可能出现这种情况
        while(proposed_index < 0)
        {
            proposed_index += table_size;
        }

    }
    // 再哈希次数已达上限，用户需要重新设置上限
    if(i == RE_HASH_LIMIT)
    {
        cout << "insufficient re-hash num" << endl;
        exit(FAILURE);
    }
    return proposed_index; 
}

// 把数据元素e插入到哈希表中，若哈希表中已存在关键字为e.key的记录，则更新该记录
void MyHashTable::insert_element(const MyRecordType &rc)
{
#ifdef debug_mode
    cout << "to insert " << rc << endl;
#endif

    int target_index = hash_index_in_current_table(rc.get_key());

    // 被插入元素的关键字在哈希表中未出现（往空条目中插入记录）
    if(entries[target_index].get_key() == NULL_KEY)
    {
        element_count++;
#ifdef debug_mode
        cout << "element_count increased" << endl;
#endif
    }

    // 把元素装入哈希表（如果关键字为rc.get_key()的元素已经存在，则更新该元素）
    entries[target_index] = rc;
#ifdef debug_mode
    cout << "final index hashed to " << target_index << endl;
#endif

    // 装填因子大于0.8
    if(element_count * 5 > table_size * 4)
    {
        enlarge(); // 扩容
    }
}

// 带参构造函数
MyHashTable::MyHashTable(const vector<MyRecordType> & vecOfRC, ReHashType rht = ReHashType::LINEAR)
{
    this->rht = rht; // 注意this指针
    table_size_update_time = 0;

    // 根据我们使用的表长是素数序列{7, 11, 13, 17, 19, 23, 57, 97}，所以至少会留出4个空位
    while(INCREASING_TABLE_SIZES[table_size_update_time] < 2 * vecOfRC.size())
    {
        ++table_size_update_time;
    }
    table_size = INCREASING_TABLE_SIZES[table_size_update_time];

    // 分配存储空间
    entries = new MyRecordType[table_size];
    if(!entries)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    element_count = 0; // 尚未插入任何元素，初始化为零

    // 生成用于再散列的序列
    generate_increment_squences();

    // 逐条插入记录
    for(int i = 0; i < vecOfRC.size(); i++)
    {
        insert_element(vecOfRC[i]);
    }
}

// 若关键字为key的记录，则删除关键字为key的记录并返回true，否则返回false
Status MyHashTable::remove_element(const string & key)
{
    if(!exist(key)) //
    {
        return ERROR;
    }
    // 注意这个技巧，删除经常都是设置一下标志位就完事
    entries[hash_index_in_current_table(key)].set_key(NULL_KEY);
    return OK;
}

void MyHashTable::show()
{
    cout << "The table size is " << table_size << endl;
    cout << "Below are " << element_count << " elements" << endl;
    cout << "The loading factor is " << round(element_count / (float)table_size * 100) / 100 << endl; 
    for(int i = 0; i < table_size; i++)
    {
        if(entries[i].get_key() != NULL_KEY)
            cout << i << ": " << entries[i] << endl;
    }
    cout << endl;
}

// 析构函数
MyHashTable::~MyHashTable()
{
    delete[] increments;
    delete[] entries;
}