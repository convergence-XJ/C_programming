#include <iostream>
#include <fstream>
#include "MyHashTableOpenAddress.h"

//#define even_id_mode

using namespace std;

const int SUCCESS = 0;
const int MAX_STR_LEN = 1024;

#ifdef even_id_mode
const string FILE_NAME = "data_file_4_even_ids.txt";
#else
const string FILE_NAME = "data_file_4_odd_ids.txt";
#endif


// 给定关键字key，返回对应的内容，
// 如果关键字key不存在，则返回"no such person"
string words_by_person(MyHashTable &htable, const string name)
{
    if(htable.exist(name))
    {
        return htable.get_data(name);
    }
    return "no such person";
}

int main()
{
    vector<MyRecordType> vecOfRC;

    ifstream in_file(FILE_NAME);
    if(!in_file)
    {
        cout << "cannot open " << FILE_NAME << endl;
        exit(EXIT_FAILURE);
    }

    char temp_str1[MAX_STR_LEN], temp_str2[MAX_STR_LEN];
    while(in_file)
    {
        in_file.getline(temp_str1, MAX_STR_LEN);
        in_file.getline(temp_str2, MAX_STR_LEN);
        vecOfRC.push_back(MyRecordType(temp_str1, temp_str2));
    }
    in_file.close();

    // MyHashTable htable(vecOfRC, ReHashType::LINEAR);
    // MyHashTable htable(vecOfRC, ReHashType::SQUARE);
    MyHashTable htable(vecOfRC, ReHashType::LINEAR);
    htable.show();

    string name = "Jack";
    cout << name << " says: " << words_by_person(htable, name) << endl;
    name = "Tom";
    cout << name << " says: " << words_by_person(htable, name) << endl;
    name = "Rick";
    cout << name << " says: " << words_by_person(htable, name) << endl;

    name = "Tom";
    if(!htable.remove_element(name))
    {
        cout << "cannot remove " << name << "'s record since it does not exist" << endl;
    }
    else
    {
        cout << "after removing " << name << "'s record, the hash table has become" << endl;
        htable.show();
    }

    name = "Steve";
    if(!htable.remove_element(name))
    {
        cout << "cannot remove " << name << "'s record since it does not exist" << endl;
    }
    else
    {
        cout << "after removing " << name << "'s record, the hash table has become" << endl;
        htable.show();
    }
    
    
    return SUCCESS;
}