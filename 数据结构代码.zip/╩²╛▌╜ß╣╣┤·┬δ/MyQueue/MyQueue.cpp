#include <iostream>
#include <stdio.h>
#include "MyQueue.h"

using namespace std;

// 无参构造函数
MyQueue::MyQueue()
{
    array_capacity = INIT_SIZE; // 确定容量
    arr = new int[array_capacity + 1]; // 分配空间
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    head = tail = 0; // 空队列的头尾指针相等
}

// 带参构造函数
MyQueue::MyQueue(int* a, int n)
{
    // 确定容量
    array_capacity = INIT_SIZE > n ? INIT_SIZE : n;
    // 分配空间
    arr = new int[array_capacity + 1];
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    // 空队列的头尾指针相等
    head = 0;
    for(int i = 0; i < n; i++)
    {
        arr[i] = a[i]; // 填入
    }
    tail = n; // 最后一个元素的下标加1
}

// 析构函数
MyQueue::~MyQueue()
{
    delete[] arr;
}

// 打印
void MyQueue::show()
{
    for(int i = head; i != tail;)
    {
        cout << arr[i] << '\t';
        if(i == array_capacity) // 注意数组长度为capacity+1
        {
            i = 0; // 自增后回到数组首元素位置
        }
        else
        {
            i++;
        }
    }
}

// 入队
void MyQueue::enQueue(int x)
{
    if(head == (tail + 1) % (array_capacity + 1)) // 满队
    {
        // 多一倍的空间，肯定不需要折回，可按通常数组处理
        int* new_arr = new int[array_capacity * 2 + 1];
        int j = head;
        /*i用于扫描原数组，j用于扫描新数组*/
        for(int i = head; i != tail; j++)
        /*head下标保持不变，因此i和j起点相同*/
        {
            new_arr[j] = arr[i];
            if(i == array_capacity) // 原数组已经扫到尽头
            {
                i = 0; // 折回
            }
            else
            {
                i++;
            }  
        } // 循环结束时，j为有效元素的下一个位置的下标
        delete[] arr; // 销毁原数组
        arr = new_arr; // 关联新数组
        tail = j; // 维护队尾下一个位置的下标
        array_capacity *= 2;
    } // 循环结束，不满队
    arr[tail] = x;
    if(tail == array_capacity)
    {
        tail = 0;
    }
    else
    {
        tail++;
    }
}

// 出队
int MyQueue::deQueue()
{
    if(tail == head)
    {
        cout << "underflow" << endl;
        return ERROR;
    }
    int x = arr[head]; // 获取队首元素
    if(head == array_capacity)
    {
        head = 0; // 折回
    }
    else
    {
        head++;
    }
    return x;
}