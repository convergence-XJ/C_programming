#include "MyDualLinkedListsWithoutSentinels.h"
#include <vector>

void print_list(Du_Linked_List list)
/*给定不带哨兵结点的双链表list，输出各个元素的值*/
{
    DuNode* p = list;
    while(p) // p仍指向元素
    {
        printf("%d\t", p->data);
        p = p->next;
    }
}

int get_element(const Du_Linked_List list, int i, int &v)
//在不带哨兵结点的双链表list中，
//根据序号i获取元素的值，用v返回链表中第i个数据元素的值
{
    DuNode* p = list; // 指向第一个结点
    while(i > 1 && p) // 未定位到i处并且p仍指向元素
    {
        p = p->next; // 指向下一元素
        i--; // 
    }
    if(!p) // 已经到达链末端 
    {
        return ERROR; 
    }   
    v = p->data; // 获取数据
    return OK;
}

DuNode *locate_element(const Du_Linked_List list, int v)
//在不带哨兵结点的双链表list中，查找值为v的元素，如找到返回结点的地址，否则返回NULL
{
    DuNode* p = list; // 指向第一个结点
    while(p && p->data != v) // 仍指向有效元素，且未找到数据
    {
        p = p->next;
    }
    return p; // 无论是否找到值为v的元素，都可以返回p
}

int list_insert(Du_Linked_List &list, int i, int v)
//在不带哨兵结点的双链表list中，第i个位置插入值为v的新结点（新结点成为第i个结点）
{
    DuNode* q = (DuNode*) malloc (sizeof(DuNode));
    if(!q)
    {
        return ERROR;
    }
    q->data = v;
    q->prev = NULL; // 初始化指针
    q->next = NULL;
    if(i == 1) // 没有哨兵结点，要分类讨论
    {
        // 直接插入到最开头
        q->next = list;
        q->prev = NULL;
        list->prev = q;
        list = q;
    }
    else if(i > 1)
    {
        DuNode * p = list;
        // 如果i为2，直接插到p所指结点之后，否则p指针要后移
        while(i > 2 && p)
        {
            p = p->next;
            i--;
        }
        if(!p) // i太大，找不到合适的位置插入
        {
            return ERROR;
        }
        // 以下要插入到p所指结点之后
        q->prev = p;
        q->next = p->next;
        p->next->prev = q;
        p->next = q;
    }
    else // i的值非法
    {
        return ERROR;
    }
    return OK;
}

int list_insert_before(Du_Linked_List &list, DuNode *p_to_inserted, DuNode* p_to_successor)
/*在不带哨兵结点的非循环双链表list中，在p_to_successor指针所指的结点之前，插入p_to_inserted指针所指的结点*/
{
    if(!p_to_inserted || !p_to_successor)
    {
        return ERROR;
    }
    if(p_to_successor == list)
    {
        p_to_inserted->next = p_to_successor;
        p_to_inserted->prev = NULL;
        list->prev = p_to_inserted;
        list = p_to_inserted;
    }
    else
    {
        p_to_inserted->prev = p_to_successor->prev;
        p_to_inserted->next = p_to_successor;
        p_to_successor->prev->next = p_to_inserted;
        p_to_successor->prev = p_to_inserted;    
    } 
    return OK;
}

int list_insert_after(Du_Linked_List &list, DuNode *p_to_inserted, DuNode* p_to_predecessor)
/*在不带哨兵结点的非循环双链表中，在p_to_predecessor指针所指的结点之后，插入p_to_inserted指针所指的结点*/
{
    if(!p_to_inserted || !p_to_predecessor)
    {
        return ERROR;
    }
    if(p_to_predecessor->next == NULL)
    {
        p_to_inserted->prev = p_to_predecessor;
        p_to_inserted->next = NULL;
        p_to_predecessor->next = p_to_inserted;
    }
    else
    {
        DuNode* p_to_successor = p_to_predecessor->next;
        if(!list_insert_before(list, p_to_inserted, p_to_successor))
        {
            return ERROR;
        }
    }
    return OK;
}

int list_delete(Du_Linked_List list, int i)
//在不带哨兵结点的双链表list中，删除第i个元素
{
    DuNode* p = list; // p用于指向待删除元素，已经定位第一个元素
    while(i > 1 && p) // 后面最多移动i-1次指针
    {
        p = p->next;
        i--;
    }
    if(!p) // 已经到达链表末端
    {
        return ERROR;
    }
    if(p->prev) // 注意首尾结点要特殊处理
    {
        p->prev->next = p->next;
    } 
    if(p->next)
    {
        p->next->prev = p->prev;
    }
    free(p);
    return OK;
}

int create_list_from_tail_to_head(Du_Linked_List &list, int n)
//逆位序输入n个元素的值，建立不带表哨兵结点的双链表list
{
    if(n <= 0)
    {
        return ERROR;
    }
    // 首结点要特殊处理
    DuNode* p = (DuNode*) malloc (sizeof(DuNode));
    if(!p)
    {
        return ERROR;
    }
    printf("Input the value of an element:\n");
    scanf("%d", &(p->data));
    p->prev = NULL;
    p->next = NULL;
    list = p;
    // 对剩下的结点
    for(int i = 1; i < n; i++) // 因为前面已经创建了一个结点，所以这里少一个
    {
        p = (DuNode*) malloc (sizeof(DuNode));
        if(!p)
        {
            return ERROR;
        }
        printf("Input the value of an element:\n");
        scanf("%d", &(p->data));
        p->prev = NULL;
        p->next = NULL;
        if(!list_insert_before(list, p, list)) // before the first element
        {
            return ERROR;
        }
    }
    return OK;
}

//逆序输入元素的值，建立不带表哨兵结点的双链表list，数据来源于迭代器
int create_list_from_tail_to_head(Du_Linked_List &list, const std::vector<int> &vecOfData)
{
    // 首结点要特殊处理
    DuNode* p = (DuNode*) malloc (sizeof(DuNode));
    if(!p)
    {
        return ERROR;
    }
    p->data = vecOfData[0];
    p->prev = NULL;
    p->next = NULL;
    list = p;
    // 对剩下的结点
    for(int i = 1; i < vecOfData.size(); i++) // 因为前面已经创建了一个结点，所以这里少一个
    {
        p = (DuNode*) malloc (sizeof(DuNode));
        if(!p)
        {
            return ERROR;
        }
        p->data = vecOfData[i];
        p->prev = NULL;
        p->next = NULL;
        if(!list_insert_before(list, p, list)) // before the first element
        {
            return ERROR;
        }
    }
    return OK;  
}

int create_list_from_head_to_tail(Du_Linked_List & list, int n)
//顺序输入n个元素的值，建立不带表哨兵结点的双链表list
{
    if(n <= 0)
    {
        return ERROR;
    }
    //首结点特殊处理
    DuNode* p = (DuNode*) malloc (sizeof(DuNode));
    if(!p)
    {
        return ERROR;
    }
    printf("Input the value of an element:\n");
    scanf("%d", &(p->data));
    p->prev = NULL;
    p->next = NULL;
    list = p;
    // 对剩下的结点
    DuNode* tail_ptr = p; // 最后元素的地址
    for(int i = 1; i < n; i++)
    {
        p = (DuNode*) malloc (sizeof(DuNode));
        if(!p)
        {
            return ERROR;
        }
        printf("Input the value of an element:\n");
        scanf("%d", &(p->data));
        if(!list_insert_after(list, p, tail_ptr))
        {
            return ERROR;
        }
        tail_ptr = p;
    }
    return OK;    
}

//顺序输入元素的值，建立不带表哨兵结点的双链表list，数据来源于文件
int create_list_from_head_to_tail(Du_Linked_List & list, const std::vector<int>& vecOfData)
{
    //首结点特殊处理
    DuNode* p = (DuNode*) malloc (sizeof(DuNode));
    if(!p)
    {
        return ERROR;
    }
    p->data = vecOfData[0];
    p->prev = NULL;
    p->next = NULL;
    list = p;
    // 对剩下的结点
    DuNode* tail_ptr = p; // 最后元素的地址
    for(int i = 1; i < vecOfData.size(); i++)
    {
        p = (DuNode*) malloc (sizeof(DuNode));
        if(!p)
        {
            return ERROR;
        }
        p->data = vecOfData[i];
        if(!list_insert_after(list, p, tail_ptr))
        {
            return ERROR;
        }
        tail_ptr = p;
    }
    return OK;
}

int destroy_list(Du_Linked_List list)
/*给定不带哨兵结点的非循环双链表list，销毁它并回收空间*/
{
    if(!list)
    {
        return ERROR;
    }
    DuNode* p = list;
    do{
        DuNode *q = p;
        p = p->next;
        free(q);
    }while(p);
    return OK;
}