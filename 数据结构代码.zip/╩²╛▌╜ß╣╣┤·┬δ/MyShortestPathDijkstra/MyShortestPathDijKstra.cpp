#include <iostream>
#include <vector>
#include "MyShortestPathDijKstra.h"

// #define debug_mode

using namespace std;

// 用Dijkstra算法求有向网G的k号顶点到其余顶点的最短路径
vector<pair<int, int>> shortest_path_dijkstra(const AMGraph &my_graph, const int k)
// 对返回迭代器中的每一个元组，前一个代表最短路径上的前驱，后一个代表最短路径长度
{
    // 给定顶点下标，给出是否已求出从k号顶点通往它的最短路径
    bool *determined = new bool[my_graph.vertex_num + 1];

    // 给定顶点下标，给出当前发现的最短路径长度（这需要在以后不断被更新）
    int* curr_min_dist = new int[my_graph.vertex_num + 1];

    // 给定顶点下标，给出最短路径上它的前驱的下标，将前驱后继连起来得到最短路径
    int *predecessor = new int[my_graph.vertex_num + 1];

    if(!determined || !curr_min_dist || !predecessor)
    {
        cout << "insufficient memory" << endl;
        exit(EXIT_FAILURE);
    }

    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        determined[i] = false; // 一开始都未求得最短路径
        curr_min_dist[i] = my_graph.arcs[k][i]; // 以边长作为初始最短路径长
        if(curr_min_dist[i] < DIST_INFINITY) // 存在一条边
        {
            predecessor[i] = k;           
        }
        else
        {
            predecessor[i] = -1; // 设为非法值，这是常见编程技巧
        }
    }

    determined[k] = true; // 到达k号顶点的最短路径已确定
    curr_min_dist[k] = 0; // 长度为0

    // 注意到在我们的邻接矩阵数据结构中，顶点数组的0号下标是弃用的
    curr_min_dist[0] = DIST_INFINITY; // 这里借助无用空间，并设置非法值（用心体会这个编程技巧）

    /*初始化已完成，以下进行循环，循环体每执行一次，就求出通往一个顶点的最短路径*/
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        // 以下在待求路径的结点中，寻求路径最短的那个
        int best_next_vertex_index = 0; // 设为非法值（这是编程技巧）
        for(int j = 1; j <= my_graph.vertex_num; j++)
        {
            if(determined[j]) // j号顶点的最短路径已经求出
            {
                continue; // 不再考虑
            }
#ifdef debug_mode
            // cout << my_graph.vertices[j] << " has not been determined." << endl;
            // cout << "curr min dist: " << curr_min_dist[j] << endl;
#endif
            if(curr_min_dist[j] < curr_min_dist[best_next_vertex_index]) // 找到更短的路径
            {
                // cout << "updated best next to be " << my_graph.vertices[j] << endl;
                best_next_vertex_index = j; // 更新顶点（下标）
            }
        }
        // 通往best_next_vertex_index处的顶点的最短路径已经求出

        if(!best_next_vertex_index) // 未得到更新
        {
            break; // 已无可达结点需要考虑
        }
#ifdef debug_mode
cout << "obtain the next best: " << my_graph.vertices[best_next_vertex_index] << ", path len: " << curr_min_dist[best_next_vertex_index] << endl;
cout << "connected to " << my_graph.vertices[predecessor[best_next_vertex_index]] << endl;
#endif
        // 标记为已求出
        determined[best_next_vertex_index] = true;

        // 更新从k号顶点出发，到达各待定顶点的最短路径
        for(int j = 1; j <= my_graph.vertex_num; j++)
        {
            if(determined[j]) // 已经求出最短路径
            {
                continue; // 跳过
            }

            // 途经新确定的结点带来更短的路径
            // 与新进的顶点相邻，并且因此产生更短路径
            if(my_graph.arcs[best_next_vertex_index][j] != DIST_INFINITY && curr_min_dist[best_next_vertex_index] + my_graph.arcs[best_next_vertex_index][j] < curr_min_dist[j])
            {
#ifdef debug_mode
                cout << "updating path info for " << my_graph.vertices[j] << endl;
#endif
                // 更新目前所知道的最短路径长度
                curr_min_dist[j] = curr_min_dist[best_next_vertex_index] + my_graph.arcs[best_next_vertex_index][j];
                // 更新最短路径
                predecessor[j] = best_next_vertex_index;
#ifdef debug_mode
                cout << "path len becomes: " << curr_min_dist[j] << endl;
                cout << "predecessor becomes: " << my_graph.vertices[predecessor[j]] << endl;
#endif
            }
        }
    }

    // 整理求得的结果
    vector<pair<int, int>> predecessorIndexAndDists;
    predecessorIndexAndDists.push_back(pair<int, int>(0, 0)); // 0号单元弃用
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        predecessorIndexAndDists.push_back(pair<int, int>(predecessor[i], curr_min_dist[i]));
    }
    
    // 回收空间
    delete[] determined;
    delete[] curr_min_dist;
    delete[] predecessor;

    // 返回结算结果
    return predecessorIndexAndDists;
}

// 根据最短路径信息，打印从k号顶点通往l号结点的最短路径
void print_shortest_path(const AMGraph & my_graph, int k, int l, const vector<pair<int, int>>& predecessorIndexAndDists)
{
    vector<int> path;
    int curr_index = l;
    
    do{
        path.push_back(curr_index);
        curr_index = predecessorIndexAndDists[curr_index].first;
    }while(curr_index != -1);

    cout << "shortest path from " << my_graph.vertices[k] << " to " << my_graph.vertices[l] << endl;
    for(int i = path.size() - 1; i >= 0; i--)
    {
        cout << my_graph.vertices[path[i]] << ", ";
    }
    cout << endl;
    cout << "shortest dist: " << predecessorIndexAndDists[l].second << endl;
}