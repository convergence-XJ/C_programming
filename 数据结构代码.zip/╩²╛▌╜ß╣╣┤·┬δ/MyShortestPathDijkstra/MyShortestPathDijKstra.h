#ifndef MY_SHORTEST_PATH_DIJKSTRA_H
#define MY_SHORTEST_PATH_DIJKSTRA_H

#include <vector>
#include "MyAdjacencyMatrix.h"

using namespace std;


// 用Dijkstra算法求有向网G的k号顶点到其余顶点的最短路径
// 对返回迭代器中的每一个元组，前一个代表最短路径上的前驱，后一个代表最短路径长度
vector<pair<int, int>> shortest_path_dijkstra(const AMGraph &my_graph, const int k);


// 根据最短路径信息，打印从k号顶点通往l号结点的最短路径
void print_shortest_path(const AMGraph & my_graph, int k, int l, const vector<pair<int, int>>& predecessorIndexAndDists);
#endif