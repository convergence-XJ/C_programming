#ifndef MY_DUAL_CIRCULAR_LINKED_LISTS_WITH_SENTINELS_H
#define MY_DUAL_CIRCULAR_LINKED_LISTS_WITH_SENTINELS_H

#include <stdio.h>
#include <stdlib.h>
#include <vector>

#define OK 1 // 涉及指针和内存分配的函数，运行正常返回
#define ERROR 0 // 运行异常返回


typedef struct MyDuNode{
    int data;
    MyDuNode* prev;
    MyDuNode* next;
} MyDuNode, *My_Du_Linked_List;

/*给定带哨兵结点的循环双链表list，输出各个元素的值*/
int print_list(My_Du_Linked_List list);

/*初始化链表*/
int initialize_list(My_Du_Linked_List &list);

//在带哨兵结点的循环双链表list中，
//根据序号i获取元素的值，用v返回链表中第i个数据元素的值
int get_element(const My_Du_Linked_List list, int i, int &v);

//在带哨兵结点的循环双链表list中，查找值为v的元素，如找到返回结点的地址，否则返回NULL
MyDuNode *locate_element(const My_Du_Linked_List list, int v);

//在带哨兵结点的循环双链表中，第i个位置插入值为v的新结点
int list_insert(My_Du_Linked_List &list, int i, int v);

/*在p_to_successor指针所指的结点之前，插入p_to_inserted指针所指的结点*/
int list_insert_before(MyDuNode *p_to_inserted, MyDuNode* p_to_successor);

/*在p_to_predecessor指针所指的结点之后，插入p_to_inserted指针所指的结点*/
int list_insert_after(MyDuNode *p_to_inserted, MyDuNode* p_to_predecessor);

//在带哨兵结点的循环双链表中，删除第i个元素
int list_delete(My_Du_Linked_List list, int i);

//逆位序输入n个元素的值，建立带表哨兵结点的循环双链表list
int create_list_from_tail_to_head(My_Du_Linked_List &list, int n);

//逆位序输入元素的值，建立带表哨兵结点的循环双链表list，数据来自于迭代器
int create_list_from_tail_to_head(My_Du_Linked_List &list, std::vector<int> vecOfData);

//顺序输入n个元素的值，建立带表哨兵结点的循环双链表list
int create_list_from_head_to_tail(My_Du_Linked_List & list, int n);

//顺序输入元素的值，建立带表哨兵结点的循环双链表list，数据来自于迭代器
int create_list_from_head_to_tail(My_Du_Linked_List & list, std::vector<int> vecOfData);

/*给定带哨兵结点的循环双链表list，销毁它并回收空间*/
int destroy_list(My_Du_Linked_List list);

#endif