#include "MyDualCircularLinkedListsWithSentinels.h"

int print_list(My_Du_Linked_List list)
/*给定带哨兵结点的循环双链表list，输出各个元素的值*/
{
    if(!list)
    {
        return ERROR;
    }
    MyDuNode* p = list->next;
    while(p != list)
    {
        // printf("%p: %d\t", p, p->data);
        printf("%d\t", p->data);
        p = p->next;
    }
    return OK;
}

int initialize_list(My_Du_Linked_List &list)
{
    // 创建哨兵结点
    list = (MyDuNode*) malloc (sizeof(MyDuNode));
    if(!list)
    {
        printf("insufficient space\n");
        exit(1);
    }
    list->next = list;
    list->prev = list;
    return OK;
}

int get_element(const My_Du_Linked_List list, int i, int &v)
//在带哨兵结点的循环双链表list中，
//根据序号i获取元素的值，用v返回链表中第i个数据元素的值
{
    MyDuNode* p = list->next; // 指向第一个有效结点
    while(i > 1 && p != list) // 未定位到i处并且p指向有效元素
    {
        p = p->next; // 指向下一元素
        i--; // 
    }
    if(p == list) // 已经到达链末端 
    {
        return ERROR; 
    }   
    v = p->data; // 获取数据
    return OK;
}

MyDuNode *locate_element(const My_Du_Linked_List list, int v)
//在带哨兵结点的循环双链表list中，查找值为v的元素，如找到返回结点的地址，否则返回NULL
{
    MyDuNode* p = list->next; // 指向第一个有效结点
    while(p != list && p->data != v) // 仍指向有效元素，且未找到数据
    {
        p = p->next;
    }
    if(p->data == v)
    {
        return p;
    }
    return NULL;
}

int list_insert(My_Du_Linked_List &list, int i, int v)
//在带哨兵结点的循环双链表中，第i个位置插入值为v的新结点
{
    MyDuNode* p = list;
    MyDuNode* q = (MyDuNode*) malloc (sizeof(MyDuNode));
    if(!q)
    {
        return ERROR;
    }
    q->data = v;
    q->prev = NULL;
    q->next = NULL;

    do{
        p = p->next;
        i--;
    }while(i > 0 && p != list); // 最多移动i次指针，p可以取值为list，但这应该是最后的尝试
    if(!p) // 已经到达链表末端
    {
        return ERROR;
    }
    q->prev = p->prev;
    q->next = p;
    p->prev->next = q;
    p->prev = q;
    
    return OK;
}

int list_insert_before(MyDuNode *p_to_inserted, MyDuNode* p_to_successor)
/*在p_to_successor指针所指的结点之前，插入p_to_inserted指针所指的结点*/
{
    if(!p_to_inserted || !p_to_successor)
    {
        return ERROR;
    }
    p_to_inserted->prev = p_to_successor->prev;
    p_to_inserted->next = p_to_successor;
    p_to_successor->prev->next = p_to_inserted;
    p_to_successor->prev = p_to_inserted;
    return OK;
}

int list_insert_after(MyDuNode *p_to_inserted, MyDuNode* p_to_predecessor)
/*在p_to_predecessor指针所指的结点之后，插入p_to_inserted指针所指的结点*/
{
    if(!p_to_inserted || !p_to_predecessor)
    {
        return ERROR;
    }
    MyDuNode *p_to_successor = p_to_predecessor->next;
    if(list_insert_before(p_to_inserted, p_to_successor))
    {
        return OK;
    }
    else
    {
        return ERROR;
    }
    
}

int list_delete(My_Du_Linked_List list, int i)
//在带哨兵结点的循环双链表中，删除第i个元素
{
    MyDuNode* p = list->next; // p用于指向待删除元素，已经定位第一个元素
    while(i > 1 && p != list) // 哨兵结点不能被删除，后面最多移动i-1次指针
    {
        p = p->next;
        i--;
    }
    if(p == list) // 已经到达链表末端
    {
        return ERROR;
    }
    p->prev->next = p->next;
    p->next->prev = p->prev;
    free(p);
    return OK;
}

int create_list_from_tail_to_head(My_Du_Linked_List &list, int n)
//逆位序输入n个元素的值，建立带表哨兵结点的循环双链表list
{
    if(n <= 0)
    {
        return ERROR;
    }
    MyDuNode* p = (MyDuNode*) malloc (sizeof(MyDuNode));
    if(!p) // 分配空间失败
    {
        return ERROR;
    }
    list = p;
    list->prev = list;
    list->next = list;
    for(int i = 0; i < n; i++)
    {
        p = (MyDuNode*) malloc (sizeof(MyDuNode));
        if(!p)
        {
            return ERROR;
        }
        printf("Input the value of an element:\n");
        scanf("%d", &(p->data));
        if(!list_insert_before(p, list->next)) // before the first element
        {
            return ERROR;
        }
    }
    return OK;
}

//逆位序输入元素的值，建立带表哨兵结点的循环双链表list，数据来自于迭代器
int create_list_from_tail_to_head(My_Du_Linked_List &list, std::vector<int> vecOfData)
{
    MyDuNode* p = (MyDuNode*) malloc (sizeof(MyDuNode));
    if(!p) // 分配空间失败
    {
        return ERROR;
    }
    list = p;
    list->prev = list;
    list->next = list;
    for(int i = 0; i < vecOfData.size(); i++)
    {
        p = (MyDuNode*) malloc (sizeof(MyDuNode));
        if(!p)
        {
            return ERROR;
        }
        (p->data) = vecOfData[i];
        if(!list_insert_before(p, list->next)) // before the first element
        {
            return ERROR;
        }
    }
    return OK;
}

int create_list_from_head_to_tail(My_Du_Linked_List & list, int n)
//顺序输入n个元素的值，建立带表哨兵结点的循环双链表list
{
    if(n <= 0)
    {
        return ERROR;
    }
    MyDuNode* p = (MyDuNode*) malloc (sizeof(MyDuNode));
    if(!p)
    {
        return ERROR;
    }
    list = p;
    list->prev = list;
    list->next = list;
    for(int i = 0; i < n; i++)
    {
        p = (MyDuNode*) malloc (sizeof(MyDuNode));
        if(!p)
        {
            return ERROR;
        }
        printf("Input the value of an element:\n");
        scanf("%d", &(p->data));
        if(!list_insert_after(p, list->prev))
        {
            return ERROR;
        }
    }
    return OK;    
}

//顺序输入元素的值，建立带表哨兵结点的循环双链表list，数据来自于迭代器
int create_list_from_head_to_tail(My_Du_Linked_List & list, std::vector<int> vecOfData)
{
    MyDuNode* p = (MyDuNode*) malloc (sizeof(MyDuNode));
    if(!p)
    {
        return ERROR;
    }
    list = p;
    list->prev = list;
    list->next = list;
    for(int i = 0; i < vecOfData.size(); i++)
    {
        p = (MyDuNode*) malloc (sizeof(MyDuNode));
        if(!p)
        {
            return ERROR;
        }
        p->data = vecOfData[i];
        if(!list_insert_after(p, list->prev))
        {
            return ERROR;
        }
    }
    return OK;   
}

int destroy_list(My_Du_Linked_List list)
/*给定带哨兵结点的循环双链表list，销毁它并回收空间*/
{
    if(!list)
    {
        return ERROR;
    }
    MyDuNode* p = list;
    do{
        MyDuNode *q = p;
        p = p->next;
        free(q);
    }while(p != list);
    return OK;
}
