#ifndef MY_ADJACENCY_MATRIX
#define MY_ADJACENCY_MATRIX

#include <string>
using namespace std;

// #define undirected_mode

const int ERROR = 0;
const int OK = 1;

typedef string VertexType;
typedef int ArcType;

typedef struct MyAdjacencyMatrix
{
    VertexType* vertices; // 顶点数组，0号单元不用
    ArcType** arcs; // 邻接矩阵，0号行和0号列不用
                    // arc[i][j]表示i号顶点与j号顶点之间的边的权重，若无边则权重为无穷大
    int vertex_num, arc_num; // 顶点数和边数
} AMGraph;

// 利用邻接矩阵创建无向网
int create_undirected_network(AMGraph & my_graph);

// 利用邻接矩阵创建无向网，基于文件提供的数据
int create_undirected_network(AMGraph & my_graph, string file_name);

// 给定无向网，输出各条边以及权重
void print_undirected_network(const AMGraph & my_graph);

// 销毁无向网
int destroy_undirected_graph(AMGraph &my_graph);

// 深度优先访问非连通图，my_graph为邻接矩阵类型
int dfs_traverse(const AMGraph &my_graph);

// 广度优先访问非连通图，my_graph为邻接矩阵类型
int bfs_traverse(const AMGraph &my_graph);
#endif