#include <iostream>
#include <string>
#include "MyAdjacencyMatrix.h"

using namespace std;

#ifdef undirected_mode
const string FILE_NAME = "undirected_data_file.txt";
#else
const string FILE_NAME = "directed_data_file.txt";
#endif

const int FAILURE = 1;

int main()
{
#ifdef undirected_mode
    cout << "Below is an undirected graph" << endl;
#else
    cout << "Below is a directed graph" << endl;
#endif
    AMGraph my_graph;
    create_undirected_network(my_graph, FILE_NAME);
    print_undirected_network(my_graph);
    cout << "below are dfs results:" << endl;
    if(!dfs_traverse(my_graph))
    {
        return ERROR;
    }
    cout << endl;
    cout << "below are bfs results:" << endl;
    if(!bfs_traverse(my_graph))
    {
        return ERROR;
    }
    if(!destroy_undirected_graph(my_graph)) 
        return FAILURE;
    return 0;
}