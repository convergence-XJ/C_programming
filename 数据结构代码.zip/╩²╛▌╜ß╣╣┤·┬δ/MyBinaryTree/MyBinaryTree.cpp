#include <iostream>
#include <string>
#include <map>
#include <deque>
#include <cmath>
#include "MyBinaryTree.h"

using namespace std;

const int ERROR = 0;
const int OK = 1;

// 根据用户输入创建二叉树
void create_binary_tree(MyBinaryTree &bt)
{
    cout << "input data for the current node, # means no data:" << endl;
    string temp_data;
    cin >> temp_data;
    if(temp_data != "#")
    {
        bt = new MyBinaryNode;
        if(!bt)
        {
            cout << "insufficient memory" << endl;
            exit(1);
        }
        bt->data = temp_data;
        bt->lchild = NULL;
        bt->rchild = NULL;
        cout << "down to its left" << endl;
        create_binary_tree(bt->lchild);
        cout << "down to its right" << endl;
        create_binary_tree(bt->rchild);
    }
}

// 以括号的形式，输出二叉树
void print_binary_tree_as_general_list(MyBinaryTree &bt)
{
    if(bt)
    {
        cout << bt->data;
        cout << ",";
        cout << "(";
        print_binary_tree_as_general_list(bt->lchild);
        cout << "),";
        cout << "(";
        print_binary_tree_as_general_list(bt->rchild);
        cout << ")";
    }
}

// 给定二叉树返回数的深度
int depth(const MyBinaryTree &bt)
{
    if(!bt)
    {
        return 0;
    }
    int l_dp = depth(bt->lchild); // 左子树深度
    int r_dp = depth(bt->rchild); // 右子树深度
    return l_dp > r_dp ? (l_dp + 1) : (r_dp + 1);
}

// 给定二叉树返回结点数
int node_count(MyBinaryTree &bt)
{
    if(!bt)
    {
        return 0;
    }
    return node_count(bt->lchild) + node_count(bt->rchild) + 1;
}


// 根据字符串创建二叉树
void create_binary_tree(MyBinaryTree& bt, const string& str)
{
    // 归纳基
    if(str == "")// 代表空子树
    {
        bt = NULL;
        return;
    }
    // 以下分割字符串
    int first_commas = str.find_first_of(",");
    // 父结点的字符串
    string parent_str = str.substr(0, first_commas);
    // 以下查找左子树字符串的结尾，按照括号匹配来找
    int i = first_commas + 1, level = 0;
    do{
        if(str[i] == '(')
        {
            level--;
        }
        else if(str[i] == ')')
        {
            level++;
        }
        i++;
    }while(level != 0);
    // 左子树字符串
    string left_child_str = str.substr(first_commas + 1, i - first_commas - 1 - 1);
    left_child_str = left_child_str.substr(1, left_child_str.size() - 1);
    // 右子树字符串
    string right_child_str = str.substr(i + 1, str.size() - i - 1 - 1);
    right_child_str = right_child_str.substr(1, right_child_str.size() - 1);
    /*
    cout << parent_str << endl;
    cout << left_child_str << endl;
    cout << right_child_str << endl;
    */
    // 创建父结点
    bt = new MyBinaryNode;
    if(!bt)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    bt->lchild = NULL;
    bt->rchild = NULL;
    bt->data = parent_str; // 父结点数据
    // 创建左子树
    create_binary_tree(bt->lchild, left_child_str); //
    // 创建右子树
    create_binary_tree(bt->rchild, right_child_str);
}

// 中序遍历
void in_order_traverse(const MyBinaryTree bt)
{
    if(!bt)
    {
        return;
    }
    in_order_traverse(bt->lchild);
    cout << bt->data << ", ";
    in_order_traverse(bt->rchild);
}

// 中序遍历二叉树（非递归）
void in_order_traverse_nonrecursively(const MyBinaryTree bt)
{
    MyBinaryNode* p = bt;
    deque<MyBinaryTree> bt_pt_stack;
    while(p || !bt_pt_stack.empty())
    // p非空表示仍有往下探索的可能
    // bt_pt_stack非空表示有往上探索的可能
    {
        if(p) // 仍有往下探索的空间
        {
            // 进栈
            bt_pt_stack.push_back(p); // 保存走过的地方，因为没有回退指针，所以只能用堆栈，类似于探索山洞的时候留个几个花生米做记号
            p = p->lchild; // 往左下走，目标是第一个要访问的结点
        }
        else
        {
            MyBinaryNode* q = bt_pt_stack.back(); // 获取栈顶元素
            bt_pt_stack.pop_back(); // 出栈
            cout << q->data << ", "; // 此时(*q)的左子树已经访问完，所以访问(*q)
            p = q->rchild; // 接下来考虑(*q)的右子树
        }
    }
}

// 前序遍历
void pre_order_traverse(const MyBinaryTree bt)
{
    if(!bt)
    {
        return;
    }
    cout << bt->data << ", ";
    pre_order_traverse(bt->lchild);
    pre_order_traverse(bt->rchild);
}

// 后序遍历
void post_order_traverse(const MyBinaryTree bt)
{
    if(!bt)
    {
        return;
    }
    post_order_traverse(bt->lchild);
    post_order_traverse(bt->rchild);
    cout << bt->data << ", ";
}

// 层序遍历
void level_order_traverse(const MyBinaryTree bt)
{
    // 先入队的结点，先被访问
    // 而且它们的孩子也应该先被访问
    queue<MyBinaryTree> que; 
    que.push(bt);
    while(!que.empty())
    {
        MyBinaryTree p = que.front();
        que.pop();
        if(!p)
        {
            continue; // 跳过空指针
        }
        cout << p->data << ", ";
        que.push(p->lchild);
        que.push(p->rchild);
    }
}

// 复制二叉树
void copy_binary_tree(const MyBinaryTree bt, MyBinaryTree &new_bt)
{
    // 归纳基
    if(!bt)
    {
        new_bt = NULL;
        return;
    }
    // 
    new_bt = new MyBinaryNode;
    if(!new_bt)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    // 复制结点数据
    new_bt->data = bt->data;
    // 复制子树
    copy_binary_tree(bt->lchild, new_bt->lchild);
    copy_binary_tree(bt->rchild, new_bt->rchild);
}

// 求每个结点指针的父结点指针（根结点除外）
void get_parents_for_nodes(const MyBinaryTree &bt, map<MyBinaryTree, MyBinaryTree> &mmap)
{
    if(!bt)
    {
        return;
    }
    // 存在左孩子
    if(bt->lchild)
    {
        mmap[bt->lchild] = bt;
    }
    // 存在右孩子
    if(bt->rchild)
    {
        mmap[bt->rchild] = bt;
    }
    // 递归
    get_parents_for_nodes(bt->lchild, mmap);
    get_parents_for_nodes(bt->rchild, mmap);
}

void _get_levels_for_nodes(const MyBinaryTree &bt, map<MyBinaryTree, int> &node2Level)
{
    if(!bt)
    {
        return;
    }
    // 存在左孩子
    if(bt->lchild)
    {
        node2Level[bt->lchild] = node2Level[bt] + 1; // 层数加1
    }
    // 存在右孩子
    if(bt->rchild)
    {
        node2Level[bt->rchild] = node2Level[bt] + 1; // 层数加1
    }
    // 递归调用
    _get_levels_for_nodes(bt->lchild, node2Level);
    _get_levels_for_nodes(bt->rchild, node2Level);
}

void get_levels_for_nodes(const MyBinaryTree &bt, map<MyBinaryTree, int> &node2Level)
{
    if(!bt)
    {
        return; // 
    }
    node2Level[bt] = 1; // 根结点的层数规定为1
    _get_levels_for_nodes(bt, node2Level);
}

// 层序保存指针
void get_level_order_pointers(const MyBinaryTree bt, vector<MyBinaryTree>& vecOfNodePtr)
{
    queue<MyBinaryTree> que;
    que.push(bt);
    while(!que.empty())
    {
        MyBinaryTree p = que.front();
        que.pop();
        if(!p)
        {
            continue;
        }
        vecOfNodePtr.push_back(p); // 指针进入迭代器
        que.push(p->lchild);
        que.push(p->rchild);
    }
}

// 给定二叉树，计算每一个层的相邻两结点之间的间距
void get_node_distances(const MyBinaryTree &bt, vector<int>& level2PositionDistance)
{
    int dp = depth(bt);
    int two2Dp = 1;
    for(int i = 0; i < dp; i++)
    {
        two2Dp *= 2; // 2^{dp}
    }
    level2PositionDistance.push_back(two2Dp * 2);
    for(int i = 1; i <= dp; i++)
    {
        // 每层相邻两个位置的间距，注意倍增关系
        level2PositionDistance.push_back(level2PositionDistance[i-1] / 2); 
    }
}

// 给定根结点所在的位置，求每一个结点在它所在的层的位置
void _get_positions_for_nodes(const MyBinaryTree &bt, map<MyBinaryTree, int> &node2Position, map<MyBinaryTree, int> &node2Level, vector<int> &level2PositionDistance)
{
    if(bt->lchild)
    {
        // 父结点与孩子结点之间的位置关系
        node2Position[bt->lchild] = node2Position[bt] - level2PositionDistance[node2Level[bt->lchild]] / 2;
        _get_positions_for_nodes(bt->lchild, node2Position, node2Level, level2PositionDistance);
    }
    if(bt->rchild)
    {
        // 父结点与孩子结点之间的位置关系
        node2Position[bt->rchild] = node2Position[bt] + level2PositionDistance[node2Level[bt->rchild]] / 2;
        _get_positions_for_nodes(bt->rchild, node2Position, node2Level, level2PositionDistance);
    }
}

// 给定二叉树，求各个结点在它所在的层的位置
void get_positions_for_nodes(const MyBinaryTree &bt, map<MyBinaryTree, int> &node2Level, map<MyBinaryTree, int> &node2Position)
{
    if(!bt)
    {
        return;
    }
    get_levels_for_nodes(bt, node2Level);
    vector<int> level2PositionDistance;
    get_node_distances(bt, level2PositionDistance);
    node2Position[bt] = level2PositionDistance[1] / 2;
    _get_positions_for_nodes(bt, node2Position, node2Level, level2PositionDistance);
}

// 直观地输出二叉树
void print_binary_tree_prettily(const MyBinaryTree &bt)
{
    vector<MyBinaryTree> vecOfNodePtrInLevelOrder; // 结点按层序排列
    get_level_order_pointers(bt, vecOfNodePtrInLevelOrder);
    map<MyBinaryTree, int> node2Level; // 每个结点所在的层
    map<MyBinaryTree, int> node2Position; // 每个结点在某层的位置
    get_positions_for_nodes(bt, node2Level, node2Position);
    // 初始化有利于后面的循环
    int last_node_level = 1;
    int last_node_position = 0;
    // 按层序输出结点
    for(int i = 0; i < vecOfNodePtrInLevelOrder.size(); i++)
    {
        MyBinaryTree curr_tr = vecOfNodePtrInLevelOrder[i]; // 此刻要输出的结点
        if(node2Level[curr_tr] != last_node_level) // 进入下一层
        {
            last_node_position = 0; // 光标回到行首
            last_node_level++; // 更新所在的层
            cout << endl;
        }
        for(int j = last_node_position + 1; j < node2Position[curr_tr]; j++)
        {
            // cout << "\t\t"; // 输出若干个空位
            cout << "   ";
        }
        last_node_position = node2Position[curr_tr]; // 记住刚刚输出的结点的位置
        // cout << "\t" << curr_tr->data << "\t";
        cout << " " << curr_tr->data << " ";
    }
}


// 销毁根指针非空的二叉树
void _destroy_binary_tree(const MyBinaryTree &bt)
{
    if(bt->lchild)
    {
        _destroy_binary_tree(bt->lchild);
    }
    if(bt->rchild)
    {
        _destroy_binary_tree(bt->rchild);
    }
    delete bt;
}

// 销毁二叉树
int destroy_binary_tree(const MyBinaryTree &bt)
{
    if(!bt)
    {
        return ERROR;
    }
    _destroy_binary_tree(bt);
    return OK;
}