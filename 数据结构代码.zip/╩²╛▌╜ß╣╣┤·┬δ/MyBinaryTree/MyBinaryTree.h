#ifndef MY_BINARY_TREE
#define MY_BINARY_TREE

#include <string>
#include <queue>
#include <map>
using namespace std;

typedef class MyBinaryNode{
    public:
        string data;
        MyBinaryNode* lchild;
        MyBinaryNode* rchild;
} *MyBinaryTree;

// 用户输入各个结点的值，创建二叉树
void create_binary_tree(MyBinaryTree& bt);

// 根据给定的括号形式的字符串，创建二叉树
void create_binary_tree(MyBinaryTree& bt, const string& str);

// 以括号的形式输出二叉树
void print_binary_tree_as_general_list(MyBinaryTree& bt);

// 生动打印二叉树
void print_binary_tree_prettily(const MyBinaryTree& bt);

// 给定二叉树返回树的深度
int depth(const MyBinaryTree &bt);

// 给定二叉树返回结点个数
int node_count(MyBinaryTree &bt);

// 中序遍历二叉树
void in_order_traverse(const MyBinaryTree bt);

// 中序遍历二叉树（非递归）
void in_order_traverse_nonrecursively(const MyBinaryTree bt);

// 前序遍历二叉树
void pre_order_traverse(const MyBinaryTree bt);

// 后序遍历二叉树
void post_order_traverse(const MyBinaryTree bt);

// 层序遍历二叉树
void level_order_traverse(const MyBinaryTree bt);

// 复制二叉树，把bt复制到new_bt
void copy_binary_tree(const MyBinaryTree bt, MyBinaryTree &new_bt);

// 求每个结点指针的父结点指针（根结点除外）
void get_parents_for_nodes(const MyBinaryTree &bt, map<MyBinaryTree, MyBinaryTree> &mmap);

// 求每个结点所在的层数
void get_levels_for_nodes(const MyBinaryTree &bt, map<MyBinaryTree, int> &mmap);

// 求每层的首位置以及位置之间的距离
void get_node_distances(const MyBinaryTree &bt, vector<int>& level2PositionDistance);

// 给定二叉树，求各个结点在它所在的层的位置
void get_positions_for_nodes(const MyBinaryTree &bt, map<MyBinaryTree, int> &node2Level, map<MyBinaryTree, int> &node2Position);

// 销毁二叉树
int destroy_binary_tree(const MyBinaryTree &bt);

#endif