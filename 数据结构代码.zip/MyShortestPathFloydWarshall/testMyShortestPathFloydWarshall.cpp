#include <iostream>
#include <string>

#include "MyAdjacencyMatrix.h"
#include "MyShortestPathFloydWarshall.h"

const int SUCCESS = 0;

#ifdef undirected_mode
const string FILE_NAME = "undirected_data_file.txt";
#else
const string FILE_NAME = "directed_data_file.txt";
#endif

using namespace std;

int main()
{
    AMGraph my_graph;
    create_undirected_network(my_graph, FILE_NAME);
    print_undirected_network(my_graph);
    vector<vector<int>> predecessor_in_path(my_graph.vertex_num + 1, vector<int>(my_graph.vertex_num + 1, 0));
    vector<vector<int>> shortest_path_len(my_graph.vertex_num + 1, vector<int>(my_graph.vertex_num + 1, 0));
    yield_shortest_path_floyd_warshall(my_graph, predecessor_in_path, shortest_path_len);
    // 打印最短路径信息
    print_shortest_path_info(my_graph, predecessor_in_path, shortest_path_len);
    
    return SUCCESS;
}