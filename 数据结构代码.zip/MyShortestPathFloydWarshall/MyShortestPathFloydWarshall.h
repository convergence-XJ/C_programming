#ifndef MY_SHORTEST_PATH_FLOYD_WARSHALL_H
#define MY_SHORTEST_PATH_FLOYD_WARSHALL_H

#include <vector>
#include "MyAdjacencyMatrix.h"

using namespace std;


// 用Floyd Warshell算法求有向网G的各对顶点之间的最短路径
// predecessor_in_path[i][j]表示从i号顶点出发到j号顶点，最短路径上的j号顶点的前一顶点的序号，predecessor_in_path初始时为(v_num+1)*(v_num+1)的矩阵
// curr_shortest_path[i][j]表示从i号顶点出发到j号顶点，当前求得的最短路径的长度，curr_shortest_path初始时为(v_num+1)*(v_num+1)的矩阵
void yield_shortest_path_floyd_warshall(const AMGraph &my_graph, vector<vector<int>> & predecessor_in_path, vector<vector<int>> & curr_shortest_path_len);


// 打印任意两顶点之间的最短路径及其长度
// predecessor_in_path[i][j]表示从i号顶点出发到j号顶点，最短路径上的j号顶点的前一顶点的序号，predecessor_in_path初始时为(v_num+1)*(v_num+1)的矩阵
// curr_shortest_path[i][j]表示从i号顶点出发到j号顶点，当前求得的最短路径的长度，curr_shortest_path初始时为(v_num+1)*(v_num+1)的矩阵
void print_shortest_path_info(const AMGraph &my_graph, const vector<vector<int>> & predecessor_in_path, const vector<vector<int>> & curr_shortest_path_len);

#endif