#include <iostream>
#include <vector>
#include "MyShortestPathFloydWarshall.h"

// #define debug_mode

using namespace std;

// 用Floyd Warshell算法求有向网G的各对顶点之间的最短路径
// predecessor_in_path[i][j]表示从i号顶点出发到j号顶点，最短路径上的j号顶点的前一顶点的序号，predecessor_in_path初始时为(v_num+1)*(v_num+1)的矩阵
// curr_shortest_path[i][j]表示从i号顶点出发到j号顶点，当前求得的最短路径的长度，curr_shortest_path初始时为(v_num+1)*(v_num+1)的矩阵
void yield_shortest_path_floyd_warshall(const AMGraph &my_graph, vector<vector<int>> & predecessor_in_path, vector<vector<int>> & curr_shortest_path_len)
{
    // 初始化最短路径信息
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        for(int j = 1; j <= my_graph.vertex_num; j++)
        {
            curr_shortest_path_len[i][j] = my_graph.arcs[i][j];
            if(curr_shortest_path_len[i][j] < DIST_INFINITY) // i号顶点与j号顶点之间有一条边
            {
                //cout << "i: " << i << ", j: " << j << endl;
                predecessor_in_path[i][j] = i; // 当前最短路径上，j号顶点的前一个顶点，它的下标为i
            }
            else
            {
                predecessor_in_path[i][j] = -1; // 设为非法值
            }
            cout << predecessor_in_path[i][j] << "\t";
        }
        cout << endl;
    }
    // 计算

    // 以下循环，表示求出任何两对顶点之间，“途经的顶点的序号”不超过k的最短路径
    for(int k = 1; k <= my_graph.vertex_num; k++)
    {
        // 以下两重循环，表示针对任何一对顶点
        for(int i = 1; i <= my_graph.vertex_num; i++)
        {
            for(int j = 1; j <= my_graph.vertex_num; j++)
            {
                if(curr_shortest_path_len[i][k] < DIST_INFINITY && curr_shortest_path_len[k][j] < DIST_INFINITY && curr_shortest_path_len[i][k] + curr_shortest_path_len[k][j] < curr_shortest_path_len[i][j]) // 途经k能得到更短路径
                {
                    curr_shortest_path_len[i][j] = curr_shortest_path_len[i][k] + curr_shortest_path_len[k][j];
                    predecessor_in_path[i][j] = predecessor_in_path[k][j];
                }
            }
        }
    }
}

// 打印任意两顶点之间的最短路径及其长度
// predecessor_in_path[i][j]表示从i号顶点出发到j号顶点，最短路径上的j号顶点的前一顶点的序号，predecessor_in_path初始时为(v_num+1)*(v_num+1)的矩阵
// curr_shortest_path[i][j]表示从i号顶点出发到j号顶点，当前求得的最短路径的长度，curr_shortest_path初始时为(v_num+1)*(v_num+1)的矩阵
void print_shortest_path_info(const AMGraph &my_graph, const vector<vector<int>> & predecessor_in_path, const vector<vector<int>> & curr_shortest_path_len)
{
    // 以下对任意一对顶点
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        cout << my_graph.vertices[i] << ":" << endl;
        for(int j = 1; j <= my_graph.vertex_num; j++)
        {
            cout << "\t" << my_graph.vertices[j] << ":" << endl;
            if(predecessor_in_path[i][j] == -1)
            {
                cout << "\tno path found" << endl;
                continue;
            }

            vector<int> i_j_path; // 从i号顶点往j号顶点的路径

            // 先进入最末端的顶点
            i_j_path.push_back(j); 
            // cout << "j: " << j << endl;
            int k = j;
            do
            {
                k = predecessor_in_path[i][k]; // 找前驱
                i_j_path.push_back(k); // 进入
            }while(k != i); // 找到i就结束

            cout << "\tshortest path: ";
            // 按顺序输出最短路径
            for(int i = i_j_path.size() - 1; i >= 0; i--)
            {
                cout << my_graph.vertices[i_j_path[i]] << "\t";
            }
            cout << endl;
            cout << "\tshortest path len: " << curr_shortest_path_len[i][j] << endl;
        }

    }
}
