#include <iostream>
#include <vector>
#include "MyTopologicalSort.h"

using std::cout;
using std::endl;

const int FAILURE = -1;
const int SUCCESS = 0;

#ifdef undirected_mode
const string FILE_NAME = "undirected_data_file.txt";
#else
// const string FILE_NAME = "directed_data_file.txt";
// const string FILE_NAME = "course_order_file.txt";
const string FILE_NAME = "directed_data_file2.txt";
#endif

int main()
{
#ifdef undirected_mode
    cout << "Below is an undirected graph" << endl;
#else
    cout << "Below is a directed graph" << endl;
#endif
    ALGraph my_graph;
    if(!create_undirected_graph(my_graph, FILE_NAME))
    {
        return FAILURE;
    }
    print_undirected_graph(my_graph);

    vector<int> topo_sort_res_in_indexes;
    if(!topologicalSort(my_graph, topo_sort_res_in_indexes))
    {
        cout << "cannot topologically sort a cyclic graph" << endl;
        return EXIT_FAILURE;
    }
    cout << "topological sort:" << endl;
    for(vector<int>::iterator itr = topo_sort_res_in_indexes.begin(); itr != topo_sort_res_in_indexes.end(); itr++)
    {
        cout << my_graph.vertices[*itr].data << "\t";
    }
    cout << endl;
    destroy_undirected_graph(my_graph);
    return SUCCESS;
}