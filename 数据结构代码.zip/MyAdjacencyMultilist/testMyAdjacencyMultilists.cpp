#include <iostream>
#include "MyAdjacencyMultilist.h"

const int FAILURE = -1;
const int SUCCESS = 0;

const std::string FILE_NAME = "undirected_data_file.txt";

int main()
{
    AMLGraph my_graph;
    if(!create_undirected_network(my_graph, FILE_NAME))
    {
        return FAILURE;
    }
    print_undirected_network(my_graph);
    
    destroy_undirected_network(my_graph);

    std::cout << "OK" << std::endl;

    return SUCCESS;
}