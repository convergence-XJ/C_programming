#ifndef MY_ADJACENCY_MULTILIST_H
#define MY_ADJACENCY_MULTILIST_H

#include <string>

typedef std::string VertexType;
typedef int EdgeDataType;

typedef enum{
    unvisited,
    visited
    } VisitIf; // 定义Visit类型，只能取unvisited和visited两个常量值

typedef struct EdgeBox{ // 边结点
    VisitIf mark; // 是否被访问过
    int i_vertex_index, j_vertex_index; // 两个结点的下标
    struct EdgeBox *i_link, *j_link; // 下一条关联到i号顶点的边，下一条关联到j号顶点的边
    EdgeDataType data; // 数据信息
} EdgeBox;

typedef struct VertexBox{ // 顶点结点
    VertexType data; // 数据信息
    EdgeBox* edge_first; // 指向第一条关联到该顶点的边，该边的两个顶点，恰有一个是本顶点
} VertexBox;

typedef struct AMLGraph{ // 无线图或者网
    VertexBox *adjacency_multilist; // 
    int vertex_num, edge_num; // 顶点数和边数
} AMLGraph;


// 创建基于邻接多重表的无向图（网），数据来源于文件
int create_undirected_network(AMLGraph &my_graph, const std::string& file_name);

// 销毁邻接多重表
void destroy_undirected_network(AMLGraph &my_graph);

// 打印基于邻接多重表的无向图（网）
void print_undirected_network(const AMLGraph &my_graph);

#endif