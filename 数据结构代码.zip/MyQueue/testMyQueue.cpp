#include <iostream>

#include "MyQueue.h"

using namespace std;

int main()
{
    int a1[] = {2, 3, 5, 7};
    int a2[] = {11, 13, 17, 19};
    MyQueue que1(a1, 4), que2(a2, 4);

    cout << "que1:" << endl;
    que1.show();
    cout << endl;
    
    cout << "que2:" << endl;
    que2.show();
    cout << endl;

    int x = 8;
    que1.enQueue(x); // que1.enQueue(4);
    cout << "appended " << x << " into que1" << endl;
    cout << "que1:" << endl;
    que1.show();
    cout << endl;

    x = 6;
    que2.enQueue(x);
    cout << "appended " << x << " into que2" << endl;
    x = 4;
    que2.enQueue(x);
    cout << "appended " << x << " into que2" << endl;
    cout << "que2:" << endl;
    que2.show();
    cout << endl;

    x = que1.deQueue();
    cout << "obtained " << x << " from que1" << endl;
    cout << "que1:" << endl;
    que1.show();
    cout << endl;

    x = que2.deQueue();
    cout << "obtained " << x << " from que2" << endl;
    x = que2.deQueue();
    cout << "obtained " << x << " from que2" << endl;
    cout << "que2:" << endl;
    que2.show();
    cout << endl;

    x = 3;
    que1.enQueue(x);
    cout << "appended " << x << " into que1" << endl;
    cout << "que1:" << endl;
    que1.show();
    cout << endl;

    x = 4;
    que2.enQueue(x);
    cout << "appended " << x << " into que2" << endl;
    cout << "que2:" << endl;
    que2.show();
    cout << endl;
    
    return 0;
}