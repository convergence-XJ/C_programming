#ifndef MY_QUEUE_H
#define MY_QUEUE_H

const int INIT_SIZE = 4;
const int OK = 1;
const int ERROR = 0;

class MyQueue{
/*用长度为n+1的数组来实现长度不超过n的动态队列，
当空间不足时，动态扩充*/
    private:
        int *arr; // 数组首元素地址
        int array_capacity; // 数组容量
        int head; // 队首下标
        int tail; // 队尾的下一个元素的下标
        /*当head==tail时，队列为空；当tail+1==head时，队列为满。*/

    public:
        MyQueue();

        // 根据数组构造队列
        MyQueue(int *a, int n); 
        ~MyQueue();

        // 入队，空间不足时扩充
        void enQueue(int x);
        // 出队，返回出队的元素的值
        int deQueue();
        void show();
};

#endif