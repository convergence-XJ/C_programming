#ifndef MY_HASH_CHAINING_H
#define MY_HASH_CHAINING_H

#include <cstdlib>
#include <string>

using namespace std;

const int INIT_TABLE_LEN = 19;
// const int M = 1e9 + 7;
const int B = 233;

typedef long long LL;

// 哈希链表的结点
class HashLinkedNode
{
public:
    string str;
    HashLinkedNode* next;
};

// 哈希链表的头结点
typedef class HashHeadNode
{
public:
    HashLinkedNode* head;
} HashEntry;

// 哈希链表的头结点形成哈希数组
class HashTable{
public:
    HashEntry *hash_array;
    int hash_array_len;
};

// 创建空的哈希表
int create_empty_hash_table_chaining(HashTable& htable);

// 把指针p指向的链表结点添加到哈希表中（如果数据元素已经存在，则不进行添加操作）
int insert_node_into_hash_table_chaining(const HashTable &htable, HashLinkedNode* p);

// 请求用户输入数据到哈希表
int ask_for_data_to_be_inserted_into_hash_table_chaining(const HashTable& htable);

// 把字符串迭代器里的数据，插入到哈希表
int insert_data_into_hash_table_chaining_from_vector(const HashTable& htable, vector<string> &str_vec);

// 删除数据元素，如果数据元素不存在，则不进行任何修改操作
void remove_data_from_hash_table_chaining(HashTable &htable, const string& data);

// 查看关键字为key的元素是否存在，若存在，返回指向该元素所在结点的指针，否则返回NULL
HashLinkedNode* address_of_element(const string & data, const HashTable &htable);

// 打印哈希表
void print_hash_table_chaining(const HashTable& htable);

// 销毁哈希表
void destroy_hash_table_chaining(HashTable &htable);

// 查看关键字为key的元素是否存在，若存在，返回指向该元素所在结点的指针，否则返回NULL
HashLinkedNode* address_of_element(const HashTable &htable, const string & data);

#endif