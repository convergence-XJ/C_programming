#include <iostream>
#include <cstdlib>
#include <ctime>
#include "MyVector.h"

const int FAILURE = -1;

// 无参构造函数
MyVector::MyVector()
{
    array_capacity = INIT_CAPACITY;
    arr = new int[array_capacity + 1]; // 0号元素不用
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(FAILURE);
    }
    array_size = 0;
}

// 带参构造函数
MyVector::MyVector(int *a, int sz)
{
    // 确定容量
    array_capacity = INIT_CAPACITY > sz ? INIT_CAPACITY : sz;
    // 分配空间
    arr = new int[array_capacity + 1]; // 因为0号单元不用，所以多一个空间
    if(!arr)
    {
        cout << "insufficient memory" << endl;
        exit(1);
    }
    // 复制
    for(int i = 1; i <= sz; i++)
    {
        arr[i] = a[i-1]; // 注意到数组的0号元素是使用的
    }
    array_size = sz; // 维护数组大小
}

// 析构函数
MyVector::~MyVector()
{
    delete[] arr;
}

// 取值
int MyVector::get_element(int i, int &e)
/*返回下标为i的元素（即第i+1个元素）的值*/
{
    if(i < 1 || i > array_size) // 访问越界
    {
        return ERROR;
    }
    e = arr[i];
    return OK;
}

// 定位
int MyVector::locate_element(int e)
/*返回最后一个值为e的元素的下标；若满足条件的元素不存在，则返回0，*/
{
    int i;
    // 从后往前搜查
    for(i = array_size; i >= 1; i--)
    {
        if(arr[i] == e) // 找到
        {
            break;
        }
    }
    return i;
}

// 插入
int MyVector::insert_element(int i, int e)
/*在下标为i的位置之前插入元素e，i的范围是[1, array_size+1]*/
{
    if(i < 1 || i > array_size + 1) // 这里特别允许在所有元素之后插入
    {
        return ERROR; // 不在合法范围内
    }
    
    if(array_capacity < array_size + 1) // 容量不足
    {
        
        int* new_arr = new int[array_capacity * 2 + 1]; // 分配空间
        if(!new_arr)
        {
            cout << "insufficient memory" << endl;
            exit(FAILURE);
        }
        array_capacity *= 2; // 容量增大为2倍
        int j;
        // 把前面i个旧元素复制过去
        for(j = 1; j <= i - 1; j++)
        {
            new_arr[j] = arr[j];
        }
        new_arr[j++] = e; // 插入元素
        for(; j <= array_size + 1; j++)
        {
            new_arr[j] = arr[j - 1]; // 复制发生偏移
        }
        delete[] arr; // 销毁原数组
        arr = new_arr; // 关联新数组
    }
    else
    {
        for(int j = array_size; j >= i; --j)
        {
            arr[j + 1] = arr[j]; // 元素后移，包括下标为i的元素
        }
        arr[i] = e;
    }
    array_size++;
    return OK;
}

// 删除
int MyVector::delete_element(int i)
/*删除下标为i的元素*/
{
    if(i < 1 || i > array_size)
    {
        return ERROR;
    }
    // 下标从i+1开始是后面的元素，直到最后一个
    for(int j = i + 1; j <= array_size; j++)
    {
        arr[j - 1] = arr[j]; // 前移
    }
    array_size--;
    return OK;
}

// 往迭代器末端添加元素e
void MyVector::push_back(int e)
{
    // 可能需要调整容量
    if(array_size == array_capacity)
    {
        int* new_arr = new int[array_capacity * 2 + 1]; // 分配空间
        if(!new_arr)
        {
            cout << "insufficient memory" << endl;
            exit(FAILURE);
        }
        array_capacity *= 2; // 容量增大为2倍
        // 把前面i个旧元素复制过去
        for(int j = 1; j <= array_size; j++)
        {
            new_arr[j] = arr[j];
        }
        delete[] arr; // 销毁原数组
        arr = new_arr; // 关联新数组
    }
    arr[++array_size] = e;
}

// 打印
void MyVector::show()
{
    for(int i = 1; i <= array_size; i++)
    {
        cout << arr[i] << '\t';
    }
}

// 将有序表r[low, mid]和r[mid+1, high]归并到t[low, high]中
void MyVector::merge(int *r, int *t, int low, int mid, int high)
{
    int i = low; // 用于遍历第一个数组的元素
    int j = mid + 1; // 用于遍历第二个数组的元素
    int k = low; // 用于指向被填充的位置
    while(i <= mid && j <= high) // 当两个数组都还有元素未填充时，需要比较
    {
        t[k++] = r[i] < r[j] ? r[i++] : r[j++]; // 按从小到大的顺序填入
    }
    // 把第一个数组的剩余元素填入
    while (i <= mid)
    {
        t[k++] = r[i++]; //
    }
    // 把第二个数组的剩余元素填入
    while (j <= high)
    {
        t[k++] = r[j++];
    }
}

// 将r[low, high]进行归并排序后放入t[low, high]中
void MyVector::msort(int *r, int *t, int low, int high)
{
    if(low == high)
    {
        t[low] = r[low];
        return;
    }
    int mid = (low + high) / 2; // 数组等分成两半
    int *s = new int[array_size + 1];
    msort(r, s, low, mid); // 对前面一半进行归并排序，放入到s相应位置
    msort(r, s, mid + 1, high); // 对后面一半进行归并排序，放入到s相应位置
    merge(s, t, low, mid, high); // 对s的两张相邻有序表归并到t中
    delete[] s; // 回收空间
}

// 归并排序
void MyVector::merge_sort()
{
    // 把arr[1, array_size]进行归并排序后，放入arr[1, array_size]中
    msort(arr, arr, 1, array_size);
}