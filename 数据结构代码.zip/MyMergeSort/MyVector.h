#ifndef MY_VECTOR_H
#define MY_VECTOR_H
#include <iostream>

using namespace std;

const int OK = 1;
const int ERROR = 0;

const int INIT_CAPACITY = 4;

class MyVector{ // 0号单元不用

    private:
        int *arr; // 数组首元素地址
        int array_size; // 数组长度
        int array_capacity; // 迭代器容量

        // 以下是归并排序的子过程
        // 将有序表r[low, mid]和r[mid+1, high]归并到t[low, high]中
        void merge(int *r, int *t, int low, int mid, int high);

        // 将r[low, high]进行归并排序后放入t[low, high]中
        void msort(int *r, int *t, int low, int high);
        
    public:
        MyVector();
        MyVector(int *a, int sz);
        ~MyVector();

        /*返回下标为i的元素（即第i+1个元素）的值*/
        int get_element(int i, int &e);

        /*返回最后一个值为e的元素的下标；若满足条件的元素不存在，则返回-1，*/
        int locate_element(int e);

        /*在下标为i的位置之前插入元素e，i的范围是[0, array_size]*/
        int insert_element(int i, int e);

        /*删除下标为i的元素*/
        int delete_element(int i);

        /*往迭代器末端添加元素*/
        void push_back(int e);

        /*输出迭代器的内容*/
        void show();

        /*归并排序*/
        void merge_sort();

};

#endif