#include <iostream>
#include <algorithm>
#include "MyMinSpanningTreeKruskal.h"

using namespace std;

// 根据克鲁斯卡尔算法，返回最小生成树
vector<pair<VertexType, VertexType>> min_spanning_tree_kruskal(const AMGraph & my_graph)
{
    vector<pair<VertexType, VertexType>> edge_vertex_pairs;
    vector<Edge> vecOfEdge;
    // 从邻接矩阵中读出边
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        for(int j = i + 1; j <= my_graph.vertex_num; j++)
        {
            if(my_graph.arcs[i][j] == INFINITY) // 边不存在
            {
                continue;
            }
            vecOfEdge.push_back(Edge(my_graph.vertices[i], my_graph.vertices[j], my_graph.arcs[i][j]));
        }
    }

    // 排序
    sort(vecOfEdge.begin(), vecOfEdge.end());

    // 根据顶点的下标，确定所属连通分量的id，
    int * id_of_component_belonging_to = new int[my_graph.vertex_num + 1];
    if(!id_of_component_belonging_to)
    {
        cout << "insufficient memory" << endl;
        exit(EXIT_FAILURE);
    }

    // 一开始的时候没有边，任何两个顶点属于不同的连通分量
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        id_of_component_belonging_to[i] = i;
    }

    // 生成树
    for(int i = 0; i < vecOfEdge.size(); i++)
    {
        VertexType v1 = vecOfEdge[i].v1;
        VertexType v2 = vecOfEdge[i].v2;

        int connected_component_id1 = id_of_component_belonging_to[locate_vertex(my_graph, v1)];
        int connected_component_id2 = id_of_component_belonging_to[locate_vertex(my_graph, v2)];

        // 判断是否属于同一个连通分量
        if(connected_component_id1 == connected_component_id2)
        {
            continue;
        }

        // 输出
        cout << v1 << ", " << v2 << endl;

        edge_vertex_pairs.push_back(pair<VertexType, VertexType>(v1, v2));

        // 连接，维护所归属的连通分量
        for(int i = 1; i <= my_graph.vertex_num; i++)
        {
            // 把所有连同分量id为xx2的都改成xx1
            if(id_of_component_belonging_to[i] == connected_component_id2)
            {
                id_of_component_belonging_to[i] = connected_component_id1;
            }
        }
    }

    // 销毁内存
    delete[] id_of_component_belonging_to;
    return edge_vertex_pairs;
}