#ifndef MY_BINARY_SORT_TREE_H
#define MY_BINARY_SORT_TREE_H

#include <string>

using namespace std;

const int END_FLAG = -1; // 自定义常量，作为输入的结束标志
const int OK = 1;
const int ERROR = 0;

typedef int KeyType;
typedef string InfoType;

typedef struct{
    KeyType key; // 关键字项
    InfoType otherinfo; // 其他数据字项
} ElementType; // 数据域的类型

typedef struct MyBSTNode
{
    ElementType data; // 数据域
    struct MyBSTNode *lchild, *rchild; // 指针域，用于指向左右孩子
} MyBSTNode, *MyBSTree;

// 依次读取关键字为key的结点，将此结点插入二叉排序树bst中
int createBST(MyBSTree &bst);

// 直观打印二叉排序树bst
void print_binary_sort_tree_prettily(const MyBSTree &bst);

// 从二叉排序树中，删除某个关键字为key的元素，若这样的元素不存在，则不执行任何操作
void delete_element_from_BST(MyBSTree &bst, KeyType key);

#endif