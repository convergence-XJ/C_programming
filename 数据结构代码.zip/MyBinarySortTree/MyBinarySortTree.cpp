#include <iostream>
#include <cstdlib>
#include <map>
#include <vector>
#include <queue>
#include <string>

#include "MyBinarySortTree.h"

// 在“以bst所指的结点”为根结点的二叉树中，递归地查找关键字等于key的某个数据元素
// 若成功，则返回指向“该元素所在结点”的指针，否则返回NULL
MyBSTree searchBST(MyBSTree &bst, KeyType key)
{
    if(!bst || key == bst->data.key)
    {
        return bst;
    }
    if(key < bst->data.key)
    {
        return searchBST(bst->lchild, key);
    }
    return searchBST(bst->rchild, key);
}

// 把数据e插入到二叉排序树bst中
int insert_element_into_BST(MyBSTree &bst, ElementType e)
{
    if(!bst) // 空树，找到了要插入的位置，直接创建结点
    {
        bst = new MyBSTNode; // 创建结点
        if(!bst)
        {
            return ERROR;
        }
        bst->data = e; // 数据域置为e
        bst->lchild = bst->rchild = NULL; // *bst为叶结点
    }
    else if(e.key < bst->data.key) // 偏小，插入到左子树中
    {
        insert_element_into_BST(bst->lchild, e); // 将e插入到左子树
    }
    else if(e.key > bst->data.key)
    {
        insert_element_into_BST(bst->rchild, e); // 将e插入到右子树
    }
    return OK;
}

// 从二叉排序树中，删除某个关键字为key的元素，若这样的元素不存在，则不执行任何操作
void delete_element_from_BST(MyBSTree &bst, KeyType key)
{
    /*f为上线，p为下线*/
    MyBSTNode *p = bst;
    MyBSTNode *f = NULL; // 用于指向*p的父结点，即(*f)为(*p)的父结点
    /*从根结点开始查找关键字为key的结点*/
    while(p) // 仍有继续探索的可能
    {
        if(p->data.key == key) // 找到（如果待删除结点为根结点，也会立即退出循环，f仍未空指针）
        {
            break; // 终止循环
        }
        f = p; // f跟进p，稍后p往前走
        if(key < p->data.key) // 根据比较结果决定走向
        {
            p = p->lchild; 
        }
        else
        {
            p = p->rchild;
        }
    }

    if(!p) // 找不到需要被删除的结点
    {
        return; // 直接返回
    }

    // 此刻(*p).data为要删除的数据，但为了重用，只要搬走就行，后面其他数据可以入驻

    /*----考虑3种情况实现p所指子树内部的处理：*p 左右子树均不空、无右子树、无左子树－－－*/
    MyBSTNode *q = NULL; // 用于保存待删除结点的地址，设为NULL有利于减轻误操作的危害
    /*左右子树都非空*/
    if(p->lchild && p->rchild)
    {
        /*以下q为s的上线*/
        q = p; // 
        MyBSTNode* s = p->lchild; // 寻求左子树，以便后面找到比(*p)小的最大元
        // 已经初始化了q和s的关系
        while (s->rchild) // 右子树存在，说明非最大元
        {
            q = s; // q跟上s
            s = s->rchild; // s往右走（因为要寻求最大元）
        }
        // 此刻s指向比(*p)小的最大元，并且(*s)不可能有右子树
        p->data = s->data; // 把s->data搬到(*p)的空间中
        if(q != p) // 说明(*(p->lchild))存在右子树
        {
            q->rchild = s->lchild; // 父亲外出务工，把孙子给爷爷托管
        }
        else // (*(p->lchild))不存在右子树
        {
            q->lchild = s->lchild; // 类似线性链表删除
        }
        delete s; // 数据已经搬走，衔接已经做好，销毁
        return;
    }
    else if(!p->rchild) // (*p)的右子树不存在，左子树可能存在
    {
        q = p; // 用于保存待删除的结点的地址
        p = p->lchild; // 用于保存待接入结点的地址，只需重接左子树（左子树不管是否存在，接上没错）
    }
    else if(!p->lchild) // (*p)的左子树不存在，右子树必存在
    {
        q = p; // 用于保存待删除的结点的地址
        p = p->rchild; // 用于保存待接入的结点的地址，只需重接右子树
    }

    /*将p所指的子树挂接到其父结点(*f)相应的位置*/
    if(!f) // 待删除结点为根结点
    {
        bst = p; // 类似线性链表删除，直接跳过
    }
    else if(q == f->lchild) // 待删除的是左孩子
    {
        f->lchild = p; // 接上，类似于线性链表，跳过实现删除
    }
    else // 待删除的是右孩子
    {
        f->rchild = p; // 接上，类似于线性链表，跳过实现删除
    }
    delete q; // 回收空间
}


// 依次读取关键字为key的结点，将此结点插入二叉排序树bst中
int createBST(MyBSTree &bst)
{
    bst = NULL; // 二叉排序树bst初始化为空树
    ElementType e; // 待插入的元素
    cout << "input key (int) and info (string) (" << END_FLAG << " means ending):" << endl;
    cin >> e.key >> e.otherinfo;
    while (e.key != END_FLAG)
    {
        if(!insert_element_into_BST(bst, e)) // 将数据元素插入到二叉排序树bst中
        {
            return ERROR;
        }
        cout << "input key (int) and info (string) (" << END_FLAG << " means ending):" << endl;
        cin >> e.key >> e.otherinfo;
    }
    return OK;
}

// 给定二叉排序树，求树的深度
int depth(const MyBSTree &bst)
{
    if(!bst)
    {
        return 0;
    }
    int l_dp = depth(bst->lchild);
    int r_dp = depth(bst->rchild);
    return l_dp > r_dp ? (l_dp + 1) : (r_dp + 1);
}

// 求每个结点指针的父结点指针（父结点除外）
void get_parents_for_nodes(const MyBSTree &bst, map<MyBSTree, MyBSTree> &child2Parent)
{
    if(!bst)
    {
        return;
    }
    // 存在左孩子
    if(bst->lchild)
    {
        child2Parent[bst->lchild] = bst;
    }
    // 存在右孩子
    if(bst->rchild)
    {
        child2Parent[bst->rchild] = bst;
    }
    // 递归
    get_parents_for_nodes(bst->lchild, child2Parent);
    get_parents_for_nodes(bst->rchild, child2Parent);
}

void _get_levels_for_nodes(const MyBSTree &bst, map<MyBSTree, int> &node2Level)
{
    if(!bst)
    {
        return;
    }
    // 存在左孩子
    if(bst->lchild)
    {
        node2Level[bst->lchild] = node2Level[bst] + 1; // 层数加1
    }
    // 存在右孩子
    if(bst->rchild)
    {
        node2Level[bst->rchild] = node2Level[bst] + 1; // 层数加1
    }
    // 递归调用
    _get_levels_for_nodes(bst->lchild, node2Level);
    _get_levels_for_nodes(bst->rchild, node2Level);
}

void get_levels_for_nodes(const MyBSTree &bst, map<MyBSTree, int> &node2Level)
{
    if(!bst)
    {
        return; // 
    }
    node2Level[bst] = 1; // 根结点的层数规定为1
    _get_levels_for_nodes(bst, node2Level);
}

// 层序保存指针
void get_level_order_pointers(const MyBSTree bst, vector<MyBSTree>& vecOfNodePtr)
{
    queue<MyBSTree> que;
    que.push(bst);
    while(!que.empty())
    {
        MyBSTree p = que.front();
        que.pop();
        if(!p)
        {
            continue;
        }
        vecOfNodePtr.push_back(p); // 指针进入迭代器
        que.push(p->lchild);
        que.push(p->rchild);
    }
}

// 给定二叉树，计算每一个层的相邻两结点之间的间距
void get_node_distances(const MyBSTree &bst, vector<int>& level2PositionDistance)
{
    int dp = depth(bst);
    int two2Dp = 1;
    for(int i = 0; i < dp; i++)
    {
        two2Dp *= 2; // 2^{dp}
    }
    level2PositionDistance.push_back(two2Dp * 2);
    for(int i = 1; i <= dp; i++)
    {
        // 每层相邻两个位置的间距，注意倍增关系
        level2PositionDistance.push_back(level2PositionDistance[i-1] / 2); 
    }
}

// 给定根结点所在的位置，求每一个结点在它所在的层的位置
void _get_positions_for_nodes(const MyBSTree &bst, map<MyBSTree, int> &node2Position, map<MyBSTree, int> &node2Level, vector<int> &level2PositionDistance)
{
    if(bst->lchild)
    {
        // 父结点与孩子结点之间的位置关系
        node2Position[bst->lchild] = node2Position[bst] - level2PositionDistance[node2Level[bst->lchild]] / 2;
        _get_positions_for_nodes(bst->lchild, node2Position, node2Level, level2PositionDistance);
    }
    if(bst->rchild)
    {
        // 父结点与孩子结点之间的位置关系
        node2Position[bst->rchild] = node2Position[bst] + level2PositionDistance[node2Level[bst->rchild]] / 2;
        _get_positions_for_nodes(bst->rchild, node2Position, node2Level, level2PositionDistance);
    }
}

// 给定二叉树，求各个结点在它所在的层的位置
void get_positions_for_nodes(const MyBSTree &bst, map<MyBSTree, int> &node2Level, map<MyBSTree, int> &node2Position)
{
    if(!bst)
    {
        return;
    }
    get_levels_for_nodes(bst, node2Level);
    vector<int> level2PositionDistance;
    get_node_distances(bst, level2PositionDistance);
    node2Position[bst] = level2PositionDistance[1] / 2;
    _get_positions_for_nodes(bst, node2Position, node2Level, level2PositionDistance);
}

// 直观地输出二叉树
void print_binary_sort_tree_prettily(const MyBSTree &bst)
{
    vector<MyBSTree> vecOfNodePtrInLevelOrder; // 结点按层序排列
    get_level_order_pointers(bst, vecOfNodePtrInLevelOrder);
    map<MyBSTree, int> node2Level; // 每个结点所在的层
    map<MyBSTree, int> node2Position; // 每个结点在某层的位置
    get_positions_for_nodes(bst, node2Level, node2Position);
    // 初始化有利于后面的循环
    int last_node_level = 1;
    int last_node_position = 0;
    // 按层序输出结点
    for(int i = 0; i < vecOfNodePtrInLevelOrder.size(); i++)
    {
        MyBSTree curr_bstr = vecOfNodePtrInLevelOrder[i]; // 此刻要输出的结点
        if(node2Level[curr_bstr] != last_node_level) // 进入下一层
        {
            last_node_position = 0; // 光标回到行首
            last_node_level++; // 更新所在的层
            cout << endl;
        }
        for(int j = last_node_position + 1; j < node2Position[curr_bstr]; j++)
        {
            // cout << "\t\t"; // 输出若干个空位
            cout << "    ";
        }
        last_node_position = node2Position[curr_bstr]; // 记住刚刚输出的结点的位置
        // cout << "\t" << curr_tr->data << "\t";
        cout << " ";
        int value = curr_bstr->data.key;
        if(value >= 0 && value < 10)
        {
            cout << "+";
        }
        cout << curr_bstr->data.key; 
        cout << " ";
    }
}