#include <iostream>

#include "MyBinarySortTree.h"

const int FAILURE = -1;
const int SUCCESS = 0;

using namespace std;

int main()
{
    MyBSTree bst;
    if(!createBST(bst))
    {
        return FAILURE;
    }
    cout << "bst:" << endl;
    print_binary_sort_tree_prettily(bst);
    cout << endl;
    int key;
    cout << "input a key value and we will delete a node with it: " << endl;
    cin >> key;
    delete_element_from_BST(bst, key);
    cout << "bst:" << endl;
    print_binary_sort_tree_prettily(bst);
    cout << endl;
    return SUCCESS;
}