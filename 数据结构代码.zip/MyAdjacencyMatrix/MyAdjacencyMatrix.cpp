#include <iostream>
#include <climits>
#include <cstring>
#include <queue>
#include <fstream>
#include "MyAdjacencyMatrix.h"

using namespace std;

#define ERROR 0
#define OK 1

const int DIST_INFINITY = INT32_MAX;

// 给定顶点，返回它在顶点数组（0号单元弃用）中的下标；若不存在，则返回0
int locate_vertex(const AMGraph& my_graph, VertexType data)
{
    int i;
    for(i = my_graph.vertex_num; i > 0; --i)
    {
        if(my_graph.vertices[i] == data)
        {
            break;
        }
    }
    return i;
}

// 利用邻接矩阵创建无向网
int create_undirected_network(AMGraph & my_graph)
{
    cout << "input the vertex number: " << endl;
    cin >> my_graph.vertex_num;
    cout << "input the arc number: " << endl;
    cin >> my_graph.arc_num;

    // 顶点数组
    my_graph.vertices = new VertexType[my_graph.vertex_num + 1]; // 0号单元不用
    if(!my_graph.vertices)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }

    // 邻接矩阵
    my_graph.arcs = new ArcType*[my_graph.vertex_num + 1]; // 0号单元不用
    if(!my_graph.arcs)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        my_graph.arcs[i] = new ArcType[my_graph.vertex_num + 1];
        if(!my_graph.arcs[i])
        {
            cout << "insufficient memory" << endl;
            return ERROR;
        }
    }

    // 顶点数组初始化
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        cout << "input the " << i << "-th vertex:" << endl;
        cin >> my_graph.vertices[i];
    }

    // 邻接矩阵的元素初始化为无穷大
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        for(int j = 1; j <= my_graph.vertex_num; j++)
        {
            my_graph.arcs[i][j] = DIST_INFINITY;
        }
    }
    
    // 用户初始化
    for(int k = 1; k <= my_graph.arc_num; k++)
    {
        VertexType v1, v2;
        ArcType w;
        cout << "input two vertices of an arc together with the respective weight:" << endl;
        cin >> v1 >> v2 >> w;
        int i = locate_vertex(my_graph, v1);
        int j = locate_vertex(my_graph, v2);
        my_graph.arcs[i][j] = w; // 如果是有向图，就只对一个方向的边赋值
#ifdef undirected_mode
        my_graph.arcs[j][i] = w; // 如果是无向图，还要对另一个方向赋值
#endif
    }
    return OK;
} // 如果只是创建无向无权图，则矩阵中的元素为0（表示不相连）或1（表示相连）

// 利用邻接矩阵创建无向网，基于文件提供的数据
int create_undirected_network(AMGraph & my_graph, const string file_name)
{
    ifstream in_file(file_name);
    if(!in_file)
    {
        cout << "fail to open " << file_name << endl;
        return ERROR;
    }

    int v_num, e_num;
    in_file >> my_graph.vertex_num >> my_graph.arc_num;
    // 分配空间
    my_graph.vertices = new VertexType[my_graph.vertex_num + 1];
    if(!my_graph.vertices)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }

    // 初始化顶点数组
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        in_file >> my_graph.vertices[i];
    }

    // 为邻接矩阵分配空间
    my_graph.arcs = new ArcType*[my_graph.vertex_num + 1]; // 0号单元不用
    if(!my_graph.arcs)
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        my_graph.arcs[i] = new ArcType[my_graph.vertex_num + 1];
        if(!my_graph.arcs[i])
        {
            cout << "insufficient memory" << endl;
            return ERROR;
        }
    }

    // 邻接矩阵的元素初始化为无穷大
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        for(int j = 1; j <= my_graph.vertex_num; j++)
        {
            my_graph.arcs[i][j] = DIST_INFINITY;
        }
    }

    for(int i = 1; i <= my_graph.arc_num; i++)
    {
        VertexType u, v;
        ArcType weight;
        in_file >> u >> v; // 写入顶点名称
        int u_index = locate_vertex(my_graph, u);
        int v_index = locate_vertex(my_graph, v);
        in_file >> weight;
        my_graph.arcs[u_index][v_index] = weight; // 如果是有向网，就只对一个方向的边赋值
#ifdef undirected_mode
        my_graph.arcs[v_index][u_index] = weight; // 注意到是无向网，具有对称性
#endif
    }
    in_file.close();
    return OK;
}

// 给定无向网，输出各条边以及权重
void print_undirected_network(const AMGraph & my_graph)
{
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        for(int j = i + 1; j <= my_graph.vertex_num; j++)
        {
            if(my_graph.arcs[i][j] < DIST_INFINITY)
            {
                cout << "(" << my_graph.vertices[i] << ", " << my_graph.vertices[j] << ", " << my_graph.arcs[i][j] << ")" << endl;
            }
        }
    }
}

// 销毁无向网
int destroy_undirected_graph(AMGraph &my_graph)
{
    if(!my_graph.vertices || !my_graph.arcs)
    {
        return ERROR;
    }
    delete[] my_graph.vertices;
    my_graph.vertices = NULL;
    for(int i = 1; i <= my_graph.vertex_num; i++)
    {
        if(!my_graph.arcs[i])
        {
            return ERROR;
        }
        delete[] my_graph.arcs[i];
    }
    delete[] my_graph.arcs;
    my_graph.arcs = NULL;
    return OK;
}

// 深度优先遍历
void dfs(const AMGraph &my_graph, int v, int* visited) // 只用于访问连通图
// my_graph为邻接矩阵类型，它的一部分顶点可能已经被访问过，
// 从第v个顶点出发深度优先遍历图my_graph
// 借助visited数组来维护各个顶点的访问情况
{
    cout << my_graph.vertices[v] << '\t'; // 访问第v个顶点
    visited[v] = true; // 把它置为已访问
    for(int w  = 1; w <= my_graph.vertex_num; w++) // 枚举所有顶点
    {
        if(my_graph.arcs[v][w] != DIST_INFINITY) // 如果v和w是邻居
        {
            if(!visited[w]) // w未被访问
            {
                dfs(my_graph, w, visited); // 从w出深度优先遍历图
            }
        }
    }
}


// 深度优先访问非连通图，my_graph为邻接矩阵类型
int dfs_traverse(const AMGraph &my_graph)
{
    // 以下用于维护各个顶点被访问的状况
    int *visited = new int[my_graph.vertex_num + 1];
    if(!visited) 
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }
    memset(visited, 0, sizeof(int) * (my_graph.vertex_num + 1)); // 初始化为未访问
    // 考虑每个顶点，以防非连通
    for(int v = 1; v <= my_graph.vertex_num; v++)
    {
        if(!visited[v]) // 找到未被访问的连通分量
        {
            dfs(my_graph, v, visited); // 每调用一次遍历一个连通分量
        }
    }
    delete[] visited;
    return OK;
}


// 广度优先遍历
void bfs(const AMGraph &my_graph, int v, int* visited) // 只用于访问连通图
// my_graph为邻接矩阵类型，它的一部分顶点可能已经被访问过，
// 从第v个顶点出发广度优先遍历图my_graph
// 借助队列来维护各顶点被访问的先后
{
    cout << my_graph.vertices[v] << "\t";
    visited[v] = true; // 置为已访问
    queue<int> que; // 用于存储自身被访问，并且可能有邻居未被访问的结点
    que.push(v); // 入队
    while(!que.empty()) 
    {
        int u = que.front(); // 获取队首元素
        que.pop();
        // 以下考虑每一个与u相邻的顶点
        for(int w = 1; w <= my_graph.vertex_num; w++) // 
        {
            if(my_graph.arcs[u][w] != DIST_INFINITY) // 第u个顶点和第w个顶点相邻
            {
                if(!visited[w]) // 未被访问
                {
                    cout << my_graph.vertices[w] << "\t";
                    visited[w] = 1; // 置为已访问
                    que.push(w); // 入队
                }
            }
        }
    }
}


// 广度优先访问非连通图，my_graph为邻接矩阵类型
int bfs_traverse(const AMGraph &my_graph)
{
    // 以下用于维护各个顶点被访问的状况
    int *visited = new int[my_graph.vertex_num + 1];
    if(!visited) 
    {
        cout << "insufficient memory" << endl;
        return ERROR;
    }
    memset(visited, 0, sizeof(int) * (my_graph.vertex_num + 1)); // 初始化为未访问
    // 考虑每个顶点，以防非连通
    for(int v = 1; v <= my_graph.vertex_num; v++)
    {
        if(!visited[v]) // 找到未被访问的连通分量
        {
            bfs(my_graph, v, visited); // 每调用一次遍历一个连通分量
        }
    }
    delete[] visited;
    return OK;
}